// adapters.js
// Адаптер описывает, как расширение находит поля карточки инцидента/события
// на конкретной SIEM-платформе. Так как MP SIEM, RuSIEM и BI.ZONE обычно
// разворачиваются on-prem на кастомных доменах и разметка может меняться
// от версии к версии, точные CSS-селекторы НЕ хардкодятся — это плейсхолдеры.
// Аналитик заполняет их один раз через "Пикер элементов" в настройках
// (options -> вкладка адаптера -> "Выбрать на странице"), после чего
// конфиг сохраняется в chrome.storage.local и используется дальше.

const SOC_COPILOT_DEFAULT_ADAPTERS = [
  {
    id: "mpsiem",
    name: "MaxPatrol SIEM",
    vendor: "Positive Technologies",
    enabled: true,
    // Подстроки пути/URL, по которым расширение решает, что это карточка
    // инцидента этой платформы. Отредактируйте под свой домен/маршруты.
    urlPatterns: ["/incidents/", "/events/", "/mpsiem", "ptsecurity"],
    selectors: {
      title: "",        // напр. заголовок инцидента
      description: "",  // описание / резюме
      severity: "",     // критичность
      status: "",        // статус обработки
      assignee: "",      // ответственный
      assets: "",        // затронутые активы/хосты
      timeline: "",       // таймлайн событий
      rawContainer: ""    // fallback: контейнер, откуда парсим текст целиком
    }
  },
  {
    id: "rusiem",
    name: "RuSIEM",
    vendor: "RuSIEM",
    enabled: true,
    urlPatterns: ["/incident", "/alert", "rusiem"],
    selectors: {
      title: "",
      description: "",
      severity: "",
      status: "",
      assignee: "",
      assets: "",
      timeline: "",
      rawContainer: ""
    }
  },
  {
    id: "bizone",
    name: "BI.ZONE (EDR/TDR)",
    vendor: "BI.ZONE",
    enabled: true,
    urlPatterns: ["/incidents", "/cases", "bizone"],
    selectors: {
      title: "",
      description: "",
      severity: "",
      status: "",
      assignee: "",
      assets: "",
      timeline: "",
      rawContainer: ""
    }
  },
  {
    id: "test-siem",
    name: "Тестовый стенд Belyaev Response",
    vendor: "Belyaev Response (встроенный тест)",
    enabled: true,
    urlPatterns: ["test-siem.html"],
    selectors: {
      title: "#bt-title",
      description: "#bt-description",
      severity: "#bt-severity",
      status: "#bt-status",
      assignee: "#bt-assignee",
      riskScore: "",
      timeline: "#bt-timeline",
      rawContainer: "#bt-card"
    }
  },
  {
    id: "universal",
    name: "Универсальный (MaxPatrol SIEM / KUMA / Security Vision / SearchInform / R-Vision / Splunk / ArcSight / другие)",
    vendor: "Любая SIEM-система",
    enabled: false,
    urlPatterns: [],
    selectors: {
      title: "h1, h2, .incident-title, .alert-title, [data-field='name']",
      description: "main, .incident-body, .alert-body, .description, [data-field='description']",
      severity: ".severity, .priority, [data-field='severity'], [data-field='priority']",
      status: ".status, [data-field='status']",
      assignee: ".assignee, .owner, [data-field='assignee']",
      riskScore: ".risk-score, [data-field='riskScore']",
      timeline: ".timeline, .events, [data-field='timeline']",
      rawContainer: "main, .container, body"
    }
  },
  {
    id: "generic",
    name: "Универсальный (fallback)",
    vendor: "—",
    // ВАЖНО (найдено при аудите безопасности/приватности): этот адаптер не имеет
    // urlPatterns и потому технически совпадает с ЛЮБЫМ сайтом. Если включить его
    // по умолчанию, расширение будет извлекать текст, писать событие в eventsLog
    // и регистрировать вкладку для кросс-корреляции на КАЖДОМ посещаемом сайте —
    // а не только на карточках инцидентов SIEM. Это подрывает саму идею
    // "активируется только на распознанных платформах" и превращает расширение
    // в незаметный трекер браузерной активности. По умолчанию — ВЫКЛЮЧЕН,
    // включение — осознанное действие аналитика в настройках (с явным
    // предупреждением там же, см. options.html).
    enabled: false,
    urlPatterns: [], // подходит всегда, если ни один другой адаптер не сматчился
    selectors: {
      title: "h1, h2",
      description: "main, [role=main], body",
      severity: "",
      status: "",
      assignee: "",
      assets: "",
      timeline: "",
      rawContainer: "body"
    }
  }
];

// Определяет, подходит ли адаптер под текущий URL
function socCopilotMatchAdapter(adapter, href) {
  if (!adapter.enabled) return false;
  if (!adapter.urlPatterns || adapter.urlPatterns.length === 0) return true; // generic fallback
  return adapter.urlPatterns.some((p) => p && href.toLowerCase().includes(p.toLowerCase()));
}

// Выбирает наиболее подходящий адаптер (не-generic приоритетнее)
function socCopilotResolveAdapter(adapters, href) {
  const specific = adapters.filter((a) => a.id !== "generic");
  const match = specific.find((a) => socCopilotMatchAdapter(a, href));
  if (match) return match;
  const generic = adapters.find((a) => a.id === "generic");
  return generic && generic.enabled ? generic : null;
}

if (typeof module !== "undefined") {
  module.exports = { SOC_COPILOT_DEFAULT_ADAPTERS, socCopilotMatchAdapter, socCopilotResolveAdapter };
}
