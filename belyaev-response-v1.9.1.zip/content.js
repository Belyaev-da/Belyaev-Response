// content.js — работает на каждой странице, но большую часть логики
// выполняет только если найден подходящий адаптер (см. adapters.js).

(function () {
  // Если content-script "осиротел" (расширение обновилось/перезагрузилось,
  // пока страница оставалась открытой), chrome.runtime становится undefined
  // или бросает "Extension context invalidated" — тихо выходим, не пытаясь
  // работать дальше на мёртвом контексте.
  if (!chrome?.runtime?.id) return;

  // Единая безопасная обёртка над chrome.runtime.sendMessage: гасит
  // синхронные исключения и chrome.runtime.lastError (например, если фон
  // в этот момент перезапускается или контекст инвалидировался уже после
  // старта скрипта), чтобы не ронять content-script и не спамить консоль.
  function socCopilotSendMessage(message, callback) {
    if (!chrome?.runtime?.id) {
      if (callback) callback(undefined);
      return;
    }
    try {
      chrome.runtime.sendMessage(message, (response) => {
        if (chrome.runtime.lastError) {
          if (callback) callback(undefined);
          return;
        }
        if (callback) callback(response);
      });
    } catch (e) {
      if (callback) callback(undefined);
    }
  }

  // Те же соображения, что и для socCopilotSendMessage: chrome.storage.local
  // может синхронно бросить исключение, если контекст расширения
  // инвалидировался уже после старта скрипта (например, обновление
  // расширения посреди SPA-сессии на странице).
  function socCopilotStorageGet(keys, callback) {
    if (!chrome?.runtime?.id) { if (callback) callback({}); return; }
    try {
      chrome.storage.local.get(keys, (data) => {
        if (chrome.runtime.lastError) { if (callback) callback({}); return; }
        if (callback) callback(data || {});
      });
    } catch (e) {
      if (callback) callback({});
    }
  }
  function socCopilotStorageSet(items, callback) {
    if (!chrome?.runtime?.id) { if (callback) callback(); return; }
    try {
      chrome.storage.local.set(items, () => { if (callback) callback(); });
    } catch (e) {
      if (callback) callback();
    }
  }
  function socCopilotStorageRemove(keys, callback) {
    if (!chrome?.runtime?.id) { if (callback) callback(); return; }
    try {
      chrome.storage.local.remove(keys, () => { if (callback) callback(); });
    } catch (e) {
      if (callback) callback();
    }
  }

  const STORAGE_KEYS = {
    adapters: "socCopilotAdapters",
    playbooks: "socCopilotPlaybooks",
    // apiKeys больше не хранятся в state.content.js — секреты шифруются и
    // расшифровываются только в background.js (см. utils/crypto.js, CHANGELOG 0.9.0).
    // Здесь остаётся только secretsMeta — булевы флаги "ключ настроен", без значений.
    checklists: "socCopilotChecklists",
    conclusionDrafts: "socCopilotConclusionDrafts",
    conclusionsHistory: "socCopilotConclusionsHistory",
    companyNames: "socCopilotCompanyNames",
    mentorProgress: "socCopilotMentorProgress",
    eventsLog: "socCopilotEventsLog",
    quizLog: "socCopilotQuizLog",
    belZorBalance: "socCopilotBelZorBalance",
    belZorLog: "socCopilotBelZorLog",
    installDate: "socCopilotInstallDate",
    license: "socCopilotLicense",
    grafanaSyncEnabled: "socCopilotGrafanaSyncEnabled",
    analystPseudonym: "socCopilotAnalystPseudonym",
    analystFullName: "socCopilotAnalystFullName",
    analystContacts: "socCopilotAnalystContacts",
    policyLocks: "socCopilotPolicyLocks",
    uiTheme: "socCopilotUITheme",
    uiLanguage: "socCopilotUILanguage"
  };

  let state = {
    adapters: SOC_COPILOT_DEFAULT_ADAPTERS,
    playbooks: SOC_COPILOT_DEFAULT_PLAYBOOKS,
    secretsMeta: {},
    activeAdapter: null,
    fields: {},
    iocMap: {},
    playbook: null,
    checkedSteps: [],
    conclusionDraft: { verdict: "", rootCause: "", impact: "", actionsTaken: "", recommendations: "" },
    conclusionsHistory: [],
    similarIncidents: [],
    relatedOpenTabs: [],
    companyNames: [],
    notifyChannels: { slack: false, telegram: false, max: false, teams: false, jira: false },
    highlightOn: false,
    mentorSteps: [],
    mentorStepIndex: 0,
    mentorProgress: { correct: 0, total: 0 },
    mentorAnswered: {},
    mentorTrack: "l1",
    eventsLog: [],
    belZorBalance: 0,
    belZorLog: [],
    riskScore: 0,
    anyMaliciousEnrichment: false,
    anyEnrichmentVerified: false,
    statsPeriod: "week",
    fieldSnapshot: null,
    alertStorms: [],
    quizLog: [],
    burnoutShownThisSession: false,
    licenseState: { tier: "free", source: "none", trialActive: false, trialDaysLeft: 0 },
    grafanaSyncEnabled: false,
    analystPseudonym: "",
    analystFullName: "",
    analystContacts: "",
    selectedOS: "windows",
    policyLocks: {},
    uiTheme: "dark",
    uiLanguage: "ru",
    glossaryTerms: [],
    panelOpen: false
  };

  function urlKey() {
    return location.origin + location.pathname + location.search;
  }

  function loadStorage() {
    return new Promise((resolve) => {
      socCopilotStorageGet(
        [
          STORAGE_KEYS.adapters,
          STORAGE_KEYS.playbooks,
          STORAGE_KEYS.checklists,
          STORAGE_KEYS.conclusionDrafts,
          STORAGE_KEYS.conclusionsHistory,
          STORAGE_KEYS.companyNames,
          STORAGE_KEYS.mentorProgress,
          STORAGE_KEYS.eventsLog,
          STORAGE_KEYS.quizLog,
          STORAGE_KEYS.belZorBalance,
          STORAGE_KEYS.belZorLog,
          STORAGE_KEYS.installDate,
          STORAGE_KEYS.license,
          STORAGE_KEYS.grafanaSyncEnabled,
          STORAGE_KEYS.analystPseudonym,
          STORAGE_KEYS.policyLocks,
          STORAGE_KEYS.uiTheme,
          STORAGE_KEYS.uiLanguage
        ],
        (data) => {
          state.adapters = data[STORAGE_KEYS.adapters] || SOC_COPILOT_DEFAULT_ADAPTERS;
          state.playbooks = data[STORAGE_KEYS.playbooks] || SOC_COPILOT_DEFAULT_PLAYBOOKS;
          state.companyNames = data[STORAGE_KEYS.companyNames] || [];
          // notifyChannels теперь определяется по secretsMeta (см. ниже, после запроса
          // к background) — сами токены/webhook-URL зашифрованы и здесь не читаются.
          const checklists = data[STORAGE_KEYS.checklists] || {};
          state.checkedSteps = checklists[urlKey()] || [];
          const drafts = data[STORAGE_KEYS.conclusionDrafts] || {};
          state.conclusionDraft = drafts[urlKey()] || { verdict: "", rootCause: "", impact: "", actionsTaken: "", recommendations: "" };
          state.conclusionsHistory = data[STORAGE_KEYS.conclusionsHistory] || [];
          state.mentorProgress = data[STORAGE_KEYS.mentorProgress] || { correct: 0, total: 0 };
          state.eventsLog = data[STORAGE_KEYS.eventsLog] || [];
          state.quizLog = data[STORAGE_KEYS.quizLog] || [];
          state.belZorBalance = data[STORAGE_KEYS.belZorBalance] || 0;
          state.belZorLog = data[STORAGE_KEYS.belZorLog] || [];
          state.grafanaSyncEnabled = !!data[STORAGE_KEYS.grafanaSyncEnabled];
          state.analystPseudonym = data[STORAGE_KEYS.analystPseudonym] || "";
          state.analystFullName = data[STORAGE_KEYS.analystFullName] || "";
          state.analystContacts = data[STORAGE_KEYS.analystContacts] || "";
          state.policyLocks = data[STORAGE_KEYS.policyLocks] || {};
          state.uiTheme = data[STORAGE_KEYS.uiTheme] || "dark";
          state.uiLanguage = data[STORAGE_KEYS.uiLanguage] || "ru";
          state.licenseState = socCopilotComputeLicenseState({
            installDate: data[STORAGE_KEYS.installDate] || new Date().toISOString(),
            license: data[STORAGE_KEYS.license] || null
          });
          // Секреты (API-ключи) больше не хранятся/не читаются здесь напрямую —
          // только булевы флаги "настроено ли", сам ключ расшифровывается и
          // используется исключительно в background.js (см. utils/crypto.js).
          socCopilotSendMessage({ type: "socCopilotGetSecretsMeta" }, (meta) => {
            state.secretsMeta = meta || {};
            state.notifyChannels = {
              slack: !!state.secretsMeta.webhook,
              telegram: !!state.secretsMeta.telegram,
              max: !!state.secretsMeta.max,
              teams: !!state.secretsMeta.teams,
              jira: !!state.secretsMeta.jira
            };
            resolve();
          });
        }
      );
    });
  }

  function saveChecklist() {
    socCopilotStorageGet([STORAGE_KEYS.checklists], (data) => {
      const checklists = data[STORAGE_KEYS.checklists] || {};
      checklists[urlKey()] = state.checkedSteps;
      socCopilotStorageSet({ [STORAGE_KEYS.checklists]: checklists });
    });
  }

  function saveConclusionDraft() {
    socCopilotStorageGet([STORAGE_KEYS.conclusionDrafts], (data) => {
      const drafts = data[STORAGE_KEYS.conclusionDrafts] || {};
      drafts[urlKey()] = state.conclusionDraft;
      socCopilotStorageSet({ [STORAGE_KEYS.conclusionDrafts]: drafts });
    });
  }

  function saveMentorProgress() {
    socCopilotStorageSet({ [STORAGE_KEYS.mentorProgress]: state.mentorProgress });
  }

  function findSimilarIncidents() {
    const currentIOCs = new Set(Object.values(state.iocMap || {}).flat());
    const currentTechniques = new Set((state.mitreTechniques || []).map((t) => t.id));
    if (!currentIOCs.size && !currentTechniques.size) return [];
    const scored = (state.conclusionsHistory || [])
      .filter((h) => h.url !== location.href)
      .map((h) => {
        const iocOverlap = (h.iocs || []).filter((v) => currentIOCs.has(v)).length;
        const techOverlap = (h.techniques || []).filter((t) => currentTechniques.has(t)).length;
        return { ...h, score: iocOverlap * 2 + techOverlap };
      })
      .filter((h) => h.score > 0)
      .sort((a, b) => b.score - a.score)
      .slice(0, 3);
    return scored;
  }

  function saveFinalizedConclusion() {
    return new Promise((resolve) => {
      socCopilotStorageGet(
        [STORAGE_KEYS.conclusionsHistory, STORAGE_KEYS.belZorBalance, STORAGE_KEYS.belZorLog],
        (data) => {
          const history = data[STORAGE_KEYS.conclusionsHistory] || [];
          history.unshift({
            url: location.href,
            title: state.fields.title || "(без заголовка)",
            platform: state.activeAdapter?.name,
            verdict: state.conclusionDraft.verdict,
            date: new Date().toISOString(),
            iocs: Object.values(state.iocMap || {}).flat(),
            techniques: (state.mitreTechniques || []).map((t) => t.id)
          });
          const trimmed = history.slice(0, 200); // ограничиваем размер локальной истории
          state.conclusionsHistory = trimmed;

          // BelZor начисляется один раз за карточку — защита от повторного начисления,
          // если аналитик несколько раз пересохраняет заключение по тому же инциденту.
          const belZorLog = data[STORAGE_KEYS.belZorLog] || [];
          const alreadyAwarded = belZorLog.some((e) => e.url === location.href);
          let awardInfo = null;
          let newBalance = data[STORAGE_KEYS.belZorBalance] || 0;
          let newBelZorLog = belZorLog;

          if (!alreadyAwarded) {
            const totalSteps = state.checkedSteps.length;
            const completedSteps = state.checkedSteps.filter(Boolean).length;
            const ratio = totalSteps > 0 ? completedSteps / totalSteps : 0;
            const award = socCopilotComputeBelZor({
              severityText: state.fields.severity,
              riskScore: state.riskScore,
              mitreCount: state.mitreTechniques.length,
              playbookCompleteRatio: ratio,
              hasVerifiedEnrichment: !!state.anyEnrichmentVerified
            });
            const prevRank = socCopilotBelZorRank(newBalance);
            newBalance += award.total;
            const newRank = socCopilotBelZorRank(newBalance);
            newBelZorLog = [
              { url: location.href, title: state.fields.title || "(без заголовка)", date: new Date().toISOString(), amount: award.total, tier: award.tier },
              ...belZorLog
            ].slice(0, 500);
            awardInfo = { ...award, rankedUp: newRank.name !== prevRank.name, newRank };
            state.belZorBalance = newBalance;
            state.belZorLog = newBelZorLog;
          }

          socCopilotStorageSet(
            {
              [STORAGE_KEYS.conclusionsHistory]: trimmed,
              [STORAGE_KEYS.belZorBalance]: newBalance,
              [STORAGE_KEYS.belZorLog]: newBelZorLog
            },
            () => resolve(awardInfo)
          );
        }
      );
    });
  }

  function registerTabForCorrelation() {
    socCopilotSendMessage({
      type: "socCopilotRegisterTab",
      url: location.href,
      title: state.fields.title || document.title,
      iocs: Object.values(state.iocMap || {}).flat(),
      techniques: (state.mitreTechniques || []).map((t) => t.id)
    });
    socCopilotSendMessage(
      {
        type: "socCopilotGetRelatedTabs",
        iocs: Object.values(state.iocMap || {}).flat(),
        techniques: (state.mitreTechniques || []).map((t) => t.id)
      },
      (resp) => {
        state.relatedOpenTabs = Array.isArray(resp) ? resp : [];
        if (state.panelOpen) render();
      }
    );
  }

  // Простая эвристическая оценка приоритета вкладки для бейджа на иконке.
  // Не претендует на точность реального risk-scoring — это ориентир "стоит ли открыть это первым".
  function computeRiskBadge() {
    const iocCount = socCopilotCountIOCs(state.iocMap);
    const tacticIdx = Math.max(
      -1,
      ...state.mitreTechniques.map((t) => SOC_COPILOT_TACTIC_ORDER.findIndex((x) => x.id === t.tacticId))
    );
    const score = iocCount + state.mitreTechniques.length * 2 + Math.max(0, tacticIdx);
    state.riskScore = score;
    let text = "";
    let color = "#6366f1";
    if (score >= 12) {
      text = "!!!";
      color = "#dc2626";
    } else if (score >= 6) {
      text = "!!";
      color = "#f59e0b";
    } else if (score >= 1) {
      text = "!";
      color = "#334155";
    }
    socCopilotSendMessage({ type: "socCopilotSetBadge", text, color });
  }

  // Логируем "событие" один раз на уникальный URL карточки — счётчик "обработанных
  // событий" отражает количество разных карточек, а не число перезагрузок одной и той же.
  function logEventOnce() {
    const key = urlKey();
    if (state.eventsLog.some((e) => e.urlKey === key)) return;
    const entry = { urlKey: key, date: new Date().toISOString(), title: state.fields.title || document.title, platform: state.activeAdapter?.name };
    state.eventsLog.push(entry);
    if (state.eventsLog.length > 5000) state.eventsLog = state.eventsLog.slice(-5000);
    socCopilotStorageSet({ [STORAGE_KEYS.eventsLog]: state.eventsLog });
  }

  // Подсветка найденных IOC прямо в тексте карточки. Best-effort: ограничено по
  // числу текстовых узлов ради производительности на больших DOM-деревьях порталов,
  // может не работать в SPA с активным перерендером (см. CHANGELOG 0.4.0).
  const MAX_HIGHLIGHT_NODES = 800;

  function highlightIOCsOnPage() {
    const values = Object.values(state.iocMap || {}).flat();
    if (!values.length) return;
    const rawSel = state.activeAdapter?.selectors?.rawContainer || state.activeAdapter?.selectors?.description;
    let root = null;
    try {
      root = rawSel ? document.querySelector(rawSel) : null;
    } catch {
      root = null;
    }
    root = root || document.body;

    const escapedValues = values
      .map((v) => v.replace(/[.*+?^${}()|[\]\\]/g, "\\$&"))
      .sort((a, b) => b.length - a.length); // длинные совпадения в приоритете
    const regex = new RegExp("(" + escapedValues.join("|") + ")", "g");

    const walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT, {
      acceptNode(node) {
        if (!node.nodeValue || !node.nodeValue.trim()) return NodeFilter.FILTER_REJECT;
        const parentTag = node.parentElement?.tagName;
        if (["SCRIPT", "STYLE", "TEXTAREA", "INPUT", "MARK"].includes(parentTag)) return NodeFilter.FILTER_REJECT;
        return NodeFilter.FILTER_ACCEPT;
      }
    });

    const nodes = [];
    let n;
    while ((n = walker.nextNode()) && nodes.length < MAX_HIGHLIGHT_NODES) nodes.push(n);

    nodes.forEach((node) => {
      regex.lastIndex = 0;
      if (!regex.test(node.nodeValue)) return;
      regex.lastIndex = 0;
      const frag = document.createDocumentFragment();
      let lastIndex = 0;
      let m;
      while ((m = regex.exec(node.nodeValue))) {
        if (m.index > lastIndex) frag.appendChild(document.createTextNode(node.nodeValue.slice(lastIndex, m.index)));
        const mark = document.createElement("mark");
        mark.dataset.socCopilotMark = "1";
        mark.style.cssText = "background:#fbbf24;color:#111;padding:0 2px;border-radius:2px;";
        mark.textContent = m[0];
        frag.appendChild(mark);
        lastIndex = m.index + m[0].length;
      }
      frag.appendChild(document.createTextNode(node.nodeValue.slice(lastIndex)));
      node.parentNode.replaceChild(frag, node);
    });
  }

  function removeIOCHighlights() {
    document.querySelectorAll("mark[data-soc-copilot-mark]").forEach((mark) => {
      const parent = mark.parentNode;
      if (!parent) return;
      parent.replaceChild(document.createTextNode(mark.textContent), mark);
      parent.normalize();
    });
  }

  // --- Spotlight-подсветка для наставника: указываем на реальный элемент на странице ---
  let spotlightEl = null;
  let spotlightReposition = null;

  function showSpotlight(selector) {
    removeSpotlight();
    if (!selector) return false;
    let target = null;
    try {
      target = document.querySelector(selector);
    } catch {
      target = null;
    }
    if (!target) return false;

    spotlightEl = document.createElement("div");
    spotlightEl.dataset.socCopilotSpotlight = "1";
    spotlightEl.style.cssText =
      "position:fixed; z-index:2147483003; pointer-events:none; border:3px solid #fbbf24; " +
      "border-radius:6px; box-shadow:0 0 0 9999px rgba(0,0,0,.55); transition: top .2s, left .2s, width .2s, height .2s;";
    document.body.appendChild(spotlightEl);

    const reposition = () => {
      if (!spotlightEl || !document.body.contains(target)) {
        removeSpotlight();
        return;
      }
      const rect = target.getBoundingClientRect();
      spotlightEl.style.top = rect.top - 6 + "px";
      spotlightEl.style.left = rect.left - 6 + "px";
      spotlightEl.style.width = rect.width + 12 + "px";
      spotlightEl.style.height = rect.height + 12 + "px";
    };
    reposition();
    target.scrollIntoView({ behavior: "smooth", block: "center" });
    window.addEventListener("scroll", reposition, true);
    window.addEventListener("resize", reposition);
    spotlightReposition = reposition;
    return true;
  }

  function removeSpotlight() {
    if (spotlightReposition) {
      window.removeEventListener("scroll", spotlightReposition, true);
      window.removeEventListener("resize", spotlightReposition);
      spotlightReposition = null;
    }
    if (spotlightEl) {
      spotlightEl.remove();
      spotlightEl = null;
    }
  }

  function textOf(selector) {
    if (!selector) return "";
    try {
      const el = document.querySelector(selector);
      return el ? el.innerText.trim() : "";
    } catch {
      return "";
    }
  }

  function extractFields(adapter) {
    const sel = adapter.selectors || {};
    const fields = {
      title: textOf(sel.title),
      description: textOf(sel.description),
      severity: textOf(sel.severity),
      status: textOf(sel.status),
      assignee: textOf(sel.assignee),
      assets: textOf(sel.assets),
      timeline: textOf(sel.timeline)
    };
    // Текст для поиска IOC: раскладка raw-контейнера, либо всё, что нашли + fallback на body
    let rawText = textOf(sel.rawContainer);
    if (!rawText) {
      rawText = [fields.title, fields.description, fields.timeline].filter(Boolean).join("\n");
    }
    if (!rawText) rawText = document.body.innerText.slice(0, 20000); // ограничим на всякий случай
    fields.rawText = rawText;
    return fields;
  }

  function refresh() {
    state.activeAdapter = socCopilotResolveAdapter(state.adapters, location.href);
    if (!state.activeAdapter) return false;
    state.fields = extractFields(state.activeAdapter);
    state.iocMap = socCopilotExtractIOCs(state.fields.rawText);
    state.playbook = socCopilotPickPlaybook(state.playbooks, state.fields.rawText);
    if (!state.checkedSteps.length && state.playbook) {
      state.checkedSteps = new Array(state.playbook.steps.length).fill(false);
    }
    state.mitreTechniques = socCopilotDetectTechniques(state.fields.rawText);
    state.mitrePredictions = socCopilotPredictNextSteps(state.mitreTechniques.map((t) => t.id));
    state.killChain = socCopilotKillChainProgress(state.mitreTechniques);
    state.similarIncidents = findSimilarIncidents();
    registerTabForCorrelation();
    computeRiskBadge();
    logEventOnce();
    state.mentorSteps = socCopilotBuildMentorSteps({
      fields: state.fields,
      iocMap: state.iocMap,
      playbook: state.playbook,
      mitreTechniques: state.mitreTechniques,
      tacticOrder: SOC_COPILOT_TACTIC_ORDER
    });
    state.mentorStepIndex = 0;
    state.mentorAnswered = {};

    // Снапшот полей для диффа "что изменилось, пока вкладка была неактивна" —
    // берём только при первом заходе на карточку в этой сессии, не перезаписываем
    // при каждом refresh() (иначе дифф никогда не покажет реальных изменений).
    if (!state.fieldSnapshot) {
      state.fieldSnapshot = socCopilotSnapshotFields(state.fields);
    }

    // Alert storm: массовые однотипные события за последний час — считаем не
    // на каждый refresh (дорого при частых пересчётах), а держим в state, обновляем
    // вместе с остальным контекстом карточки.
    state.alertStorms = socCopilotDetectAlertStorm(state.eventsLog);

    return true;
  }

  // ---------- UI: боковая панель в Shadow DOM ----------
  let shadowHost, shadowRoot, panelEl;

  const SOC_COPILOT_RTL_LANGUAGES = new Set(["ar", "ur", "fa"]);

  function applyThemeClasses() {
    if (!shadowHost) return;
    shadowHost.className = ""; // сброс перед применением текущей темы
    if (state.uiTheme === "light") shadowHost.classList.add("sc-theme-light");
    else if (state.uiTheme === "contrast") shadowHost.classList.add("sc-theme-contrast");
    // "dark" — тема по умолчанию, класс не нужен (базовые правила CSS уже её задают)
  }

  // Вызывается при первом создании панели (после того, как panelEl уже существует)
  // и при обновлении настроек — применяет и цветовую тему, и направление текста.
  function applyTheme() {
    applyThemeClasses();
    applyTextDirection();
  }

  // RTL: dir="rtl" на .sc-panel заставляет flexbox-раскладку (flex-direction: row)
  // естественно отзеркалиться по спецификации CSS Flexbox — большая часть UI
  // переворачивается без дополнительного CSS. Точечные исключения (иконки, canvas
  // графа) не переворачиваются намеренно — это не текстовые элементы.
  function applyTextDirection() {
    if (!panelEl) return;
    const isRtl = SOC_COPILOT_RTL_LANGUAGES.has(state.uiLanguage);
    panelEl.dir = isRtl ? "rtl" : "ltr";
    panelEl.classList.toggle("sc-rtl", isRtl);
  }

  function ensurePanel() {
    if (shadowHost) return;
    shadowHost = document.createElement("div");
    shadowHost.id = "soc-copilot-host";
    applyThemeClasses();
    document.documentElement.appendChild(shadowHost);
    shadowRoot = shadowHost.attachShadow({ mode: "open" });

    const style = document.createElement("style");
    style.textContent = SOC_COPILOT_PANEL_CSS;
    shadowRoot.appendChild(style);

    panelEl = document.createElement("div");
    panelEl.className = "sc-panel sc-hidden";
    shadowRoot.appendChild(panelEl);
    applyTextDirection();

    const toggle = document.createElement("button");
    toggle.className = "sc-toggle";
    toggle.textContent = "BR";
    toggle.title = "Belyaev Response";
    toggle.addEventListener("click", () => togglePanel());
    shadowRoot.appendChild(toggle);
  }

  function togglePanel(force) {
    state.panelOpen = typeof force === "boolean" ? force : !state.panelOpen;
    panelEl.classList.toggle("sc-hidden", !state.panelOpen);
    if (state.panelOpen) {
      render();
      maybeShowBurnoutReminder();
    } else {
      removeSpotlight();
    }
  }

  function maybeShowBurnoutReminder() {
    if (state.burnoutShownThisSession) return;
    socCopilotStorageGet(
      ["socCopilotBurnoutCheckEnabled", "socCopilotLastBurnoutSnapshot"],
      (data) => {
        if (data.socCopilotBurnoutCheckEnabled === false) return;
        const signal = socCopilotCheckBurnoutSignals({
          quizHistory: state.quizLog,
          eventsLog: state.eventsLog,
          conclusionsHistory: state.conclusionsHistory,
          lastBurnoutSnapshot: data.socCopilotLastBurnoutSnapshot || null
        });
        if (!signal) return;
        state.burnoutShownThisSession = true;
        if (signal.type === "warning" && signal.snapshot) {
          socCopilotStorageSet({ socCopilotLastBurnoutSnapshot: signal.snapshot });
        } else if (signal.type === "recovery") {
          socCopilotStorageRemove("socCopilotLastBurnoutSnapshot");
        }
        showBurnoutToast(signal.message, signal.type);
      }
    );
  }

  function showBurnoutToast(message, type) {
    ensurePanel();
    const toast = document.createElement("div");
    toast.className = "sc-ask-toast sc-burnout-toast" + (type === "recovery" ? " sc-burnout-recovery" : "");
    toast.textContent = (type === "recovery" ? "💛 " : "💙 ") + message;
    shadowRoot.appendChild(toast);
    setTimeout(() => toast.classList.add("sc-show"), 10);
    setTimeout(() => {
      toast.classList.remove("sc-show");
      setTimeout(() => toast.remove(), 300);
    }, 15000);
  }

  function relatedTabsHTML() {
    if (!state.relatedOpenTabs.length) return "";
    return `
      <div class="sc-section-title">Связанные открытые вкладки (эта сессия)</div>
      ${state.relatedOpenTabs
        .map(
          (t) => `<div class="sc-similar-row"><span title="${escapeAttr(t.title || "")}">${escapeHtml((t.title || "").slice(0, 40))}</span><span class="sc-muted">пересечение: ${t.score}</span></div>`
        )
        .join("")}
    `;
  }

  function alertStormBannerHTML() {
    if (!state.alertStorms.length) return "";
    return state.alertStorms
      .map(
        (s) => `
      <div class="sc-storm-banner">
        ⚡ Похоже на массовое срабатывание: <b>${s.count}</b> однотипных событий за последний час
        («${escapeHtml(s.pattern)}»). Возможно, стоит разобрать одну причину и закрыть массово,
        а не по одной карточке.
      </div>`
      )
      .join("");
  }

  function iocListHTML() {
    const entries = Object.entries(state.iocMap);
    if (!entries.length) return alertStormBannerHTML() + `<p class="sc-muted">IOC не обнаружены на странице.</p>`;
    return (
      alertStormBannerHTML() +
      entries
        .map(
          ([type, values]) => `
        <div class="sc-ioc-group">
          <div class="sc-ioc-type">${type} (${values.length})</div>
          ${values
            .map(
              (v) => `
            <div class="sc-ioc-row">
              <code>${escapeHtml(v)}</code>
              <div class="sc-ioc-actions">
                <button data-copy="${escapeAttr(v)}" title="Скопировать в буфер обмена">${T("btnCopy")}</button>
                ${socCopilotEnrichButtonHTML(type, v)}
                ${socCopilotSnippetsButtonHTML(type, v)}
              </div>
              <span class="sc-enrich-result" data-for="${escapeAttr(v)}"></span>
              <div class="sc-snippets-panel" data-snippets-for="${escapeAttr(v)}"></div>
            </div>`
            )
            .join("")}
        </div>`
        )
        .join("")
    );
  }

  function socCopilotSnippetsButtonHTML(type, value) {
    const snippetType = ["md5", "sha1", "sha256"].includes(type) ? "hash" : type;
    if (!["ipv4", "ipv6", "domain", "url", "hash"].includes(snippetType)) return "";
    return `<button data-snippets="${escapeAttr(value)}" data-snippet-type="${snippetType}">команды блокировки</button>`;
  }

  function socCopilotEnrichButtonHTML(type, value) {
    if (["ipv4", "ipv6", "domain", "url"].includes(type)) {
      return `<button data-enrich="${escapeAttr(value)}" data-ioctype="${type}" title="Проверить в VirusTotal/AbuseIPDB">${T("btnCheck")}</button>`;
    }
    if (["md5", "sha1", "sha256"].includes(type)) {
      return `<button data-enrich="${escapeAttr(value)}" data-ioctype="hash">${T("btnCheck")}</button>`;
    }
    return "";
  }

  function T(key) {
    return socCopilotT(key, state.uiLanguage || "ru");
  }

  function escapeHtml(s) {
    return s.replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
  }
  function escapeAttr(s) {
    return escapeHtml(s);
  }

  function killChainHTML() {
    return `<div class="sc-killchain">${state.killChain
      .map(
        (t) => `<span class="sc-kc-pill ${t.observed ? "sc-kc-hit" : ""}" title="${escapeHtml(t.name)}">${escapeHtml(t.name)}</span>`
      )
      .join("")}</div>`;
  }

  function techniquesHTML() {
    if (!state.mitreTechniques.length) {
      return `<p class="sc-muted">Техники ATT&CK не распознаны по тексту карточки (курируемый набор ~25 техник, см. настройки для расширения базы).</p>`;
    }
    return state.mitreTechniques
      .map(
        (t) => `
      <div class="sc-technique">
        <a href="${escapeAttr(t.url)}" target="_blank" rel="noopener">${t.id}</a>
        <b>${escapeHtml(t.name)}</b>
        <span class="sc-tactic-tag">${escapeHtml(t.tacticName)}</span>
      </div>`
      )
      .join("");
  }

  function predictionsHTML() {
    if (!state.mitrePredictions.length) {
      return `<p class="sc-muted">Недостаточно данных для прогноза - нет распознанных техник ATT&CK.</p>`;
    }
    return state.mitrePredictions
      .map(
        (p) => `
      <div class="sc-predict-card">
        <div class="sc-predict-head">
          <a href="${escapeAttr(p.url)}" target="_blank" rel="noopener">${p.id}</a>
          <b>${escapeHtml(p.name)}</b>
        </div>
        <div class="sc-predict-meta">
          Тактика: ${escapeHtml(p.tacticName)} ·
          <span class="sc-conf sc-conf-${p.confidence}">${p.confidence === "curated" ? "по типовой связке" : "по позиции в kill chain"}</span>
        </div>
      </div>`
      )
      .join("");
  }

  function similarIncidentsHTML() {
    if (!state.similarIncidents.length) return "";
    const verdictShort = { tp: "TP", fp: "FP", benign: "Benign", escalate: "Эскалация" };
    return `
      <div class="sc-section-title">Похожие завершённые инциденты</div>
      ${state.similarIncidents
        .map(
          (h) => `
        <div class="sc-similar-row">
          <a href="${escapeAttr(h.url)}" target="_blank" rel="noopener">${escapeHtml((h.title || "").slice(0, 40))}</a>
          <span class="sc-verdict-badge sc-verdict-${h.verdict}">${verdictShort[h.verdict] || h.verdict || "?"}</span>
          <span class="sc-muted">${new Date(h.date).toLocaleDateString("ru-RU")}</span>
        </div>`
        )
        .join("")}
    `;
  }

  function broadcastButtonsHTML() {
    const labels = { slack: "Slack/Mattermost", telegram: "Telegram", max: "MAX", teams: "Teams", jira: "Jira" };
    const anyChannel = Object.values(state.notifyChannels).some(Boolean);
    const buttons = Object.entries(state.notifyChannels)
      .filter(([, on]) => on)
      .map(([ch]) => `<button class="sc-conclusion-broadcast-btn" data-channel="${ch}">Отправить в ${labels[ch]} <span class="sc-pro-badge">PRO</span></button>`)
      .join("");
    const secondOpinionBtn = anyChannel
      ? `<button class="sc-second-opinion-btn">🤝 Запросить второе мнение</button>`
      : "";
    return buttons + secondOpinionBtn;
  }

  function glossaryTabHTML() {
    const termsHtml = state.glossaryTerms.length
      ? state.glossaryTerms
          .map(
            (t) => `
        <div class="sc-glossary-term">
          <div class="sc-glossary-head">
            <b>${escapeHtml(t.term)}</b>
            ${t.platformContext ? `<span class="sc-tactic-tag">${escapeHtml(t.platformContext)}</span>` : ""}
          </div>
          <p class="sc-glossary-def">${escapeHtml(t.definition)}</p>
          <div class="sc-glossary-meta">
            <span class="sc-muted">от ${escapeHtml(t.submittedBy)}</span>
            <button class="sc-glossary-vote" data-vote-id="${escapeAttr(t.id)}" data-vote-dir="up">👍 ${t.upvotes}</button>
            <button class="sc-glossary-vote" data-vote-id="${escapeAttr(t.id)}" data-vote-dir="down">👎 ${t.downvotes}</button>
          </div>
        </div>`
          )
          .join("")
      : `<p class="sc-muted">Список пуст или ещё не загружен - нажмите «Обновить». Требуется активная лицензия.</p>`;

    return `
      <p class="sc-hint-inline">Community-словарь терминов конкретных SIEM (что означает то или иное поле/правило) - общий для всех организаций с лицензией. Голосуйте за полезные определения. <span class="sc-pro-badge">PRO</span></p>
      <button class="sc-glossary-refresh-btn" title="Загрузить термины глоссария с сервера">Обновить список</button>
      <div class="sc-glossary-list">${termsHtml}</div>

      <div class="sc-section-title">Добавить термин</div>
      <input type="text" class="sc-glossary-input" data-glossary-field="term" placeholder="Термин (например: 'Инцидент-корреляция')" maxlength="128" />
      <input type="text" class="sc-glossary-input" data-glossary-field="platformContext" placeholder="Платформа (необязательно, например: MaxPatrol SIEM)" maxlength="64" />
      <textarea class="sc-glossary-input" data-glossary-field="definition" rows="3" placeholder="Определение" maxlength="2000"></textarea>
      <button class="sc-glossary-submit-btn">Добавить термин</button>
    `;
  }

  function statsTabHTML() {
    const rank = socCopilotBelZorRank(state.belZorBalance);
    const nextRank = socCopilotBelZorNextRank(state.belZorBalance);
    const period = SOC_COPILOT_PERIODS.find((p) => p.id === state.statsPeriod) || SOC_COPILOT_PERIODS[0];
    const agg = socCopilotAggregateStats(state.eventsLog, state.conclusionsHistory, state.belZorLog, period.days);

    const periodButtons = SOC_COPILOT_PERIODS.map(
      (p) => `<button class="sc-stats-period-btn ${p.id === state.statsPeriod ? "sc-active" : ""}" data-period="${p.id}">${p.label}</button>`
    ).join("");

    const verdictLabels = { tp: "True Positive", fp: "False Positive", benign: "Benign", escalate: "Эскалация", unset: "без вердикта" };
    const verdictRows = Object.entries(agg.byVerdict)
      .filter(([, count]) => count > 0)
      .map(([k, count]) => `<div class="sc-stats-row"><span>${escapeHtml(verdictLabels[k])}</span><b>${count}</b></div>`)
      .join("") || `<p class="sc-muted">Нет завершённых инцидентов за период.</p>`;

    return `
      <div class="sc-belzor-card">
        <div class="sc-belzor-balance">${rank.emoji} ${state.belZorBalance} BelZor</div>
        <div class="sc-belzor-rank">Ранг: <b>${escapeHtml(rank.name)}</b>${nextRank ? ` - до «${escapeHtml(nextRank.name)}»: ${nextRank.min - state.belZorBalance} BelZor` : " - максимальный ранг"}</div>
        <p class="sc-hint-inline" style="margin-top:6px">
          BelZor - внутренняя валюта признания за работу SOC-аналитика. Начисляется за каждый
          закрытый инцидент (Critical: 50, High: 30, Medium: 15, Low: 5) плюс бонусы за
          качество: применение MITRE-контекста, полный плейбук, проверку IOC через TI.
          Рейтинг видят коллеги в Grafana (в псевдонимах) - это честная, прозрачная
          оценка вклада каждого, без слежки за личными данными.
        </p>
      </div>

      <div class="sc-section-title">Счётчики (всё время)</div>
      <div class="sc-stats-row"><span>Обработано событий (уникальных карточек)</span><b>${state.eventsLog.length}</b></div>
      <div class="sc-stats-row"><span>Закрыто инцидентов (с заключением)</span><b>${state.conclusionsHistory.length}</b></div>

      <div class="sc-section-title">Отчёт за период</div>
      <div class="sc-stats-periods">${periodButtons}</div>
      <div class="sc-stats-row"><span>Событий за период</span><b>${agg.eventsCount}</b></div>
      <div class="sc-stats-row"><span>Закрыто инцидентов за период</span><b>${agg.incidentsCount}</b></div>
      <div class="sc-stats-row"><span>Заработано BelZor за период</span><b>${agg.belZorEarned}</b></div>
      <div class="sc-section-title">Разбивка по вердиктам за период</div>
      ${verdictRows}

      <button class="sc-stats-export-btn">Экспортировать отчёт (CSV)</button>
      <p class="sc-hint-inline">Все данные - только по этому браузеру, не агрегация по всей команде SOC.</p>

      <div class="sc-section-title">Граф кампании</div>
      <p class="sc-hint-inline">Связи между закрытыми инцидентами по общим IOC/техникам - возможно, это не разрозненные срабатывания, а одна кампания. Клик по узлу открывает инцидент.</p>
      <canvas class="sc-campaign-canvas" width="320" height="260"></canvas>
      <div class="sc-campaign-empty sc-muted"></div>
    `;
  }

  function mentorTrackSwitcherHTML() {
    const tracks = [
      ["l1", "L1 - Разбор инцидента"],
      ["l2", "L2 - Форензика/СЗИ"],
      ["l3", "L3 - Хантинг/эскалация"]
    ];
    return `
      <div class="sc-mentor-track-switch">
        ${tracks
          .map(
            ([id, label]) =>
              `<button class="sc-mentor-track-btn ${state.mentorTrack === id ? "sc-active" : ""}" data-track="${id}">${label}</button>`
          )
          .join("")}
      </div>`;
  }

  function mentorL2ContentHTML() {
    const techIds = (state.mitreTechniques || []).map((t) => t.id);
    const tacticIds = (state.mitreTechniques || []).map((t) => t.tacticId);
    const tools = socCopilotRecommendDFIRTools(techIds);
    const sziRecs = socCopilotGetSZIRecommendations(tacticIds);
    const osKey = state.selectedOS || "windows";
    const osData = socCopilotGetDFIRByOS(osKey);

    return `
      <p class="sc-hint-inline">Рекомендации подобраны под техники ATT&CK из этой карточки.
      Выберите ОС для команд форензики:</p>
      <div class="sc-os-selector">
        ${["windows","linux","mac","astra"].map((os) => {
          const labels = {windows:"Windows",linux:"Linux",mac:"macOS",astra:"AstraLinux"};
          return `<button class="sc-os-btn${os === osKey ? " sc-os-active" : ""}" data-os="${os}">${labels[os]}</button>`;
        }).join("")}
      </div>

      <div class="sc-section-title">Команды сбора артефактов: ${escapeHtml(osData.label)}</div>
      ${osData.sections.map((sec) => `
        <details class="sc-dfir-quickstart">
          <summary>${escapeHtml(sec.title)}</summary>
          ${sec.commands ? `<ol>${sec.commands.map((c) => `<li><code>${escapeHtml(c)}</code></li>`).join("")}</ol>` : ""}
          ${sec.links ? sec.links.map((l) => `<a href="${escapeAttr(l.url)}" target="_blank" rel="noopener">${escapeHtml(l.name)}</a><br>`).join("") : ""}
        </details>`).join("")}

      <div class="sc-section-title">Инструменты форензики (по типу атаки)</div>
      ${tools
        .map(
          (t) => `
        <div class="sc-dfir-tool">
          <div class="sc-dfir-tool-head">
            <a href="${t.officialUrl}" target="_blank" rel="noopener">${escapeHtml(t.name)}</a>
            <span class="sc-tactic-tag">${escapeHtml(t.categoryName)}</span>
          </div>
          <p class="sc-dfir-tool-desc">${escapeHtml(t.description)}</p>
          <p class="sc-dfir-tool-license">Лицензия: ${escapeHtml(t.license)}</p>
          <details class="sc-dfir-quickstart">
            <summary>Быстрый старт</summary>
            <ol>${t.quickStart.map((s) => `<li>${escapeHtml(s)}</li>`).join("")}</ol>
          </details>
        </div>`
        )
        .join("")}

      <div class="sc-section-title">Нейтрализация на СЗИ</div>
      ${
        sziRecs.length
          ? sziRecs.map((r) => `<div class="sc-szi-rec"><b>${escapeHtml(r.sziClass)}:</b> ${escapeHtml(r.action)}</div>`).join("")
          : `<p class="sc-muted">Нет распознанных тактик ATT&CK для подбора рекомендаций - см. вкладку «MITRE».</p>`
      }
      <p class="sc-hint-inline">Это типовые действия для класса СЗИ, не инструкция под конкретный вендор - сверяйтесь с документацией продукта в вашей инфраструктуре.</p>
    `;
  }

  function mentorL3ContentHTML() {
    const draftBtn = `<button class="sc-gossopka-draft-btn">Подготовить черновик карточки для НКЦКИ</button>`;
    return `
      ${mentorL2ContentHTML()}

      <div class="sc-section-title">Threat Hunting и эскалация</div>
      <ul class="sc-l3-list">
        <li>Проверьте вкладку IOC → «Связанные открытые вкладки» - нет ли признаков той же кампании в других инцидентах за смену.</li>
        <li>Проверьте вкладку «Заключение» → «Похожие завершённые инциденты» - не встречался ли этот IOC/техника раньше.</li>
        <li>Критерии эскалации во внешнюю форензик-лабораторию: подтверждённая компрометация домена/AD, масштаб &gt; нескольких критичных хостов, признаки APT (длительное присутствие, целевой инструментарий), либо когда объём работы превышает возможности команды по времени реагирования.</li>
        <li>Критерии информирования руководства: подтверждённый инцидент с воздействием на бизнес-процессы, утечка данных, требование по 187-ФЗ/приказам ФСБ для субъектов КИИ.</li>
      </ul>

      <div class="sc-section-title">ГосСОПКА / НКЦКИ (справочно)</div>
      <p class="sc-hint-inline">
        У НКЦКИ нет публичного API для сторонних инструментов - карточки подаются через
        личный кабинет вашей организации (доступ выдаётся после заключения регламента
        взаимодействия, info@cert.gov.ru) или через дежурную смену вашего центра ГосСОПКА.
        Приказ ФСБ №161 регулирует аккредитацию ЦЕНТРОВ ГосСОПКА (не отдельных инструментов) —
        направления аккредитации: ${SOC_COPILOT_161_ACCREDITATION_DIRECTIONS.map(escapeHtml).join("; ")}.
      </p>
      ${draftBtn}
      <a href="${SOC_COPILOT_GOSSOPKA_LINKS.officialSite}" target="_blank" rel="noopener" class="sc-gossopka-link">Официальный сайт gossopka.ru →</a>
      <pre class="sc-gossopka-draft-preview"></pre>
    `;
  }

  function mentorTabHTML() {
    if (!state.mentorSteps.length) {
      return `<p class="sc-muted">Наставник доступен, когда открыта карточка инцидента с распознанным адаптером.</p>`;
    }
    if (state.mentorTrack === "l2") return mentorTrackSwitcherHTML() + mentorL2ContentHTML();
    if (state.mentorTrack === "l3") return mentorTrackSwitcherHTML() + mentorL3ContentHTML();

    const idx = state.mentorStepIndex;
    const step = state.mentorSteps[idx];
    const answered = state.mentorAnswered[step.id];
    const level = socCopilotMentorLevel(state.mentorProgress.correct);
    const nextLevel = socCopilotMentorNextLevel(state.mentorProgress.correct);

    const progressLine = `
      <div class="sc-mentor-progress">
        Уровень: <b>${escapeHtml(level.name)}</b>
        ${nextLevel ? ` · до «${escapeHtml(nextLevel.name)}»: ${nextLevel.min - state.mentorProgress.correct} верных ответов` : " · максимальный уровень для этого трека"}
        <br/>Всего верных ответов: ${state.mentorProgress.correct} из ${state.mentorProgress.total}
      </div>`;

    const dots = state.mentorSteps
      .map((s, i) => `<span class="sc-mentor-dot ${i === idx ? "sc-mentor-dot-active" : ""} ${state.mentorAnswered[s.id] ? "sc-mentor-dot-done" : ""}"></span>`)
      .join("");

    let quizHTML = "";
    if (step.quiz) {
      if (!answered) {
        quizHTML = `
          <div class="sc-mentor-quiz">
            <p><b>${escapeHtml(step.quiz.question)}</b></p>
            ${step.quiz.options
              .map((opt, i) => `<button class="sc-mentor-quiz-option" data-quiz-index="${i}">${escapeHtml(opt)}</button>`)
              .join("")}
          </div>`;
      } else {
        const correct = answered.correct;
        quizHTML = `
          <div class="sc-mentor-quiz-result ${correct ? "sc-mentor-correct" : "sc-mentor-incorrect"}">
            ${correct ? "✅ Верно!" : "❌ Не совсем"} ${escapeHtml(step.quiz.explain)}
          </div>`;
      }
    } else if (step.reflection) {
      quizHTML = `
        <div class="sc-mentor-reflection">
          <p class="sc-mentor-reflection-q">💭 ${escapeHtml(step.reflection)}</p>
          <textarea class="sc-mentor-reflection-input" rows="2" placeholder="Запиши свою мысль (необязательно, видно только тебе)">${escapeHtml(state.mentorAnswered[step.id]?.note || "")}</textarea>
        </div>`;
    }

    return `
      ${mentorTrackSwitcherHTML()}
      ${progressLine}
      <div class="sc-mentor-dots">${dots}</div>
      <div class="sc-mentor-step">
        <div class="sc-mentor-step-title">Шаг ${idx + 1} из ${state.mentorSteps.length}: ${escapeHtml(step.title)}</div>
        <p class="sc-mentor-explain">${escapeHtml(step.explain)}</p>
        ${quizHTML}
      </div>
      <div class="sc-mentor-nav">
        <button class="sc-mentor-prev" ${idx === 0 ? "disabled" : ""}>← Назад</button>
        <button class="sc-mentor-next" ${idx === state.mentorSteps.length - 1 ? "disabled" : ""}>Дальше →</button>
      </div>
      <div class="sc-section-title">Спросить наставника (AI)</div>
      <p class="sc-hint-inline">Вопрос обезличивается перед отправкой (см. вкладку «Сводка»). Наставник отвечает наводящими вопросами, а не готовым решением - это часть обучения.</p>
      <textarea class="sc-mentor-ask-input" rows="2" placeholder="Например: почему это может быть ложным срабатыванием?"></textarea>
      <button class="sc-mentor-ask-btn">Спросить <span class="sc-pro-badge">PRO</span></button>
      <div class="sc-mentor-ask-redaction-preview"></div>
      <div class="sc-mentor-ask-output"></div>
    `;
  }

  function conclusionFormHTML() {
    const d = state.conclusionDraft;
    const verdictOptions = [
      ["tp", "True Positive"],
      ["fp", "False Positive"],
      ["benign", "Benign"],
      ["escalate", "Эскалация"]
    ];
    return `
      ${similarIncidentsHTML()}
      <div class="sc-section-title">Вердикт</div>
      <div class="sc-verdict-options">
        ${verdictOptions
          .map(
            ([val, label]) => `
          <label class="sc-verdict-option">
            <input type="radio" name="sc-verdict" value="${val}" ${d.verdict === val ? "checked" : ""}/> ${label}
          </label>`
          )
          .join("")}
      </div>
      <div class="sc-section-title">Причина / вектор атаки <button class="sc-voice-btn" data-voice-target="rootCause" title="Надиктовать">🎤</button></div>
      <textarea class="sc-conclusion-input" data-field="rootCause" rows="2" placeholder="Например: фишинговое письмо с вредоносным вложением">${escapeHtml(d.rootCause || "")}</textarea>
      <div class="sc-section-title">Воздействие <button class="sc-voice-btn" data-voice-target="impact" title="Надиктовать">🎤</button></div>
      <textarea class="sc-conclusion-input" data-field="impact" rows="2" placeholder="Затронутые системы/данные, ущерб">${escapeHtml(d.impact || "")}</textarea>
      <div class="sc-section-title">Предпринятые действия <button class="sc-voice-btn" data-voice-target="actionsTaken" title="Надиктовать">🎤</button></div>
      <textarea class="sc-conclusion-input" data-field="actionsTaken" rows="2" placeholder="Изоляция хоста, блокировка IOC, сброс пароля...">${escapeHtml(d.actionsTaken || "")}</textarea>
      <div class="sc-section-title">Рекомендации <button class="sc-voice-btn" data-voice-target="recommendations" title="Надиктовать">🎤</button></div>
      <textarea class="sc-conclusion-input" data-field="recommendations" rows="2" placeholder="Что сделать, чтобы избежать повторения">${escapeHtml(d.recommendations || "")}</textarea>
      <div class="sc-section-title">Формат</div>
      <select class="sc-conclusion-format">
        <option value="md">Markdown (.md)</option>
        <option value="txt">Простой текст (.txt)</option>
        <option value="html">HTML</option>
      </select>
      <button class="sc-conclusion-generate-btn" title="Сформировать текст заключения и скопировать в буфер">Сформировать и скопировать заключение</button>
      <button class="sc-conclusion-pdf-btn">Экспорт в PDF (печать) <span class="sc-pro-badge">PRO</span></button>
      <button class="sc-conclusion-save-btn">Сохранить как завершённое</button>
      ${broadcastButtonsHTML()}
      <pre class="sc-conclusion-preview"></pre>

      <div class="sc-section-title">Detection engineering</div>
      <p class="sc-hint-inline">Черновик правила по этому инциденту - чтобы такой же паттерн ловился автоматически. Требует ревью detection engineer перед внедрением.</p>
      <button class="sc-sigma-draft-btn" title="Сгенерировать черновик Sigma-правила из текущего инцидента">Черновик Sigma-правила</button>
      <button class="sc-yara-draft-btn" title="Сгенерировать черновик YARA-правила">Черновик YARA-правила</button>
      <pre class="sc-detection-draft-preview"></pre>
    `;
  }

  function playbookHTML() {
    if (!state.playbook) return "";
    return `
      <div class="sc-playbook">
        <div class="sc-playbook-title">${escapeHtml(state.playbook.name)}</div>
        ${state.playbook.steps
          .map(
            (step, i) => `
          <label class="sc-step">
            <input type="checkbox" data-step="${i}" ${state.checkedSteps[i] ? "checked" : ""}/>
            <span>${escapeHtml(step)}</span>
          </label>`
          )
          .join("")}
      </div>`;
  }

  function render() {
    if (!panelEl) return;
    const adapterName = state.activeAdapter ? state.activeAdapter.name : "не определена";
    const iocCount = socCopilotCountIOCs(state.iocMap);

    panelEl.innerHTML = `
      <div class="sc-header">
        <span>Belyaev Response</span>
        <button class="sc-highlight-toggle ${state.highlightOn ? "sc-active" : ""}" title="Подсветить IOC на странице">◎</button>
        <button class="sc-close" title="${T("btnClose")}">×</button>
      </div>
      <div class="sc-platform">${T("platformLabel")}: <b>${escapeHtml(adapterName)}</b> · IOC: <b>${iocCount}</b></div>
      <div class="sc-tabs">
        <button class="sc-tab-btn sc-active" data-tab="ioc">${T("tabIOC")}</button>
        <button class="sc-tab-btn" data-tab="summary">${T("tabSummary")}</button>
        <button class="sc-tab-btn" data-tab="mitre">${T("tabMitre")}</button>
        <button class="sc-tab-btn" data-tab="playbook">${T("tabPlaybook")}</button>
        <button class="sc-tab-btn" data-tab="report">${T("tabReport")}</button>
        <button class="sc-tab-btn" data-tab="conclusion">${T("tabConclusion")}</button>
        <button class="sc-tab-btn" data-tab="mentor">🎓 ${T("tabMentor")}</button>
        <button class="sc-tab-btn" data-tab="stats">📊 ${T("tabStats")}</button>
        <button class="sc-tab-btn" data-tab="glossary">📖 Глоссарий</button>
      </div>
      <div class="sc-tab-content" data-tab-content="ioc">${relatedTabsHTML()}${iocListHTML()}</div>
      <div class="sc-tab-content sc-hidden" data-tab-content="mitre">
        <div class="sc-section-title">Kill chain (обнаруженные тактики)</div>
        ${killChainHTML()}
        <div class="sc-section-title">Распознанные техники</div>
        ${techniquesHTML()}
        <div class="sc-section-title">Прогноз следующего шага <span class="sc-badge-beta">эвристика</span></div>
        <p class="sc-disclaimer">Гипотеза на основе типовой прогрессии атаки, не факт. Проверяйте перед действиями.</p>
        ${predictionsHTML()}
        <button class="sc-llm-predict-btn">✨ Уточнить прогноз через LLM <span class="sc-pro-badge">PRO</span></button>
        <div class="sc-llm-predict-redaction-preview"></div>
        <div class="sc-llm-predict-output"></div>
      </div>
      <div class="sc-tab-content sc-hidden" data-tab-content="summary">
        <div class="sc-field"><b>Заголовок:</b> ${escapeHtml(state.fields.title || "—")}</div>
        <div class="sc-field"><b>Критичность:</b> ${escapeHtml(state.fields.severity || "—")}</div>
        <div class="sc-field"><b>Статус:</b> ${escapeHtml(state.fields.status || "—")}</div>
        <div class="sc-field"><b>Активы:</b> ${escapeHtml(state.fields.assets || "—")}</div>
        <div class="sc-field"><b>Описание:</b><br/>${escapeHtml((state.fields.description || "—").slice(0, 600))}</div>
        <button class="sc-llm-btn">✨ Улучшить через LLM <span class="sc-pro-badge">PRO</span></button>
        <div class="sc-llm-redaction-preview"></div>
        <div class="sc-llm-output"></div>
      </div>
      <div class="sc-tab-content sc-hidden" data-tab-content="playbook">${playbookHTML()}</div>
      <div class="sc-tab-content sc-hidden" data-tab-content="report">
        <button class="sc-report-btn">Сформировать и скопировать отчёт</button>
        <pre class="sc-report-preview"></pre>
      </div>
      <div class="sc-tab-content sc-hidden" data-tab-content="conclusion">${conclusionFormHTML()}</div>
      <div class="sc-tab-content sc-hidden" data-tab-content="mentor">${mentorTabHTML()}</div>
      <div class="sc-tab-content sc-hidden" data-tab-content="stats">${statsTabHTML()}</div>
      <div class="sc-tab-content sc-hidden" data-tab-content="glossary">${glossaryTabHTML()}</div>
    `;

    panelEl.querySelector(".sc-close").addEventListener("click", () => togglePanel(false));
    panelEl.querySelector(".sc-highlight-toggle").addEventListener("click", () => {
      state.highlightOn = !state.highlightOn;
      if (state.highlightOn) highlightIOCsOnPage();
      else removeIOCHighlights();
      render();
    });

    panelEl.querySelectorAll(".sc-tab-btn").forEach((btn) =>
      btn.addEventListener("click", () => {
        panelEl.querySelectorAll(".sc-tab-btn").forEach((b) => b.classList.remove("sc-active"));
        btn.classList.add("sc-active");
        panelEl.querySelectorAll("[data-tab-content]").forEach((c) => c.classList.add("sc-hidden"));
        panelEl.querySelector(`[data-tab-content="${btn.dataset.tab}"]`).classList.remove("sc-hidden");
        if (btn.dataset.tab === "mentor") {
          spotlightCurrentMentorStep();
        } else {
          removeSpotlight();
        }
      })
    );

    panelEl.querySelectorAll("[data-copy]").forEach((btn) =>
      btn.addEventListener("click", () => navigator.clipboard.writeText(btn.dataset.copy))
    );

    panelEl.querySelectorAll("[data-step]").forEach((cb) =>
      cb.addEventListener("change", (e) => {
        state.checkedSteps[Number(e.target.dataset.step)] = e.target.checked;
        saveChecklist();
      })
    );

    panelEl.querySelectorAll("[data-enrich]").forEach((btn) =>
      btn.addEventListener("click", () => runEnrichment(btn.dataset.enrich, btn.dataset.ioctype, btn))
    );
    panelEl.querySelectorAll("[data-snippets]").forEach((btn) =>
      btn.addEventListener("click", () => toggleResponseSnippets(btn.dataset.snippets, btn.dataset.snippetType))
    );

    const llmBtn = panelEl.querySelector(".sc-llm-btn");
    if (llmBtn) llmBtn.addEventListener("click", runLLMSummary);

    const llmPredictBtn = panelEl.querySelector(".sc-llm-predict-btn");
    if (llmPredictBtn) llmPredictBtn.addEventListener("click", runLLMPredict);

    const reportBtn = panelEl.querySelector(".sc-report-btn");
    if (reportBtn) reportBtn.addEventListener("click", buildAndCopyReport);

    panelEl.querySelectorAll('input[name="sc-verdict"]').forEach((radio) =>
      radio.addEventListener("change", (e) => {
        state.conclusionDraft.verdict = e.target.value;
        saveConclusionDraft();
      })
    );
    panelEl.querySelectorAll(".sc-conclusion-input").forEach((input) =>
      input.addEventListener("change", (e) => {
        state.conclusionDraft[e.target.dataset.field] = e.target.value;
        saveConclusionDraft();
      })
    );
    panelEl.querySelectorAll(".sc-voice-btn").forEach((btn) =>
      btn.addEventListener("click", () => startVoiceInput(btn.dataset.voiceTarget, btn))
    );
    const genBtn = panelEl.querySelector(".sc-conclusion-generate-btn");
    if (genBtn) genBtn.addEventListener("click", buildAndCopyConclusion);
    const pdfBtn = panelEl.querySelector(".sc-conclusion-pdf-btn");
    if (pdfBtn) pdfBtn.addEventListener("click", exportConclusionPDF);
    const saveBtn = panelEl.querySelector(".sc-conclusion-save-btn");
    if (saveBtn)
      saveBtn.addEventListener("click", () => {
        if (!state.conclusionDraft.verdict) {
          alert("Выберите вердикт перед сохранением заключения.");
          return;
        }
        saveBtn.disabled = true;
        saveBtn.textContent = "Сохранение…";
        saveFinalizedConclusion().then((awardInfo) => {
          saveBtn.disabled = false;
          if (awardInfo) {
            showBelZorToast(awardInfo);
            saveBtn.textContent = `+${awardInfo.total} BelZor ✓`;
          } else {
            saveBtn.textContent = "Уже сохранено ранее ✓"; // BelZor уже начислен за эту карточку
          }
          setTimeout(() => (saveBtn.textContent = "Сохранить как завершённое"), 2500);
        });
      });
    panelEl.querySelectorAll(".sc-conclusion-broadcast-btn").forEach((btn) =>
      btn.addEventListener("click", () => broadcastConclusion(btn.dataset.channel, btn))
    );
    const secondOpinionBtn = panelEl.querySelector(".sc-second-opinion-btn");
    if (secondOpinionBtn) secondOpinionBtn.addEventListener("click", requestSecondOpinion);

    // --- Наставник L1 ---
    panelEl.querySelectorAll(".sc-mentor-quiz-option").forEach((btn) =>
      btn.addEventListener("click", () => handleMentorQuizAnswer(Number(btn.dataset.quizIndex)))
    );
    panelEl.querySelectorAll(".sc-os-btn").forEach((btn) =>
      btn.addEventListener("click", () => {
        state.selectedOS = btn.dataset.os;
        render();
        switchToTabAndRender("mentor");
      })
    );
    const mentorReflectionInput = panelEl.querySelector(".sc-mentor-reflection-input");
    if (mentorReflectionInput) {
      mentorReflectionInput.addEventListener("change", (e) => {
        const step = state.mentorSteps[state.mentorStepIndex];
        state.mentorAnswered[step.id] = { note: e.target.value };
      });
    }
    const mentorPrev = panelEl.querySelector(".sc-mentor-prev");
    if (mentorPrev) mentorPrev.addEventListener("click", () => moveMentorStep(-1));
    const mentorNext = panelEl.querySelector(".sc-mentor-next");
    if (mentorNext) mentorNext.addEventListener("click", () => moveMentorStep(1));
    const mentorAskBtn = panelEl.querySelector(".sc-mentor-ask-btn");
    if (mentorAskBtn) mentorAskBtn.addEventListener("click", runMentorAsk);

    panelEl.querySelectorAll(".sc-mentor-track-btn").forEach((btn) =>
      btn.addEventListener("click", () => {
        state.mentorTrack = btn.dataset.track;
        render();
        switchToTabAndRender("mentor");
      })
    );
    const gossopkaDraftBtn = panelEl.querySelector(".sc-gossopka-draft-btn");
    if (gossopkaDraftBtn) gossopkaDraftBtn.addEventListener("click", buildGosSOPKADraft);
    const sigmaBtn = panelEl.querySelector(".sc-sigma-draft-btn");
    if (sigmaBtn) sigmaBtn.addEventListener("click", () => buildDetectionDraft("sigma"));
    const yaraBtn = panelEl.querySelector(".sc-yara-draft-btn");
    if (yaraBtn) yaraBtn.addEventListener("click", () => buildDetectionDraft("yara"));

    // --- Статистика ---
    panelEl.querySelectorAll(".sc-stats-period-btn").forEach((btn) =>
      btn.addEventListener("click", () => {
        state.statsPeriod = btn.dataset.period;
        render();
        switchToTabAndRender("stats");
      })
    );
    const statsExportBtn = panelEl.querySelector(".sc-stats-export-btn");
    if (statsExportBtn) statsExportBtn.addEventListener("click", exportStatsCSV);
    renderCampaignGraph();

    // --- Глоссарий ---
    const glossaryRefreshBtn = panelEl.querySelector(".sc-glossary-refresh-btn");
    if (glossaryRefreshBtn) glossaryRefreshBtn.addEventListener("click", refreshGlossary);
    const glossarySubmitBtn = panelEl.querySelector(".sc-glossary-submit-btn");
    if (glossarySubmitBtn) glossarySubmitBtn.addEventListener("click", submitGlossaryTerm);
    panelEl.querySelectorAll(".sc-glossary-vote").forEach((btn) =>
      btn.addEventListener("click", () => voteGlossaryTerm(btn.dataset.voteId, btn.dataset.voteDir))
    );
  }

  const CAMPAIGN_VERDICT_COLORS = { tp: "#dc2626", fp: "#16a34a", benign: "#64748b", escalate: "#f59e0b", unset: "#6366f1" };

  function renderCampaignGraph() {
    const canvas = panelEl.querySelector(".sc-campaign-canvas");
    const emptyEl = panelEl.querySelector(".sc-campaign-empty");
    if (!canvas) return;
    const graph = socCopilotBuildCampaignGraph(state.conclusionsHistory);
    if (!graph.nodes.length) {
      canvas.style.display = "none";
      if (emptyEl) emptyEl.textContent = "Пока недостаточно закрытых инцидентов с пересекающимися IOC/техниками для графа.";
      return;
    }
    canvas.style.display = "block";
    if (emptyEl) emptyEl.textContent = "";

    const width = canvas.width;
    const height = canvas.height;
    const nodes = socCopilotLayoutCircular(graph.nodes, { width, height });
    const nodeById = Object.fromEntries(nodes.map((n) => [n.id, n]));
    const ctx = canvas.getContext("2d");
    ctx.clearRect(0, 0, width, height);

    const maxWeight = Math.max(1, ...graph.edges.map((e) => e.weight));
    graph.edges.forEach((e) => {
      const a = nodeById[e.source];
      const b = nodeById[e.target];
      if (!a || !b) return;
      ctx.beginPath();
      ctx.moveTo(a.x, a.y);
      ctx.lineTo(b.x, b.y);
      ctx.strokeStyle = `rgba(129, 140, 248, ${0.25 + 0.5 * (e.weight / maxWeight)})`;
      ctx.lineWidth = 1 + 2 * (e.weight / maxWeight);
      ctx.stroke();
    });

    nodes.forEach((n) => {
      ctx.beginPath();
      ctx.arc(n.x, n.y, 7, 0, 2 * Math.PI);
      ctx.fillStyle = CAMPAIGN_VERDICT_COLORS[n.verdict] || CAMPAIGN_VERDICT_COLORS.unset;
      ctx.fill();
      ctx.strokeStyle = "#0f172a";
      ctx.lineWidth = 2;
      ctx.stroke();
    });

    // Клик по узлу — открыть соответствующий инцидент. Простое попадание в круг
    // радиусом чуть больше отрисованного (проще целиться курсором).
    canvas.onclick = (e) => {
      const rect = canvas.getBoundingClientRect();
      const x = ((e.clientX - rect.left) / rect.width) * width;
      const y = ((e.clientY - rect.top) / rect.height) * height;
      const hit = nodes.find((n) => Math.hypot(n.x - x, n.y - y) <= 10);
      if (hit && hit.url) window.open(hit.url, "_blank");
    };
    canvas.title = "Клик по узлу открывает инцидент";
  }

  function refreshGlossary() {
    if (!requirePro("glossary")) return;
    const btn = panelEl.querySelector(".sc-glossary-refresh-btn");
    if (btn) {
      btn.disabled = true;
      btn.textContent = "Загрузка…";
    }
    socCopilotSendMessage({ type: "socCopilotGlossaryList" }, (resp) => {
      if (btn) {
        btn.disabled = false;
        btn.textContent = "Обновить список";
      }
      if (!resp || !resp.ok) {
        alert("Ошибка загрузки глоссария: " + (resp?.error || "неизвестная"));
        return;
      }
      state.glossaryTerms = resp.terms;
      render();
      switchToTabAndRender("glossary");
    });
  }

  function submitGlossaryTerm() {
    if (!requirePro("glossary")) return;
    const term = panelEl.querySelector('[data-glossary-field="term"]')?.value.trim();
    const platformContext = panelEl.querySelector('[data-glossary-field="platformContext"]')?.value.trim();
    const definition = panelEl.querySelector('[data-glossary-field="definition"]')?.value.trim();
    if (!term || !definition) {
      alert("Заполните термин и определение.");
      return;
    }
    const btn = panelEl.querySelector(".sc-glossary-submit-btn");
    if (btn) {
      btn.disabled = true;
      btn.textContent = "Добавление…";
    }
    socCopilotSendMessage(
      { type: "socCopilotGlossarySubmit", term: { term, definition, platformContext } },
      (resp) => {
        if (btn) {
          btn.disabled = false;
          btn.textContent = "Добавить термин";
        }
        if (!resp || !resp.ok) {
          alert("Ошибка добавления: " + (resp?.error || "неизвестная"));
          return;
        }
        refreshGlossary();
      }
    );
  }

  function voteGlossaryTerm(termId, direction) {
    if (!requirePro("glossary")) return;
    socCopilotSendMessage({ type: "socCopilotGlossaryVote", termId, direction }, (resp) => {
      if (!resp || !resp.ok) {
        alert("Ошибка голосования: " + (resp?.error || "неизвестная"));
        return;
      }
      const term = state.glossaryTerms.find((t) => t.id === termId);
      if (term) {
        term.upvotes = resp.upvotes;
        term.downvotes = resp.downvotes;
        term.netScore = resp.netScore;
        render();
        switchToTabAndRender("glossary");
      }
    });
  }

  function exportStatsCSV() {
    const csv = socCopilotBuildCSVReport(state.conclusionsHistory);
    const blob = new Blob([csv], { type: "text/csv;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = `belyaev-response-report-${new Date().toISOString().slice(0, 10)}.csv`;
    a.click();
    URL.revokeObjectURL(url);
  }

  function moveMentorStep(delta) {
    const newIdx = state.mentorStepIndex + delta;
    if (newIdx < 0 || newIdx >= state.mentorSteps.length) return;
    state.mentorStepIndex = newIdx;
    render();
    switchToTabAndRender("mentor");
    spotlightCurrentMentorStep();
  }

  function switchToTabAndRender(tabName) {
    panelEl.querySelectorAll(".sc-tab-btn").forEach((b) => b.classList.toggle("sc-active", b.dataset.tab === tabName));
    panelEl.querySelectorAll("[data-tab-content]").forEach((c) => c.classList.toggle("sc-hidden", c.dataset.tabContent !== tabName));
  }

  function spotlightCurrentMentorStep() {
    const step = state.mentorSteps[state.mentorStepIndex];
    if (!step || !step.highlightField) {
      removeSpotlight();
      return;
    }
    const selector = state.activeAdapter?.selectors?.[step.highlightField];
    if (!selector) {
      removeSpotlight();
      return;
    }
    showSpotlight(selector);
  }

  function handleMentorQuizAnswer(selectedIndex) {
    const step = state.mentorSteps[state.mentorStepIndex];
    if (!step.quiz || state.mentorAnswered[step.id]) return;
    const correct = selectedIndex === step.quiz.correctIndex;
    state.mentorAnswered[step.id] = { correct, selectedIndex };
    state.mentorProgress.total += 1;
    if (correct) state.mentorProgress.correct += 1;
    saveMentorProgress();
    state.quizLog.push({ correct, timestamp: new Date().toISOString() });
    if (state.quizLog.length > 200) state.quizLog = state.quizLog.slice(-200);
    socCopilotStorageSet({ [STORAGE_KEYS.quizLog]: state.quizLog });
    render();
    switchToTabAndRender("mentor");
  }

  // Проверка доступа к Pro-функции. При отсутствии Pro — показывает понятное
  // объяснение (сколько дней триала осталось / что лицензия истекла) и не даёт
  // выполнить действие. Ссылается на человекочитаемое название фичи из license.js.
  function requirePro(featureKey) {
    if (socCopilotIsPro(state.licenseState)) return true;
    const label = SOC_COPILOT_PRO_FEATURES[featureKey] || "Эта функция";
    const msg =
      state.licenseState.source === "none" && !state.licenseState.trialActive
        ? `«${label}» - Pro-функция. Бесплатный период закончился. Активируйте лицензию во вкладке настроек «Лицензия».`
        : `«${label}» - Pro-функция, доступна в бесплатном пробном периоде (осталось ${state.licenseState.trialDaysLeft} дн.) или по лицензии.`;
    alert(msg);
    return false;
  }

  function runMentorAsk() {
    if (!requirePro("llmMentorAsk")) return;
    const input = panelEl.querySelector(".sc-mentor-ask-input");
    const out = panelEl.querySelector(".sc-mentor-ask-output");
    const previewEl = panelEl.querySelector(".sc-mentor-ask-redaction-preview");
    const question = (input?.value || "").trim();
    if (!question) return;
    const raw = `Вопрос аналитика: ${question}
Контекст инцидента - заголовок: ${state.fields.title || "—"}
Описание: ${(state.fields.description || "—").slice(0, 1000)}`;
    const { text: redactedContext, mapping } = socCopilotRedactSensitiveData(raw, { companyNames: state.companyNames || [] });
    renderRedactionPreview(previewEl, redactedContext, mapping);
    out.textContent = "Наставник думает…";
    socCopilotSendMessage(
      { type: "socCopilotLLMMentor", payload: { redactedContext } },
      (response) => {
        if (!response || response.error) {
          out.textContent = "Ошибка: " + (response?.error || "нет ответа. Укажите Anthropic API-ключ в настройках.");
          return;
        }
        out.textContent = socCopilotRestoreSensitiveData(response.text, mapping);
      }
    );
  }

  function requestSecondOpinion() {
    if (!requirePro("conclusionBroadcast")) return;
    const btn = panelEl.querySelector(".sc-second-opinion-btn");
    const channel = Object.entries(state.notifyChannels).find(([, on]) => on)?.[0];
    if (!channel) return;
    const verdictLabels = { tp: "True Positive", fp: "False Positive", benign: "Benign", escalate: "Эскалация" };
    const title = `🤝 Нужна проверка вердикта: ${state.fields.title || location.href}`;
    const text = `Коллеги, нужно второе мнение по инциденту.\n${state.fields.title || location.href}\nМой предварительный вердикт: ${verdictLabels[state.conclusionDraft.verdict] || "ещё не определён"}\nПричина: ${state.conclusionDraft.rootCause || "—"}\nСсылка: ${location.href}\n\nСогласны или видите иначе?`;
    btn.textContent = "Отправка…";
    socCopilotSendMessage({ type: "socCopilotBroadcast", channel, text, title }, (resp) => {
      btn.textContent = resp && resp.ok ? "Запрошено ✓" : "Ошибка: " + (resp?.error || "неизвестная");
      setTimeout(() => (btn.textContent = "🤝 Запросить второе мнение"), 2500);
    });
  }

  function broadcastConclusion(channel, btn) {
    if (!requirePro("conclusionBroadcast")) return;
    const labels = { slack: "Slack/Mattermost", telegram: "Telegram", max: "MAX", teams: "Teams", jira: "Jira" };
    const verdictLabels = { tp: "True Positive", fp: "False Positive", benign: "Benign", escalate: "Эскалация" };
    const originalLabel = `Отправить в ${labels[channel]}`;
    const title = `Инцидент: ${state.fields.title || location.href}`;
    // Примечание: это уведомление команде реагирования, а не запрос к LLM — обезличивание
    // здесь не применяется, т.к. коллегам для реагирования нужны настоящие значения.
    const summaryText = `Заключение по инциденту\n${state.fields.title || location.href}\nВердикт: ${verdictLabels[state.conclusionDraft.verdict] || "не выбран"}\nПричина: ${state.conclusionDraft.rootCause || "—"}\nСсылка: ${location.href}`;
    btn.textContent = "Отправка…";
    socCopilotSendMessage(
      { type: "socCopilotBroadcast", channel, text: summaryText, title },
      (resp) => {
        if (resp && resp.ok) {
          btn.textContent = resp.issueKey ? `Создано: ${resp.issueKey} ✓` : "Отправлено ✓";
        } else {
          btn.textContent = "Ошибка: " + (resp?.error || "неизвестная");
        }
        setTimeout(() => (btn.textContent = originalLabel), 2500);
      }
    );
  }

  function toggleResponseSnippets(value, snippetType) {
    const panel = panelEl.querySelector(`.sc-snippets-panel[data-snippets-for="${cssEscape(value)}"]`);
    if (!panel) return;
    if (panel.classList.contains("sc-snippets-open")) {
      panel.classList.remove("sc-snippets-open");
      panel.innerHTML = "";
      return;
    }
    const snippets = socCopilotBuildResponseSnippets(snippetType, value);
    panel.classList.add("sc-snippets-open");
    panel.innerHTML = snippets.length
      ? `<p class="sc-hint-inline">⚠️ Только copy-paste - плагин ничего не выполняет сам. Проверьте команду перед запуском.</p>` +
        snippets
          .map(
            (s) => `
        <div class="sc-snippet">
          <div class="sc-snippet-tool">${escapeHtml(s.tool)}</div>
          <pre class="sc-snippet-code">${escapeHtml(s.command)}</pre>
          <button class="sc-snippet-copy" data-copy-snippet="${escapeAttr(s.command)}">Копировать</button>
        </div>`
          )
          .join("")
      : `<p class="sc-muted">Нет готовых шаблонов для этого типа индикатора.</p>`;
    panel.querySelectorAll("[data-copy-snippet]").forEach((btn) =>
      btn.addEventListener("click", () => navigator.clipboard.writeText(btn.dataset.copySnippet))
    );
  }

  function runEnrichment(value, iocType, btn) {
    const resultEl = panelEl.querySelector(`.sc-enrich-result[data-for="${cssEscape(value)}"]`);
    if (resultEl) resultEl.textContent = "…";
    socCopilotSendMessage(
      { type: "socCopilotEnrich", value, iocType },
      (response) => {
        if (!resultEl) return;
        if (!response || response.error) {
          resultEl.textContent = response?.error || "ошибка / нет ключа API";
          resultEl.className = "sc-enrich-result sc-bad";
          return;
        }
        resultEl.textContent = response.summary;
        resultEl.className = `sc-enrich-result ${response.malicious ? "sc-bad" : "sc-ok"}`;
        state.anyEnrichmentVerified = true;
        if (response.malicious) state.anyMaliciousEnrichment = true;
      }
    );
  }

  function cssEscape(v) {
    return v.replace(/["\\]/g, "\\$&");
  }

  function buildRedactedContext(kind) {
    const companyNames = state.companyNames || [];
    let raw = "";
    if (kind === "summary") {
      raw = `Заголовок: ${state.fields.title || "—"}
Описание: ${state.fields.description || "—"}
Критичность: ${state.fields.severity || "—"}
Статус: ${state.fields.status || "—"}
Активы: ${state.fields.assets || "—"}
Обнаруженные типы IOC: ${Object.keys(state.iocMap).join(", ") || "нет"}`;
    } else if (kind === "predict") {
      const techniquesStr = state.mitreTechniques.map((t) => `${t.id} ${t.name} (${t.tacticName})`).join(", ") || "нет";
      const heuristicStr = state.mitrePredictions.map((p) => `${p.id} ${p.name}`).join(", ") || "нет";
      raw = `Заголовок: ${state.fields.title || "—"}
Описание: ${state.fields.description || "—"}
Обнаруженные техники ATT&CK: ${techniquesStr}
Эвристический прогноз: ${heuristicStr}`;
    }
    return socCopilotRedactSensitiveData(raw, { companyNames });
  }

  function renderRedactionPreview(containerEl, redactedText, mapping) {
    const summary = socCopilotRedactionSummary(mapping);
    const summaryStr = Object.entries(summary)
      .map(([type, count]) => `${type}: ${count}`)
      .join(", ");
    containerEl.innerHTML = `
      <details class="sc-redaction-preview">
        <summary>🔒 Обезличено перед отправкой${summaryStr ? " (" + escapeHtml(summaryStr) + ")" : ""}</summary>
        <pre>${escapeHtml(redactedText)}</pre>
      </details>`;
  }

  function runLLMSummary() {
    if (!requirePro("llmSummary")) return;
    const out = panelEl.querySelector(".sc-llm-output");
    const previewEl = panelEl.querySelector(".sc-llm-redaction-preview");
    const { text: redactedContext, mapping } = buildRedactedContext("summary");
    renderRedactionPreview(previewEl, redactedContext, mapping);
    out.textContent = "Запрашиваю модель…";
    socCopilotSendMessage(
      {
        type: "socCopilotLLMSummary",
        payload: { redactedContext, platform: state.activeAdapter?.name }
      },
      (response) => {
        if (!response || response.error) {
          out.textContent = "Ошибка: " + (response?.error || "нет ответа. Укажите Anthropic API-ключ в настройках.");
          return;
        }
        // Восстанавливаем плейсхолдеры обратно в реальные значения — ТОЛЬКО локально,
        // модель их не видела (см. utils/redaction.js).
        out.textContent = socCopilotRestoreSensitiveData(response.text, mapping);
      }
    );
  }

  function runLLMPredict() {
    if (!requirePro("llmPredict")) return;
    const out = panelEl.querySelector(".sc-llm-predict-output");
    const previewEl = panelEl.querySelector(".sc-llm-predict-redaction-preview");
    const { text: redactedContext, mapping } = buildRedactedContext("predict");
    renderRedactionPreview(previewEl, redactedContext, mapping);
    out.textContent = "Запрашиваю модель…";
    socCopilotSendMessage(
      {
        type: "socCopilotLLMPredict",
        payload: { redactedContext }
      },
      (response) => {
        if (!response || response.error) {
          out.textContent = "Ошибка: " + (response?.error || "нет ответа. Укажите Anthropic API-ключ в настройках.");
          return;
        }
        out.textContent = socCopilotRestoreSensitiveData(response.text, mapping);
      }
    );
  }

  function buildConclusionText(format) {
    const base = socCopilotBuildConclusion({
      platformName: state.activeAdapter?.name,
      fields: state.fields,
      iocMap: state.iocMap,
      mitreTechniques: state.mitreTechniques,
      playbook: state.playbook,
      checkedSteps: state.checkedSteps,
      verdict: state.conclusionDraft.verdict,
      rootCause: state.conclusionDraft.rootCause,
      impact: state.conclusionDraft.impact,
      actionsTaken: state.conclusionDraft.actionsTaken,
      recommendations: state.conclusionDraft.recommendations,
      url: location.href
    });
    const analyst = state.analystFullName || state.analystPseudonym || "";
    const contacts = state.analystContacts || "";
    const ts = new Date().toLocaleDateString("ru-RU") + " " + new Date().toLocaleTimeString("ru-RU", { hour: "2-digit", minute: "2-digit" });
    const signature = (analyst || contacts) ? "\n---\n" + (analyst ? "Аналитик: " + analyst + "\n" : "") + (contacts ? "Контакты: " + contacts + "\n" : "") + "Дата: " + ts : "";
    const full = base + signature;
    if (format === "html") {
      const esc = full.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
      return "<!DOCTYPE html><html lang=\"ru\"><head><meta charset=\"utf-8\"><title>Заключение</title></head><body><pre>" + esc + "</pre></body></html>";
    }
    return full;
  }

  function buildGosSOPKADraft() {
    const draft = socCopilotBuildGosSOPKADraft({
      platformName: state.activeAdapter?.name,
      fields: state.fields,
      iocMap: state.iocMap,
      mitreTechniques: state.mitreTechniques,
      verdict: state.conclusionDraft.verdict,
      url: location.href
    });
    const preview = panelEl.querySelector(".sc-gossopka-draft-preview");
    if (preview) preview.textContent = draft;
    navigator.clipboard.writeText(draft);
  }

  // Голосовой ввод для полей заключения (Web Speech API, встроен в Chrome).
  // Распознавание идёт локально в браузере через сервис Google speech recognition,
  // используемый самим Chrome — плагин не отправляет аудио никуда сам по себе.
  let activeRecognition = null;

  function startVoiceInput(fieldName, btn) {
    const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
    if (!SpeechRecognition) {
      alert("Голосовой ввод не поддерживается в этом браузере.");
      return;
    }
    if (activeRecognition) {
      activeRecognition.stop();
      return;
    }
    const textarea = panelEl.querySelector(`.sc-conclusion-input[data-field="${fieldName}"]`);
    if (!textarea) return;

    const recognition = new SpeechRecognition();
    recognition.lang = "ru-RU";
    recognition.interimResults = false;
    recognition.maxAlternatives = 1;

    activeRecognition = recognition;
    btn.textContent = "🔴";
    btn.title = "Идёт запись… нажмите ещё раз, чтобы остановить";

    recognition.onresult = (event) => {
      const transcript = Array.from(event.results)
        .map((r) => r[0].transcript)
        .join(" ");
      const existing = textarea.value.trim();
      textarea.value = existing ? existing + " " + transcript : transcript;
      state.conclusionDraft[fieldName] = textarea.value;
      saveConclusionDraft();
    };
    recognition.onerror = (event) => {
      if (event.error !== "aborted") console.warn("[voice] Ошибка распознавания:", event.error);
    };
    recognition.onend = () => {
      activeRecognition = null;
      btn.textContent = "🎤";
      btn.title = "Надиктовать";
    };
    recognition.start();
  }

  function buildDetectionDraft(kind) {
    const draft =
      kind === "sigma"
        ? socCopilotBuildSigmaDraft({
            title: state.fields.title,
            mitreTechniques: state.mitreTechniques,
            iocMap: state.iocMap,
            platformName: state.activeAdapter?.name
          })
        : socCopilotBuildYaraDraft({ title: state.fields.title, iocMap: state.iocMap });
    const preview = panelEl.querySelector(".sc-detection-draft-preview");
    if (preview) preview.textContent = draft;
    navigator.clipboard.writeText(draft);
  }

  function buildAndCopyConclusion() {
    const fmt = panelEl.querySelector(".sc-conclusion-format")?.value || "md";
    const text = buildConclusionText(fmt);
    panelEl.querySelector(".sc-conclusion-preview").textContent = buildConclusionText("md");
    navigator.clipboard.writeText(text);
  }

  function exportConclusionPDF() {
    if (!requirePro("conclusionPdf")) return;
    const md = buildConclusionText();
    // Безопасность: контент экранируется как HTML-текст и вставляется в <pre> напрямую,
    // без встраивания пользовательских/сгенерированных данных в <script> (см. CHANGELOG 0.4.0).
    const escaped = md
      .replace(/&/g, "&amp;")
      .replace(/</g, "&lt;")
      .replace(/>/g, "&gt;");
    const html = `<!DOCTYPE html><html lang="ru"><head><meta charset="utf-8"/>
      <title>Заключение по инциденту</title>
      <style>
        body { font-family: -apple-system, Arial, sans-serif; max-width: 800px; margin: 30px auto; color: #111; line-height: 1.5; }
        pre { white-space: pre-wrap; font-family: inherit; }
        @media print { body { margin: 10mm; } }
      </style></head>
      <body onload="setTimeout(function(){ window.print(); }, 300)">
      <pre>${escaped}</pre>
      </body></html>`;
    const blob = new Blob([html], { type: "text/html" });
    const url = URL.createObjectURL(blob);
    window.open(url, "_blank");
  }

  function buildAndCopyReport() {
    const md = socCopilotBuildReport({
      platformName: state.activeAdapter?.name,
      fields: state.fields,
      iocMap: state.iocMap,
      playbook: state.playbook,
      checkedSteps: state.checkedSteps,
      mitreTechniques: state.mitreTechniques,
      mitrePredictions: state.mitrePredictions,
      url: location.href
    });
    panelEl.querySelector(".sc-report-preview").textContent = md;
    navigator.clipboard.writeText(md);
  }

  // ---------- Пикер элементов (для настройки адаптеров) ----------
  let pickerActive = false;
  let pickerField = null;
  let pickerOverlay = null;

  function buildSelector(el) {
    if (el.id) return `#${CSS.escape(el.id)}`;
    const parts = [];
    let node = el;
    let depth = 0;
    while (node && node.nodeType === 1 && depth < 6) {
      let part = node.tagName.toLowerCase();
      if (node.classList.length) {
        part += "." + Array.from(node.classList).slice(0, 2).map((c) => CSS.escape(c)).join(".");
      } else {
        const parent = node.parentElement;
        if (parent) {
          const idx = Array.from(parent.children).indexOf(node) + 1;
          part += `:nth-child(${idx})`;
        }
      }
      parts.unshift(part);
      node = node.parentElement;
      depth++;
    }
    return parts.join(" > ");
  }

  function startPicker(field) {
    pickerActive = true;
    pickerField = field;
    document.body.style.cursor = "crosshair";
    document.addEventListener("mouseover", onPickerHover, true);
    document.addEventListener("click", onPickerClick, true);
  }

  function onPickerHover(e) {
    if (!pickerActive) return;
    if (pickerOverlay) pickerOverlay.style.outline = "";
    e.target.style.outline = "2px solid #ff5252";
    pickerOverlay = e.target;
  }

  function onPickerClick(e) {
    if (!pickerActive) return;
    e.preventDefault();
    e.stopPropagation();
    const selector = buildSelector(e.target);
    e.target.style.outline = "";
    document.removeEventListener("mouseover", onPickerHover, true);
    document.removeEventListener("click", onPickerClick, true);
    document.body.style.cursor = "";
    pickerActive = false;
    socCopilotSendMessage({ type: "socCopilotPickerResult", field: pickerField, selector });
  }

  // ---------- Сообщения от popup/options ----------
  chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
    if (msg.type === "socCopilotTogglePanel") {
      ensurePanel();
      togglePanel();
      sendResponse({ ok: true });
    } else if (msg.type === "socCopilotStatus") {
      sendResponse({
        matched: !!state.activeAdapter,
        adapterName: state.activeAdapter?.name || null,
        iocCount: socCopilotCountIOCs(state.iocMap)
      });
    } else if (msg.type === "socCopilotStartPicker") {
      startPicker(msg.field);
      sendResponse({ ok: true });
    } else if (msg.type === "socCopilotSettingsUpdated") {
      loadStorage().then(() => {
        refresh();
        applyTheme();
        if (state.panelOpen) render();
      });
    } else if (msg.type === "socCopilotCommand") {
      handleHotkeyCommand(msg.command);
    } else if (msg.type === "socCopilotAskSelectionResult") {
      showAskSelectionToast(msg);
    }
    return true;
  });

  function handleHotkeyCommand(command) {
    if (command === "toggle-panel") {
      ensurePanel();
      togglePanel();
    } else if (command === "mark-false-positive") {
      if (!state.activeAdapter) return;
      ensurePanel();
      state.conclusionDraft.verdict = "fp";
      saveConclusionDraft();
      togglePanel(true);
    } else if (command === "copy-report") {
      if (!state.activeAdapter) return;
      const md = socCopilotBuildReport({
        platformName: state.activeAdapter?.name,
        fields: state.fields,
        iocMap: state.iocMap,
        playbook: state.playbook,
        checkedSteps: state.checkedSteps,
        mitreTechniques: state.mitreTechniques,
        mitrePredictions: state.mitrePredictions,
        url: location.href
      });
      navigator.clipboard.writeText(md);
    }
  }

  // Плавающая подсказка с ответом на "Спросить Belyaev Response про выделенное"
  function showAskSelectionToast(msg) {
    ensurePanel();
    const toast = document.createElement("div");
    toast.className = "sc-ask-toast";
    toast.textContent = msg.error ? "Ошибка: " + msg.error : msg.text;
    shadowRoot.appendChild(toast);
    setTimeout(() => toast.classList.add("sc-show"), 10);
    setTimeout(() => {
      toast.classList.remove("sc-show");
      setTimeout(() => toast.remove(), 300);
    }, 12000);
  }

  const SOC_COPILOT_TIER_LABELS = { critical: "критический", high: "высокий", medium: "средний", low: "низкий" };

  function showBelZorToast(awardInfo) {
    ensurePanel();
    const toast = document.createElement("div");
    toast.className = "sc-ask-toast sc-belzor-toast";
    const tierLabel = SOC_COPILOT_TIER_LABELS[awardInfo.tier] || awardInfo.tier;
    let text = `🏅 +${awardInfo.total} BelZor (критичность: ${tierLabel}, база ${awardInfo.base}`;
    if (awardInfo.bonus > 0) text += ` + бонус ${awardInfo.bonus}`;
    text += ")";
    if (awardInfo.bonusDetails.length) text += "\n" + awardInfo.bonusDetails.join("\n");
    if (awardInfo.rankedUp) text += `\n\n🎉 Новый ранг: ${awardInfo.newRank.emoji} ${awardInfo.newRank.name}!`;
    toast.textContent = text;
    shadowRoot.appendChild(toast);
    setTimeout(() => toast.classList.add("sc-show"), 10);
    setTimeout(() => {
      toast.classList.remove("sc-show");
      setTimeout(() => toast.remove(), 300);
    }, awardInfo.rankedUp ? 8000 : 5000);
  }

  // Дифф "что изменилось, пока вкладка была неактивна" — срабатывает при
  // возврате фокуса на вкладку, сравнивает текущие поля со снапшотом, снятым при
  // предыдущем взгляде на карточку.
  function checkFieldsDiff() {
    if (!state.activeAdapter) return;
    const freshFields = extractFields(state.activeAdapter);
    const changes = socCopilotDiffFields(state.fieldSnapshot, freshFields);
    if (changes.length) {
      const summary = changes.map((c) => `${c.label}: «${c.from || "—"}» → «${c.to || "—"}»`).join("\n");
      showAskSelectionToast({ text: "🔄 Пока вкладка была неактивна, изменилось:\n" + summary });
      state.fields = freshFields;
      state.iocMap = socCopilotExtractIOCs(state.fields.rawText);
      if (state.panelOpen) render();
    }
    state.fieldSnapshot = socCopilotSnapshotFields(freshFields);
  }

  document.addEventListener("visibilitychange", () => {
    if (document.visibilityState === "visible") checkFieldsDiff();
  });

  // ---------- Init ----------
  loadStorage().then(() => {
    const matched = refresh();
    if (matched) {
      ensurePanel();
    }
  });
})();
