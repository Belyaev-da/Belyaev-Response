// utils/burnout.js — v2.0
// Детектор признаков профессионального выгорания SOC-аналитика.
//
// ЧТО НОВОГО (v2.0):
//   6 поведенческих сигналов вместо 2 — добавлены: скорость работы с инцидентами,
//   доля False Positive, монотонность (одни и те же плейбуки), длина смен,
//   резкое падение BelZor-активности, отсутствие перерывов внутри смены.
//   Персонализированные сообщения — разные советы в зависимости от сочетания сигналов.
//   Динамический порог — накопительный score (сигналы имеют разный вес),
//   а не просто «2 из 2».
//   Трекер восстановления — фиксирует, помогло ли предыдущее напоминание
//   (точность выросла → «молодец»).
//   Всё локально, ничего никуда не отправляется.
//
// ВАЖНО: это НЕ клинический инструмент и не оценка психического состояния.
// Единственная цель — дружелюбная подсказка. Модуль намеренно консервативен:
// молчит при малейших сомнениях.

// ─── 1. ТОЧНОСТЬ КВИЗОВ ───────────────────────────────────────────────────────

function socCopilotQuizAccuracyTrend(quizHistory, windowSize = 10) {
  if (!quizHistory || quizHistory.length < windowSize * 2) return null;
  const sorted = [...quizHistory].sort((a, b) => new Date(a.timestamp) - new Date(b.timestamp));
  const recent   = sorted.slice(-windowSize);
  const previous = sorted.slice(-windowSize * 2, -windowSize);
  const recentAcc   = recent.filter((q) => q.correct).length / recent.length;
  const previousAcc = previous.filter((q) => q.correct).length / previous.length;
  return { recentAccuracy: recentAcc, previousAccuracy: previousAcc, delta: recentAcc - previousAcc };
}

// ─── 2. НОЧНЫЕ СМЕНЫ ──────────────────────────────────────────────────────────

function socCopilotLateNightPattern(eventsLog, days = 5) {
  if (!eventsLog || !eventsLog.length) return { lateNightDays: 0, flagged: false };
  const cutoff = Date.now() - days * 24 * 60 * 60 * 1000;
  const byDay = {};
  eventsLog.forEach((e) => {
    const t = new Date(e.date);
    if (t.getTime() < cutoff) return;
    const hour   = t.getHours();
    const dayKey = t.toISOString().slice(0, 10);
    if (hour >= 23 || hour < 5) byDay[dayKey] = true;
  });
  const lateNightDays = Object.keys(byDay).length;
  return { lateNightDays, flagged: lateNightDays >= 3 };
}

// ─── 3. СКОРОСТЬ РАБОТЫ С ИНЦИДЕНТАМИ ────────────────────────────────────────
// Резкое ускорение (инциденты закрываются быстрее нормы) часто означает
// поверхностный разбор, а не реальный рост мастерства.

function socCopilotClosingSpeedAnomaly(conclusionsHistory, windowSize = 10) {
  if (!conclusionsHistory || conclusionsHistory.length < windowSize * 2) return null;
  const sorted = [...conclusionsHistory].sort((a, b) => new Date(a.date) - new Date(b.date));
  const timesAll = sorted.map((c) => c.durationMinutes).filter((d) => d > 0);
  if (timesAll.length < windowSize * 2) return null;
  const recent   = timesAll.slice(-windowSize);
  const previous = timesAll.slice(-windowSize * 2, -windowSize);
  const avg = (arr) => arr.reduce((s, v) => s + v, 0) / arr.length;
  const recentAvg   = avg(recent);
  const previousAvg = avg(previous);
  if (previousAvg === 0) return null;
  const ratio = recentAvg / previousAvg; // < 0.5 = вдвое быстрее нормы
  return { recentAvg, previousAvg, ratio, flagged: ratio < 0.5 };
}

// ─── 4. РОСТ ДОЛИ FALSE POSITIVE ──────────────────────────────────────────────
// Усталость снижает внимательность — аналитик начинает закрывать больше
// инцидентов как FP без реального разбора.

function socCopilotFPRateTrend(conclusionsHistory, windowSize = 15) {
  if (!conclusionsHistory || conclusionsHistory.length < windowSize * 2) return null;
  const sorted = [...conclusionsHistory].sort((a, b) => new Date(a.date) - new Date(b.date));
  const fpRate = (arr) => arr.filter((c) => c.verdict === "fp").length / arr.length;
  const recent   = sorted.slice(-windowSize);
  const previous = sorted.slice(-windowSize * 2, -windowSize);
  const recentFP   = fpRate(recent);
  const previousFP = fpRate(previous);
  const delta = recentFP - previousFP;
  // Флаг: FP вырос на >30 п.п. И абсолютная доля > 60%
  return { recentFP, previousFP, delta, flagged: delta > 0.30 && recentFP > 0.60 };
}

// ─── 5. МОНОТОННОСТЬ ПЛЕЙБУКОВ ────────────────────────────────────────────────
// Аналитик работает только с одним типом инцидентов несколько дней подряд —
// признак того, что его «посадили» на однотипный поток (типичная причина выгорания).

function socCopilotPlaybookMonotony(conclusionsHistory, days = 7) {
  if (!conclusionsHistory || conclusionsHistory.length < 5) return { flagged: false };
  const cutoff = Date.now() - days * 24 * 60 * 60 * 1000;
  const recent = conclusionsHistory.filter((c) => new Date(c.date).getTime() >= cutoff);
  if (recent.length < 5) return { flagged: false };
  const counts = {};
  recent.forEach((c) => { const pb = c.playbookId || "generic"; counts[pb] = (counts[pb] || 0) + 1; });
  const total = recent.length;
  const vals = Object.values(counts);
  if (!vals.length) return { flagged: false };
  const maxCount = Math.max(...vals);
  const dominantShare = maxCount / total;
  // Флаг: >80% инцидентов — один тип плейбука при общем количестве ≥5
  return { dominantShare, flagged: dominantShare >= 0.80 };
}

// ─── 6. ДЛИННЫЕ СМЕНЫ БЕЗ ПЕРЕРЫВОВ ─────────────────────────────────────────
// Если события идут непрерывным потоком дольше 8 часов без промежутка ≥30 мин —
// аналитик работает без паузы (высокий риск ошибок и выгорания).

function socCopilotLongShiftPattern(eventsLog, days = 3) {
  if (!eventsLog || eventsLog.length < 3) return { flagged: false };
  const cutoff = Date.now() - days * 24 * 60 * 60 * 1000;
  const recent = eventsLog
    .filter((e) => new Date(e.date).getTime() >= cutoff)
    .sort((a, b) => new Date(a.date) - new Date(b.date));
  if (recent.length < 3) return { flagged: false };

  let maxShiftHours = 0;
  let shiftStart = new Date(recent[0].date);
  let prevTime   = shiftStart;

  recent.slice(1).forEach((e) => {
    const t = new Date(e.date);
    const gapMin = (t - prevTime) / 60000;
    if (gapMin > 30) {
      // Перерыв — смена заканчивается
      const shiftHours = (prevTime - shiftStart) / 3600000;
      if (shiftHours > maxShiftHours) maxShiftHours = shiftHours;
      shiftStart = t;
    }
    prevTime = t;
  });
  // Финальная смена
  const lastShift = (prevTime - shiftStart) / 3600000;
  if (lastShift > maxShiftHours) maxShiftHours = lastShift;

  return { maxShiftHours, flagged: maxShiftHours >= 8 };
}

// ─── 7. ПАДЕНИЕ АКТИВНОСТИ BELZOR ─────────────────────────────────────────────
// Резкое снижение количества закрытых инцидентов при активных сессиях —
// признак прокрастинации и потери мотивации.

function socCopilotBelZorActivityDrop(conclusionsHistory, eventsLog, days = 14) {
  if (!conclusionsHistory || !eventsLog) return { flagged: false };
  const half = days / 2;
  const now  = Date.now();
  const mid  = now - half * 24 * 60 * 60 * 1000;
  const start = now - days * 24 * 60 * 60 * 1000;

  const conclusionsOld    = conclusionsHistory.filter((c) => new Date(c.date).getTime() >= start && new Date(c.date).getTime() < mid).length;
  const conclusionsRecent = conclusionsHistory.filter((c) => new Date(c.date).getTime() >= mid).length;
  const sessionsOld    = eventsLog.filter((e) => new Date(e.date).getTime() >= start && new Date(e.date).getTime() < mid).length;
  const sessionsRecent = eventsLog.filter((e) => new Date(e.date).getTime() >= mid).length;

  if (sessionsOld < 3 || sessionsRecent < 3) return { flagged: false };
  const rateOld    = conclusionsOld    / sessionsOld;
  const rateRecent = conclusionsRecent / sessionsRecent;
  const drop = rateOld > 0 ? (rateOld - rateRecent) / rateOld : 0;
  // Флаг: производительность упала более чем вдвое при наличии активных сессий
  return { rateOld, rateRecent, drop, flagged: drop >= 0.5 && conclusionsRecent < conclusionsOld };
}

// ─── ТРЕКЕР ВОССТАНОВЛЕНИЯ ────────────────────────────────────────────────────
// После показа напоминания запоминает точность, и через N квизов проверяет
// динамику — если улучшилась, показывает позитивный фидбек.

function socCopilotCheckRecovery(quizHistory, lastBurnoutSnapshot) {
  if (!lastBurnoutSnapshot || !quizHistory || quizHistory.length < 10) return null;
  const { accuracyAtAlert, timestamp } = lastBurnoutSnapshot;
  // Берём только ответы ПОСЛЕ момента напоминания
  const afterAlert = quizHistory
    .filter((q) => new Date(q.timestamp) > new Date(timestamp))
    .sort((a, b) => new Date(a.timestamp) - new Date(b.timestamp));
  if (afterAlert.length < 8) return null;
  const window8 = afterAlert.slice(-8);
  const recentAcc = window8.filter((q) => q.correct).length / window8.length;
  const delta = recentAcc - accuracyAtAlert;
  if (delta >= 0.15) {
    return {
      recovered: true,
      message: `💛 Заметил, что после перерыва точность выросла на ${Math.round(delta * 100)} п.п. — перерывы работают!`
    };
  }
  return null;
}

// ─── ГЛАВНАЯ ФУНКЦИЯ ──────────────────────────────────────────────────────────

function socCopilotCheckBurnoutSignals({
  quizHistory, eventsLog, conclusionsHistory, lastBurnoutSnapshot
}) {
  // --- Сначала проверяем восстановление ---
  const recovery = socCopilotCheckRecovery(quizHistory, lastBurnoutSnapshot);
  if (recovery) return { type: "recovery", ...recovery };

  // --- Собираем все сигналы с весами ---
  const signals = [];

  const trend = socCopilotQuizAccuracyTrend(quizHistory);
  if (trend && trend.delta <= -0.25)
    signals.push({ id: "quiz", weight: 2, detail: `точность квизов: ${Math.round(trend.recentAccuracy * 100)}% (была ${Math.round(trend.previousAccuracy * 100)}%)` });

  const lateNight = socCopilotLateNightPattern(eventsLog);
  if (lateNight.flagged)
    signals.push({ id: "night", weight: 2, detail: `работа в ночное время ${lateNight.lateNightDays} дн. из 5` });

  const speed = socCopilotClosingSpeedAnomaly(conclusionsHistory);
  if (speed && speed.flagged)
    signals.push({ id: "speed", weight: 1, detail: `инциденты закрываются вдвое быстрее нормы (возможно — поверхностно)` });

  const fp = socCopilotFPRateTrend(conclusionsHistory);
  if (fp && fp.flagged)
    signals.push({ id: "fp", weight: 2, detail: `доля FP выросла до ${Math.round(fp.recentFP * 100)}% (была ${Math.round(fp.previousFP * 100)}%)` });

  const mono = socCopilotPlaybookMonotony(conclusionsHistory);
  if (mono.flagged)
    signals.push({ id: "mono", weight: 1, detail: `${Math.round(mono.dominantShare * 100)}% инцидентов — один тип, возможна монотония` });

  const shift = socCopilotLongShiftPattern(eventsLog);
  if (shift.flagged)
    signals.push({ id: "shift", weight: 2, detail: `смена без перерывов ${Math.round(shift.maxShiftHours)} ч` });

  const activity = socCopilotBelZorActivityDrop(conclusionsHistory, eventsLog);
  if (activity.flagged)
    signals.push({ id: "activity", weight: 1, detail: `активность закрытия упала вдвое при тех же сессиях` });

  const totalScore = signals.reduce((s, sig) => s + sig.weight, 0);
  if (totalScore < 2) return null; // Консервативный порог: ≥2 очка

  // --- Персонализированное сообщение ---
  const ids = new Set(signals.map((s) => s.id));
  let message = "";

  if (ids.has("shift") && ids.has("night")) {
    message = "Похоже, ты работаешь без перерывов в нестандартное время уже несколько дней. Усталость в такой режиме накапливается незаметно — мозг адаптируется и уже не сигнализирует о перегрузке так явно. Даже 15 минут на свежем воздухе сейчас дадут больше, чем ещё один закрытый инцидент.";
  } else if (ids.has("fp") && ids.has("speed")) {
    message = "Вижу, что инциденты стали закрываться быстрее, но доля FP выросла. Это классическая картина «автопилота» при усталости — паттерны угадываются, а не анализируются. Если есть возможность — притормози на одном следующем инциденте и разбери его глубже, чем кажется нужным.";
  } else if (ids.has("mono")) {
    message = "Последнюю неделю почти все инциденты — одного типа. Монотония — отдельный фактор выгорания, не менее сильный, чем перегрузка. Попробуй обсудить с тимлидом ротацию типов задач.";
  } else if (ids.has("quiz")) {
    message = "Точность в квизах наставника заметно снизилась. Это не страшно само по себе, но часто первый объективный сигнал усталости — ещё до того, как ты сам почувствуешь. Короткий перерыв сейчас работает лучше, чем «дотяну до конца смены».";
  } else if (ids.has("activity")) {
    message = "Сессий стало столько же, но инцидентов закрывается вдвое меньше. Иногда это рабочий затык — иногда потеря мотивации. Если второе — это не слабость, это нормальная физиология при высоком темпе SOC.";
  } else {
    message = "Несколько мелких сигналов сложились в картину: " + signals.map((s) => s.detail).join("; ") + ". Каждый сам по себе — ничего, вместе — повод ненадолго переключиться.";
  }

  return {
    type: "warning",
    signals,
    score: totalScore,
    message,
    // Снапшот для трекера восстановления
    snapshot: {
      timestamp: new Date().toISOString(),
      accuracyAtAlert: trend ? trend.recentAccuracy : null
    }
  };
}

if (typeof module !== "undefined") {
  module.exports = {
    socCopilotQuizAccuracyTrend,
    socCopilotLateNightPattern,
    socCopilotClosingSpeedAnomaly,
    socCopilotFPRateTrend,
    socCopilotPlaybookMonotony,
    socCopilotLongShiftPattern,
    socCopilotBelZorActivityDrop,
    socCopilotCheckRecovery,
    socCopilotCheckBurnoutSignals
  };
}
