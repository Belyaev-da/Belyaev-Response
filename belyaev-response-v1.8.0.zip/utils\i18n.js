// utils/i18n.js
// Мультиязычность интерфейса. ЧЕСТНО про объём: переведена интерфейсная "оболочка"
// (заголовок панели, названия вкладок, общие кнопки/метки) — самая заметная часть UI.
// Динамический контент (шаги наставника, описания DFIR-инструментов, тексты плейбуков,
// сгенерированные отчёты/заключения) остаётся на русском — полный перевод многих тысяч
// слов контента на 30 языков потребовал бы отдельного проекта уровня локализации, а не
// одной функции. Список языков — топ-30 по числу носителей (первый+второй язык).

const SOC_COPILOT_LANGUAGES = [
  { code: "en", native: "English", ru: "Английский" },
  { code: "zh", native: "中文", ru: "Китайский" },
  { code: "hi", native: "हिन्दी", ru: "Хинди" },
  { code: "es", native: "Español", ru: "Испанский" },
  { code: "fr", native: "Français", ru: "Французский" },
  { code: "ar", native: "العربية", ru: "Арабский" },
  { code: "bn", native: "বাংলা", ru: "Бенгальский" },
  { code: "pt", native: "Português", ru: "Португальский" },
  { code: "ru", native: "Русский", ru: "Русский" },
  { code: "ur", native: "اردو", ru: "Урду" },
  { code: "id", native: "Bahasa Indonesia", ru: "Индонезийский" },
  { code: "de", native: "Deutsch", ru: "Немецкий" },
  { code: "ja", native: "日本語", ru: "Японский" },
  { code: "sw", native: "Kiswahili", ru: "Суахили" },
  { code: "mr", native: "मराठी", ru: "Маратхи" },
  { code: "te", native: "తెలుగు", ru: "Телугу" },
  { code: "tr", native: "Türkçe", ru: "Турецкий" },
  { code: "ta", native: "தமிழ்", ru: "Тамильский" },
  { code: "vi", native: "Tiếng Việt", ru: "Вьетнамский" },
  { code: "ko", native: "한국어", ru: "Корейский" },
  { code: "it", native: "Italiano", ru: "Итальянский" },
  { code: "fa", native: "فارسی", ru: "Персидский" },
  { code: "th", native: "ไทย", ru: "Тайский" },
  { code: "gu", native: "ગુજરાતી", ru: "Гуджарати" },
  { code: "pl", native: "Polski", ru: "Польский" },
  { code: "uk", native: "Українська", ru: "Украинский" },
  { code: "ml", native: "മലയാളം", ru: "Малаялам" },
  { code: "kn", native: "ಕನ್ನಡ", ru: "Каннада" },
  { code: "nl", native: "Nederlands", ru: "Нидерландский" },
  { code: "ro", native: "Română", ru: "Румынский" }
];

// Ключ -> { код_языка: перевод }. "ru" всегда присутствует как исходный текст и
// fallback для отсутствующих переводов.
const SOC_COPILOT_TRANSLATIONS = {
  tabIOC: { ru: "IOC", en: "IOC", zh: "威胁指标", hi: "IOC", es: "IOC", fr: "IOC", ar: "مؤشرات الاختراق", bn: "IOC", pt: "IOC", ur: "IOC", id: "IOC", de: "IOC", ja: "IOC", sw: "IOC", mr: "IOC", te: "IOC", tr: "IOC", ta: "IOC", vi: "IOC", ko: "IOC", it: "IOC", fa: "IOC", th: "IOC", gu: "IOC", pl: "IOC", uk: "IOC", ml: "IOC", kn: "IOC", nl: "IOC", ro: "IOC" },
  tabSummary: { ru: "Сводка", en: "Summary", zh: "摘要", hi: "सारांश", es: "Resumen", fr: "Résumé", ar: "ملخص", bn: "সারসংক্ষেপ", pt: "Resumo", ur: "خلاصہ", id: "Ringkasan", de: "Übersicht", ja: "要約", sw: "Muhtasari", mr: "सारांश", te: "సారాంశం", tr: "Özet", ta: "சுருக்கம்", vi: "Tóm tắt", ko: "요약", it: "Riepilogo", fa: "خلاصه", th: "สรุป", gu: "સારાંશ", pl: "Podsumowanie", uk: "Зведення", ml: "സംഗ്രഹം", kn: "ಸಾರಾಂಶ", nl: "Overzicht", ro: "Rezumat" },
  tabMitre: { ru: "MITRE", en: "MITRE", zh: "MITRE", hi: "MITRE", es: "MITRE", fr: "MITRE", ar: "MITRE", bn: "MITRE", pt: "MITRE", ur: "MITRE", id: "MITRE", de: "MITRE", ja: "MITRE", sw: "MITRE", mr: "MITRE", te: "MITRE", tr: "MITRE", ta: "MITRE", vi: "MITRE", ko: "MITRE", it: "MITRE", fa: "MITRE", th: "MITRE", gu: "MITRE", pl: "MITRE", uk: "MITRE", ml: "MITRE", kn: "MITRE", nl: "MITRE", ro: "MITRE" },
  tabPlaybook: { ru: "Плейбук", en: "Playbook", zh: "剧本", hi: "प्लेबुक", es: "Manual", fr: "Playbook", ar: "دليل الإجراءات", bn: "প্লেবুক", pt: "Playbook", ur: "پلے بک", id: "Playbook", de: "Playbook", ja: "プレイブック", sw: "Playbook", mr: "प्लेबुक", te: "ప్లేబుక్", tr: "Oyun Kitabı", ta: "பிளேபுக்", vi: "Playbook", ko: "플레이북", it: "Playbook", fa: "پلی‌بوک", th: "เพลย์บุ๊ก", gu: "પ્લેબુક", pl: "Playbook", uk: "Плейбук", ml: "പ്ലേബുക്ക്", kn: "ಪ್ಲೇಬುಕ್", nl: "Playbook", ro: "Playbook" },
  tabReport: { ru: "Отчёт", en: "Report", zh: "报告", hi: "रिपोर्ट", es: "Informe", fr: "Rapport", ar: "تقرير", bn: "প্রতিবেদন", pt: "Relatório", ur: "رپورٹ", id: "Laporan", de: "Bericht", ja: "レポート", sw: "Ripoti", mr: "अहवाल", te: "నివేదిక", tr: "Rapor", ta: "அறிக்கை", vi: "Báo cáo", ko: "보고서", it: "Rapporto", fa: "گزارش", th: "รายงาน", gu: "અહેવાલ", pl: "Raport", uk: "Звіт", ml: "റിപ്പോർട്ട്", kn: "ವರದಿ", nl: "Rapport", ro: "Raport" },
  tabConclusion: { ru: "Заключение", en: "Conclusion", zh: "结论", hi: "निष्कर्ष", es: "Conclusión", fr: "Conclusion", ar: "الخلاصة", bn: "উপসংহার", pt: "Conclusão", ur: "نتیجہ", id: "Kesimpulan", de: "Fazit", ja: "結論", sw: "Hitimisho", mr: "निष्कर्ष", te: "ముగింపు", tr: "Sonuç", ta: "முடிவு", vi: "Kết luận", ko: "결론", it: "Conclusione", fa: "نتیجه‌گیری", th: "บทสรุป", gu: "નિષ્કર્ષ", pl: "Wniosek", uk: "Висновок", ml: "നിഗമനം", kn: "ತೀರ್ಮಾನ", nl: "Conclusie", ro: "Concluzie" },
  tabMentor: { ru: "Наставник", en: "Mentor", zh: "导师", hi: "मार्गदर्शक", es: "Mentor", fr: "Mentor", ar: "مرشد", bn: "মেন্টর", pt: "Mentor", ur: "رہنما", id: "Mentor", de: "Mentor", ja: "メンター", sw: "Mshauri", mr: "मार्गदर्शक", te: "మెంటార్", tr: "Mentor", ta: "வழிகாட்டி", vi: "Người hướng dẫn", ko: "멘토", it: "Mentore", fa: "مربی", th: "พี่เลี้ยง", gu: "માર્ગદર્શક", pl: "Mentor", uk: "Наставник", ml: "മെന്റർ", kn: "ಮಾರ್ಗದರ್ಶಕ", nl: "Mentor", ro: "Mentor" },
  tabStats: { ru: "Статистика", en: "Statistics", zh: "统计", hi: "सांख्यिकी", es: "Estadísticas", fr: "Statistiques", ar: "الإحصائيات", bn: "পরিসংখ্যান", pt: "Estatísticas", ur: "اعداد و شمار", id: "Statistik", de: "Statistik", ja: "統計", sw: "Takwimu", mr: "आकडेवारी", te: "గణాంకాలు", tr: "İstatistik", ta: "புள்ளிவிவரங்கள்", vi: "Thống kê", ko: "통계", it: "Statistiche", fa: "آمار", th: "สถิติ", gu: "આંકડા", pl: "Statystyki", uk: "Статистика", ml: "സ്ഥിതിവിവരക്കണക്ക്", kn: "ಅಂಕಿಅಂಶಗಳು", nl: "Statistieken", ro: "Statistici" },
  btnCopy: { ru: "копир.", en: "copy", zh: "复制", hi: "कॉपी", es: "copiar", fr: "copier", ar: "نسخ", bn: "কপি", pt: "copiar", ur: "کاپی", id: "salin", de: "kopieren", ja: "コピー", sw: "nakili", mr: "कॉपी", te: "కాపీ", tr: "kopyala", ta: "நகலெடு", vi: "sao chép", ko: "복사", it: "copia", fa: "کپی", th: "คัดลอก", gu: "કૉપિ", pl: "kopiuj", uk: "копіювати", ml: "പകർത്തുക", kn: "ನಕಲಿಸಿ", nl: "kopiëren", ro: "copiază" },
  btnCheck: { ru: "проверить", en: "check", zh: "检查", hi: "जांचें", es: "comprobar", fr: "vérifier", ar: "تحقق", bn: "যাচাই করুন", pt: "verificar", ur: "چیک کریں", id: "periksa", de: "prüfen", ja: "確認", sw: "kagua", mr: "तपासा", te: "తనిఖీ", tr: "kontrol et", ta: "சரிபார்", vi: "kiểm tra", ko: "확인", it: "verifica", fa: "بررسی", th: "ตรวจสอบ", gu: "તપાસો", pl: "sprawdź", uk: "перевірити", ml: "പരിശോധിക്കുക", kn: "ಪರಿಶೀಲಿಸಿ", nl: "controleren", ro: "verifică" },
  btnSave: { ru: "Сохранить", en: "Save", zh: "保存", hi: "सहेजें", es: "Guardar", fr: "Enregistrer", ar: "حفظ", bn: "সংরক্ষণ করুন", pt: "Salvar", ur: "محفوظ کریں", id: "Simpan", de: "Speichern", ja: "保存", sw: "Hifadhi", mr: "जतन करा", te: "సేవ్ చేయండి", tr: "Kaydet", ta: "சேமி", vi: "Lưu", ko: "저장", it: "Salva", fa: "ذخیره", th: "บันทึก", gu: "સાચવો", pl: "Zapisz", uk: "Зберегти", ml: "സംരക്ഷിക്കുക", kn: "ಉಳಿಸಿ", nl: "Opslaan", ro: "Salvează" },
  btnActivate: { ru: "Активировать", en: "Activate", zh: "激活", hi: "सक्रिय करें", es: "Activar", fr: "Activer", ar: "تفعيل", bn: "সক্রিয় করুন", pt: "Ativar", ur: "فعال کریں", id: "Aktifkan", de: "Aktivieren", ja: "有効化", sw: "Amilisha", mr: "सक्रिय करा", te: "సక్రియం చేయండి", tr: "Etkinleştir", ta: "செயல்படுத்து", vi: "Kích hoạt", ko: "활성화", it: "Attiva", fa: "فعال‌سازی", th: "เปิดใช้งาน", gu: "સક્રિય કરો", pl: "Aktywuj", uk: "Активувати", ml: "സജീവമാക്കുക", kn: "ಸಕ್ರಿಯಗೊಳಿಸಿ", nl: "Activeren", ro: "Activează" },
  btnSend: { ru: "Отправить", en: "Send", zh: "发送", hi: "भेजें", es: "Enviar", fr: "Envoyer", ar: "إرسال", bn: "পাঠান", pt: "Enviar", ur: "بھیجیں", id: "Kirim", de: "Senden", ja: "送信", sw: "Tuma", mr: "पाठवा", te: "పంపండి", tr: "Gönder", ta: "அனுப்பு", vi: "Gửi", ko: "보내기", it: "Invia", fa: "ارسال", th: "ส่ง", gu: "મોકલો", pl: "Wyślij", uk: "Надіслати", ml: "അയയ്ക്കുക", kn: "ಕಳುಹಿಸಿ", nl: "Verzenden", ro: "Trimite" },
  btnExport: { ru: "Экспортировать", en: "Export", zh: "导出", hi: "निर्यात करें", es: "Exportar", fr: "Exporter", ar: "تصدير", bn: "রপ্তানি করুন", pt: "Exportar", ur: "برآمد کریں", id: "Ekspor", de: "Exportieren", ja: "エクスポート", sw: "Hamisha", mr: "निर्यात करा", te: "ఎగుమతి చేయండి", tr: "Dışa Aktar", ta: "ஏற்றுமதி", vi: "Xuất", ko: "내보내기", it: "Esporta", fa: "خروجی", th: "ส่งออก", gu: "નિકાસ કરો", pl: "Eksportuj", uk: "Експортувати", ml: "എക്സ്പോർട്ട്", kn: "ರಫ್ತು ಮಾಡಿ", nl: "Exporteren", ro: "Exportă" },
  btnClose: { ru: "Закрыть", en: "Close", zh: "关闭", hi: "बंद करें", es: "Cerrar", fr: "Fermer", ar: "إغلاق", bn: "বন্ধ করুন", pt: "Fechar", ur: "بند کریں", id: "Tutup", de: "Schließen", ja: "閉じる", sw: "Funga", mr: "बंद करा", te: "మూసివేయండి", tr: "Kapat", ta: "மூடு", vi: "Đóng", ko: "닫기", it: "Chiudi", fa: "بستن", th: "ปิด", gu: "બંધ કરો", pl: "Zamknij", uk: "Закрити", ml: "അടയ്ക്കുക", kn: "ಮುಚ್ಚಿ", nl: "Sluiten", ro: "Închide" },
  platformLabel: { ru: "Платформа", en: "Platform", zh: "平台", hi: "प्लेटफ़ॉर्म", es: "Plataforma", fr: "Plateforme", ar: "المنصة", bn: "প্ল্যাটফর্ম", pt: "Plataforma", ur: "پلیٹ فارم", id: "Platform", de: "Plattform", ja: "プラットフォーム", sw: "Jukwaa", mr: "प्लॅटफॉर्म", te: "ప్లాట్‌ఫారమ్", tr: "Platform", ta: "தளம்", vi: "Nền tảng", ko: "플랫폼", it: "Piattaforma", fa: "پلتفرم", th: "แพลตฟอร์ม", gu: "પ્લેટફોર્મ", pl: "Platforma", uk: "Платформа", ml: "പ്ലാറ്റ്‌ഫോം", kn: "ಪ್ಲಾಟ್‌ಫಾರ್ಮ್", nl: "Platform", ro: "Platformă" },
  severityLabel: { ru: "Критичность", en: "Severity", zh: "严重性", hi: "गंभीरता", es: "Gravedad", fr: "Gravité", ar: "الخطورة", bn: "গুরুত্ব", pt: "Gravidade", ur: "شدت", id: "Tingkat Keparahan", de: "Schweregrad", ja: "重大度", sw: "Ukali", mr: "तीव्रता", te: "తీవ్రత", tr: "Önem Derecesi", ta: "தீவிரம்", vi: "Mức độ nghiêm trọng", ko: "심각도", it: "Gravità", fa: "شدت", th: "ความรุนแรง", gu: "ગંભીરતા", pl: "Krytyczność", uk: "Критичність", ml: "തീവ്രത", kn: "ತೀವ್ರತೆ", nl: "Ernst", ro: "Gravitate" },
  statusLabel: { ru: "Статус", en: "Status", zh: "状态", hi: "स्थिति", es: "Estado", fr: "Statut", ar: "الحالة", bn: "অবস্থা", pt: "Status", ur: "حیثیت", id: "Status", de: "Status", ja: "ステータス", sw: "Hali", mr: "स्थिती", te: "స్థితి", tr: "Durum", ta: "நிலை", vi: "Trạng thái", ko: "상태", it: "Stato", fa: "وضعیت", th: "สถานะ", gu: "સ્થિતિ", pl: "Status", uk: "Статус", ml: "നില", kn: "ಸ್ಥಿತಿ", nl: "Status", ro: "Stare" },
  verdictLabel: { ru: "Вердикт", en: "Verdict", zh: "结论", hi: "फ़ैसला", es: "Veredicto", fr: "Verdict", ar: "الحكم", bn: "রায়", pt: "Veredicto", ur: "فیصلہ", id: "Putusan", de: "Urteil", ja: "判定", sw: "Uamuzi", mr: "निर्णय", te: "తీర్పు", tr: "Karar", ta: "தீர்ப்பு", vi: "Phán quyết", ko: "판정", it: "Verdetto", fa: "رأی", th: "คำตัดสิน", gu: "ચુકાદો", pl: "Werdykt", uk: "Вердикт", ml: "വിധി", kn: "ತೀರ್ಪು", nl: "Oordeel", ro: "Verdict" }
};

// Возвращает перевод ключа под язык lang, с fallback на русский (исходный текст),
// затем на сам ключ (чтобы UI не показывал "undefined" при опечатке в коде).
function socCopilotT(key, lang) {
  const entry = SOC_COPILOT_TRANSLATIONS[key];
  if (!entry) return key;
  return entry[lang] || entry.ru || key;
}

if (typeof module !== "undefined") {
  module.exports = { SOC_COPILOT_LANGUAGES, SOC_COPILOT_TRANSLATIONS, socCopilotT };
}
