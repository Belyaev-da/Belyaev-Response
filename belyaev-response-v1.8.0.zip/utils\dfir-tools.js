// utils/dfir-tools.js
// Справочник DFIR/форензик-инструментов для наставника уровней L2/L3.
// ВАЖНО: все ссылки — на официальные страницы проектов/вендоров на момент составления
// справочника. Перед использованием в реальном расследовании ВСЕГДА сверяйте, что вы
// скачиваете инструмент с официального домена (у форензик-тулов бывают поддельные
// клоны) — не полагайтесь слепо на ссылку из любого источника, включая эту.
// Лицензионные условия отдельных инструментов (например, KAPE) могут ограничивать
// коммерческое использование — проверяйте лицензию перед применением у клиента/в SOC.

const SOC_COPILOT_DFIR_TOOLS = [
  {
    id: "volatility3",
    name: "Volatility 3",
    category: "memory",
    categoryName: "Форензика оперативной памяти (RAM)",
    description: "Анализ дампов оперативной памяти: процессы, сетевые соединения, инъекции кода, извлечение учётных данных из lsass.",
    officialUrl: "https://github.com/volatilityfoundation/volatility3",
    license: "Свободное ПО (Volatility Software License)",
    quickStart: [
      "Снимите дамп памяти на хосте (например, через WinPmem/DumpIt — снятие дампа делайте ДО перезагрузки хоста)",
      "vol -f memory.dmp windows.pslist — список процессов",
      "vol -f memory.dmp windows.netscan — сетевые соединения на момент снятия дампа",
      "vol -f memory.dmp windows.malfind — поиск инъекций кода в процессы"
    ]
  },
  {
    id: "kape",
    name: "KAPE (Kroll Artifact Parser and Extractor)",
    category: "triage",
    categoryName: "Быстрый сбор артефактов (триаж)",
    description: "Целевой сбор криминалистически значимых артефактов (реестр, журналы событий, префетч, MFT и др.) без полного образа диска — минуты вместо часов.",
    officialUrl: "https://www.kroll.com/en/services/cyber/reactive-services/kroll-artifact-parser-and-extractor-kape",
    license: "Бесплатно для правоохранительных органов, обучения и НЕкоммерческого использования; для коммерческого/платного реагирования требуется отдельная лицензия Kroll — проверьте актуальные условия перед использованием в оплачиваемом расследовании.",
    quickStart: [
      "Скачайте KAPE с официальной страницы Kroll (форма запроса на сайте)",
      "Запустите gkape.exe (GUI) или kape.exe (CLI) с правами администратора",
      "Targets: выберите набор артефактов (например, !SANS_Triage для базового набора)",
      "Modules: выберите инструменты обработки (например, EvtxECmd для разбора журналов событий)",
      "Результат — готовые к анализу артефакты в целевой папке"
    ]
  },
  {
    id: "velociraptor",
    name: "Velociraptor",
    category: "triage",
    categoryName: "Распределённый сбор и хантинг по парку хостов",
    description: "Open-source EDR-подобный фреймворк для удалённого сбора артефактов и охоты на угрозы на множестве хостов одновременно — хорошая свободная альтернатива коммерческим DFIR-агентам.",
    officialUrl: "https://docs.velociraptor.app/",
    license: "Свободное ПО (Apache 2.0)",
    quickStart: [
      "Разверните сервер Velociraptor (docs.velociraptor.app/docs/deployment)",
      "Установите агента на целевые хосты (или используйте standalone-режим для одного хоста)",
      "Используйте готовые VQL-артефакты (Windows.System.PowerShell, Windows.EventLogs.EvtxHunter и т.п.) для сбора",
      "Экспортируйте результаты для дальнейшего анализа в KAPE/Volatility/Autopsy"
    ]
  },
  {
    id: "autopsy",
    name: "Autopsy (The Sleuth Kit)",
    category: "disk",
    categoryName: "Полный анализ образа диска",
    description: "Графическая оболочка над The Sleuth Kit — восстановление удалённых файлов, анализ файловой системы, timeline, поиск по ключевым словам.",
    officialUrl: "https://www.autopsy.com/download/",
    license: "Свободное ПО (Apache 2.0 / GPL для отдельных модулей)",
    quickStart: [
      "Создайте образ диска (например, через FTK Imager) — работайте с образом, не с оригинальным носителем",
      "New Case → добавьте источник данных (образ)",
      "Дождитесь индексации, используйте модули: File Analysis, Timeline, Keyword Search",
      "Экспортируйте отчёт по найденным артефактам"
    ]
  },
  {
    id: "ftk-imager",
    name: "FTK Imager",
    category: "disk",
    categoryName: "Криминалистическое снятие образов",
    description: "Бесплатный инструмент для создания судебно-значимых (bit-by-bit) образов дисков и памяти с сохранением хэш-сумм для цепочки хранения доказательств.",
    officialUrl: "https://www.exterro.com/ftk-imager",
    license: "Бесплатно (требуется регистрация на сайте Exterro)",
    quickStart: [
      "File → Create Disk Image → выберите источник (физический диск/логический раздел)",
      "Укажите формат образа (E01 — сохраняет метаданные и хэш) и место назначения",
      "После создания сверьте MD5/SHA1 образа с оригиналом (Verify)",
      "Работайте только с копией образа, оригинал — в неизменном виде для цепочки хранения доказательств"
    ]
  },
  {
    id: "chainsaw",
    name: "Chainsaw",
    category: "logs",
    categoryName: "Быстрый поиск по журналам событий Windows",
    description: "Поиск по большим объёмам журналов Windows Event Log с готовыми правилами обнаружения (Sigma-совместимо) — быстрая первичная охота без полного SIEM.",
    officialUrl: "https://github.com/WithSecureLabs/chainsaw",
    license: "Свободное ПО (GPL-3.0)",
    quickStart: [
      "chainsaw hunt <путь к .evtx файлам> --sigma <путь к Sigma-правилам> --mapping <mapping файл>",
      "chainsaw search -t \"<строка поиска>\" <путь к .evtx>",
      "Результат — таблица совпадений с привязкой к конкретным событиям и хостам"
    ]
  },
  {
    id: "hayabusa",
    name: "Hayabusa",
    category: "logs",
    categoryName: "Анализ журналов событий Windows (тайм-лайн)",
    description: "Построение единого тайм-лайна по журналам событий Windows с оценкой критичности каждого события — удобно для быстрой реконструкции хронологии инцидента.",
    officialUrl: "https://github.com/Yamato-Security/hayabusa",
    license: "Свободное ПО (AGPL-3.0)",
    quickStart: [
      "hayabusa update-rules — обновить правила обнаружения перед анализом",
      "hayabusa csv-timeline -d <папка с .evtx> -o timeline.csv",
      "Откройте timeline.csv — события отсортированы по критичности (crit/high/med/low)"
    ]
  },
  {
    id: "wireshark",
    name: "Wireshark",
    category: "network",
    categoryName: "Сетевая форензика",
    description: "Анализ перехваченного сетевого трафика (PCAP) — реконструкция сессий, извлечение файлов, выявление аномального трафика/C2.",
    officialUrl: "https://www.wireshark.org/download.html",
    license: "Свободное ПО (GPLv2)",
    quickStart: [
      "Откройте PCAP-файл (File → Open)",
      "Statistics → Conversations — обзор сетевых сессий",
      "Follow → TCP Stream — реконструкция конкретной сессии",
      "File → Export Objects — извлечение переданных файлов (HTTP/SMB и т.п.)"
    ]
  },
  {
    id: "yara",
    name: "YARA",
    category: "malware",
    categoryName: "Сигнатурный анализ вредоносного ПО",
    description: "Написание и применение правил для идентификации и классификации образцов вредоносного ПО по паттернам в файлах/памяти.",
    officialUrl: "https://virustotal.github.io/yara/",
    license: "Свободное ПО (BSD-3-Clause)",
    quickStart: [
      "yara <правило.yar> <файл_или_папка> — проверка файла/папки по правилу",
      "yara -r <правило.yar> <папка> — рекурсивный поиск",
      "Готовые наборы правил: github.com/Yara-Rules/rules (проверяйте актуальность и источник перед применением)"
    ]
  },
  {
    id: "plaso",
    name: "Plaso / log2timeline",
    category: "timeline",
    categoryName: "Суперлайн-анализ (timeline из множества источников)",
    description: "Автоматическое построение единого хронологического таймлайна из множества разнородных артефактов (файловая система, реестр, журналы, браузер и т.д.).",
    officialUrl: "https://plaso.readthedocs.io/",
    license: "Свободное ПО (Apache 2.0)",
    quickStart: [
      "log2timeline.py output.plaso <путь к образу/артефактам>",
      "psort.py -o l2tcsv -w timeline.csv output.plaso",
      "Анализируйте timeline.csv в Timeline Explorer или любом табличном инструменте"
    ]
  }
];

// Связь между обнаруженными техниками MITRE ATT&CK и рекомендуемыми категориями
// инструментов — помогает наставнику предложить релевантный, а не общий список.
const SOC_COPILOT_TECHNIQUE_TO_DFIR_CATEGORY = {
  T1003: ["memory", "triage"], // OS Credential Dumping — дамп lsass, артефакты авторизации
  T1055: ["memory"], // Process Injection — видно в дампе памяти
  T1059: ["logs", "triage"], // Command and Scripting Interpreter — журналы PowerShell/командной строки
  T1053: ["triage", "logs"], // Scheduled Task — артефакты планировщика
  T1547: ["triage"], // Autostart — реестр/автозагрузка
  T1070: ["logs"], // Indicator Removal — что осталось в журналах после очистки
  T1021: ["network", "logs"], // Remote Services — сетевые сессии, логи авторизации
  T1071: ["network"], // Application Layer Protocol (C2) — сетевой трафик
  T1105: ["network", "malware"], // Ingress Tool Transfer — что было загружено
  T1486: ["triage", "malware"] // Data Encrypted for Impact — образец шифровальщика, артефакты запуска
};

// Конкретные команды быстрого сбора артефактов для каждой ОС
const SOC_COPILOT_DFIR_OS_COMMANDS = {
  windows: {
    label: "Windows",
    sections: [
      {
        title: "Процессы и сетевые соединения",
        commands: [
          "tasklist /v /fo csv > procs.csv",
          "netstat -ano > netstat.txt",
          "wmic process get name,processid,parentprocessid,commandline /format:csv > wmic_procs.csv"
        ]
      },
      {
        title: "Автозагрузка и задачи",
        commands: [
          "reg export HKLM\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Run autorun_hklm.reg",
          "schtasks /query /fo csv /v > schtasks.csv",
          "sc query type= all state= all > services.txt"
        ]
      },
      {
        title: "Пользователи и сессии",
        commands: [
          "net user > users.txt",
          "query session > sessions.txt",
          "wevtutil qe Security /q:\"*[System[EventID=4624 or EventID=4625 or EventID=4648]]\" /rd:true /c:100 /f:text > auth_events.txt"
        ]
      },
      {
        title: "Инструменты (скачать)",
        links: [
          { name: "Autoruns (Sysinternals)", url: "https://learn.microsoft.com/en-us/sysinternals/downloads/autoruns" },
          { name: "Volatility 3 (RAM dump)", url: "https://github.com/volatilityfoundation/volatility3" },
          { name: "KAPE (артефакты + триаж)", url: "https://www.kroll.com/en/services/cyber-risk/incident-response-litigation-support/kroll-artifact-parser-extractor-kape" },
          { name: "Chainsaw (event log hunt)", url: "https://github.com/WithSecureLabs/chainsaw" }
        ]
      }
    ]
  },
  linux: {
    label: "Linux",
    sections: [
      {
        title: "Процессы и сеть",
        commands: [
          "ps aux --forest > procs.txt",
          "ss -tulpn > sockets.txt",
          "lsof -i > lsof_net.txt",
          "netstat -plantu > netstat.txt"
        ]
      },
      {
        title: "Автозагрузка и задачи",
        commands: [
          "crontab -l -u root > cron_root.txt",
          "ls -la /etc/cron* /var/spool/cron/ >> cron_root.txt",
          "systemctl list-units --all > systemctl_units.txt",
          "cat /etc/rc.local"
        ]
      },
      {
        title: "Пользователи и логи",
        commands: [
          "last -i > last.txt",
          "lastb -i > lastb_failed.txt",
          "cat /var/log/auth.log | grep -E 'Failed|Accepted|sudo' > auth.log",
          "cat /etc/passwd | awk -F: '$3==0' > root_uid.txt"
        ]
      },
      {
        title: "Инструменты",
        links: [
          { name: "LiME (дамп памяти Linux)", url: "https://github.com/504ensicsLabs/LiME" },
          { name: "Volatility 3 (анализ дампа)", url: "https://github.com/volatilityfoundation/volatility3" },
          { name: "Hayabusa (log hunting)", url: "https://github.com/Yamato-Security/hayabusa" },
          { name: "Plaso / log2timeline", url: "https://github.com/log2timeline/plaso" }
        ]
      }
    ]
  },
  mac: {
    label: "macOS",
    sections: [
      {
        title: "Процессы и сеть",
        commands: [
          "ps aux > procs.txt",
          "netstat -an > netstat.txt",
          "lsof -i > lsof_net.txt"
        ]
      },
      {
        title: "Автозагрузка",
        commands: [
          "ls -la ~/Library/LaunchAgents/ /Library/LaunchAgents/ /Library/LaunchDaemons/ > launchd.txt",
          "osascript -e 'tell application \"System Events\" to get name of every login item' > login_items.txt"
        ]
      },
      {
        title: "Пользователи и логи",
        commands: [
          "last > last.txt",
          "log show --predicate 'eventMessage contains \"authentication\"' --last 24h > auth.log",
          "dscl . list /Users | grep -v '^_' > users.txt"
        ]
      },
      {
        title: "Инструменты",
        links: [
          { name: "osxpmem (RAM dump)", url: "https://github.com/google/rekall" },
          { name: "Volatility 3 macOS", url: "https://github.com/volatilityfoundation/volatility3" },
          { name: "Autopsy (disk forensics)", url: "https://www.autopsy.com/" }
        ]
      }
    ]
  },
  astra: {
    label: "AstraLinux",
    sections: [
      {
        title: "Процессы и сеть (astra)",
        commands: [
          "ps aux --forest > procs.txt",
          "ss -tulpn > sockets.txt",
          "pdp-ls / 2>/dev/null | head -50 > pdp_root.txt",
          "astra-audit -a list > audit_rules.txt 2>/dev/null || auditctl -l > audit_rules.txt"
        ]
      },
      {
        title: "Мандатный контроль (Parsec/SELinux)",
        commands: [
          "pdp-ps > pdp_procs.txt 2>/dev/null",
          "cat /etc/parsec/macdb > parsec_mac.txt 2>/dev/null",
          "sestatus > sestatus.txt 2>/dev/null"
        ]
      },
      {
        title: "Логи и аудит",
        commands: [
          "journalctl -xe --no-pager > journal.log",
          "cat /var/log/audit/audit.log | grep -E 'USER_AUTH|ANOM' > audit_auth.log",
          "last -i > last.txt"
        ]
      },
      {
        title: "Особенности AstraLinux",
        commands: [
          "# AstraLinux SE: проверить мандатные уровни затронутых процессов",
          "# Документация: https://astralinux.ru/information/documentation/",
          "# Для форензики рекомендован стандартный Linux-инструментарий (LiME, Volatility)"
        ]
      }
    ]
  }
};

function socCopilotRecommendDFIRTools(detectedTechniqueIds) {
  const categories = new Set();
  (detectedTechniqueIds || []).forEach((id) => {
    (SOC_COPILOT_TECHNIQUE_TO_DFIR_CATEGORY[id] || []).forEach((c) => categories.add(c));
  });
  if (!categories.size) return SOC_COPILOT_DFIR_TOOLS.slice(0, 3); // общий стартовый набор
  return SOC_COPILOT_DFIR_TOOLS.filter((t) => categories.has(t.category));
}

// Получить команды/инструменты DFIR для выбранной ОС
function socCopilotGetDFIRByOS(osKey) {
  return SOC_COPILOT_DFIR_OS_COMMANDS[osKey] || SOC_COPILOT_DFIR_OS_COMMANDS.windows;
}

if (typeof module !== "undefined") {
  module.exports = { SOC_COPILOT_DFIR_TOOLS, SOC_COPILOT_TECHNIQUE_TO_DFIR_CATEGORY, socCopilotRecommendDFIRTools, SOC_COPILOT_DFIR_OS_COMMANDS, socCopilotGetDFIRByOS };
}
