const statusEl = document.getElementById("status");
const toggleBtn = document.getElementById("toggleBtn");
const optionsBtn = document.getElementById("optionsBtn");
const mentorProgressEl = document.getElementById("mentorProgress");
const masterEnabledToggle = document.getElementById("masterEnabledToggle");

// Общий выключатель расширения — работает сразу на всех открытых вкладках, без
// перезагрузки страниц (см. соответствующий слушатель socCopilotExtensionToggled
// в content.js). Значение по умолчанию — включено (undefined в storage ещё не
// значит "выключено", это просто "ключ ни разу не сохранялся").
chrome.storage.local.get(["socCopilotExtensionEnabled"], (data) => {
  masterEnabledToggle.checked = data.socCopilotExtensionEnabled !== false;
});
masterEnabledToggle.addEventListener("change", () => {
  const enabled = masterEnabledToggle.checked;
  chrome.storage.local.set({ socCopilotExtensionEnabled: enabled });
  chrome.tabs.query({}, (tabs) => {
    tabs.forEach((tab) => {
      if (tab.id) chrome.tabs.sendMessage(tab.id, { type: "socCopilotExtensionToggled", enabled }).catch(() => {});
    });
  });
});

chrome.storage.local.get(["socCopilotUITheme"], (data) => {
  if (data.socCopilotUITheme === "light") document.body.classList.add("sc-theme-light");
});

chrome.storage.local.get(
  ["socCopilotMentorProgress", "socCopilotBelZorBalance", "socCopilotEventsLog", "socCopilotConclusionsHistory"],
  (data) => {
    const mentorProgress = data.socCopilotMentorProgress;
    const balance = data.socCopilotBelZorBalance || 0;
    const eventsCount = (data.socCopilotEventsLog || []).length;
    const incidentsCount = (data.socCopilotConclusionsHistory || []).length;
    const lines = [];
    if (balance > 0 && typeof socCopilotBelZorRank === "function") {
      const rank = socCopilotBelZorRank(balance);
      lines.push(`${rank.emoji} ${balance} BelZor · ${rank.name}`);
    }
    if (eventsCount > 0 || incidentsCount > 0) {
      lines.push(`Событий: ${eventsCount} · Инцидентов закрыто: ${incidentsCount}`);
    }
    if (mentorProgress && mentorProgress.total > 0 && typeof socCopilotMentorLevel === "function") {
      const level = socCopilotMentorLevel(mentorProgress.correct);
      lines.push(`🎓 ${level.name} (${mentorProgress.correct}/${mentorProgress.total} верных)`);
    }
    if (lines.length) {
      mentorProgressEl.style.display = "block";
      mentorProgressEl.style.whiteSpace = "pre-line";
      mentorProgressEl.textContent = lines.join("\n");
    }
  }
);

chrome.tabs.query({ active: true, currentWindow: true }, ([tab]) => {
  if (!tab?.id) return;
  chrome.tabs.sendMessage(tab.id, { type: "socCopilotStatus" }, (resp) => {
    if (chrome.runtime.lastError || !resp) {
      statusEl.textContent = "Расширение не активно на этой странице (адаптер не настроен под её URL). Добавьте паттерн URL в настройках.";
      return;
    }
    if (resp.matched) {
      statusEl.textContent = `Платформа: ${resp.adapterName}\nОбнаружено IOC: ${resp.iocCount}`;
      statusEl.style.whiteSpace = "pre-line";
      toggleBtn.disabled = false;
    } else {
      statusEl.textContent = "Ни один адаптер не подошёл под эту страницу.";
    }
  });
});

toggleBtn.addEventListener("click", () => {
  chrome.tabs.query({ active: true, currentWindow: true }, ([tab]) => {
    chrome.tabs.sendMessage(tab.id, { type: "socCopilotTogglePanel" });
    window.close();
  });
});

optionsBtn.addEventListener("click", () => chrome.runtime.openOptionsPage());

const testSiemBtn = document.getElementById("testSiemBtn");
if (testSiemBtn) {
  testSiemBtn.addEventListener("click", () => {
    chrome.tabs.create({ url: chrome.runtime.getURL("test-siem.html") });
  });
}
