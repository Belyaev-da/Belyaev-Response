// utils/report-template.js
// Собирает черновик отчёта/эскалации в Markdown из извлечённых данных.
// Это НЕ окончательный вывод — аналитик проверяет и правит перед отправкой.

function socCopilotFormatIOCTable(iocMap) {
  const rows = [];
  for (const [type, values] of Object.entries(iocMap)) {
    values.forEach((v) => rows.push(`| ${type} | \`${v}\` |`));
  }
  if (!rows.length) return "_IOC не обнаружены автоматическим парсером._";
  return ["| Тип | Значение |", "|---|---|", ...rows].join("\n");
}

function socCopilotFormatMitre(mitreTechniques, mitrePredictions) {
  const detected = (mitreTechniques || [])
    .map((t) => `- **${t.id}** ${t.name} _(${t.tacticName})_`)
    .join("\n") || "_техники не распознаны_";
  const predicted = (mitrePredictions || [])
    .map((p) => `- ${p.id} ${p.name} _(${p.tacticName}, ${p.confidence === "curated" ? "по типовой связке" : "по позиции в kill chain"})_`)
    .join("\n") || "_недостаточно данных для прогноза_";
  return `**Обнаруженные техники:**\n${detected}\n\n**Эвристический прогноз следующего шага (требует проверки аналитиком):**\n${predicted}`;
}

function socCopilotBuildReport({ platformName, fields, iocMap, playbook, checkedSteps, mitreTechniques, mitrePredictions, url }) {
  const date = new Date().toISOString().slice(0, 16).replace("T", " ");
  const stepsBlock = (playbook?.steps || [])
    .map((s, i) => `- [${checkedSteps?.[i] ? "x" : " "}] ${s}`)
    .join("\n");

  return `## Черновик отчёта по инциденту

**Платформа:** ${platformName || "не определена"}
**Ссылка:** ${url || "—"}
**Сформировано:** ${date}

### Заголовок
${fields.title || "_не извлечён — заполните вручную_"}

### Описание
${fields.description || "_не извлечено — заполните вручную_"}

**Критичность:** ${fields.severity || "—"}
**Статус:** ${fields.status || "—"}
**Ответственный:** ${fields.assignee || "—"}
**Затронутые активы:** ${fields.assets || "—"}

### Обнаруженные индикаторы (IOC)
${socCopilotFormatIOCTable(iocMap)}

### MITRE ATT&CK
${socCopilotFormatMitre(mitreTechniques, mitrePredictions)}

### Рекомендованный плейбук: ${playbook?.name || "—"}
${stepsBlock || "_нет шагов_"}

### Вывод аналитика
_Заполните: FP/TP, причина, предпринятые действия, рекомендации._

---
_Черновик сгенерирован Belyaev Response автоматически. Проверьте перед отправкой — часть полей может быть извлечена некорректно._
`;
}

if (typeof module !== "undefined") {
  module.exports = { socCopilotBuildReport, socCopilotFormatIOCTable };
}
