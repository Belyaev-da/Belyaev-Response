// utils/mitre-attack.js
//
// MVP-модуль сопоставления текста карточки инцидента с MITRE ATT&CK.
// ВАЖНО: это эвристика (поиск по ключевым словам + курируемая таблица типовых
// переходов между техниками), а НЕ статистическая модель, обученная на
// реальных инцидентах, и не официальная база MITRE "как есть". Он даёт
// аналитику гипотезу для проверки, а не готовый вердикт. Список техник —
// намеренно ограниченный, курируемый набор для MVP (расширяется через
// синхронизацию с официальным CTI-репозиторием MITRE — см. background.js).

const SOC_COPILOT_TACTIC_ORDER = [
  { id: "reconnaissance", mitreId: "TA0043", name: "Разведка" },
  { id: "resource-development", mitreId: "TA0042", name: "Разработка ресурсов" },
  { id: "initial-access", mitreId: "TA0001", name: "Первичный доступ" },
  { id: "execution", mitreId: "TA0002", name: "Выполнение" },
  { id: "persistence", mitreId: "TA0003", name: "Закрепление" },
  { id: "privilege-escalation", mitreId: "TA0004", name: "Повышение привилегий" },
  { id: "defense-evasion", mitreId: "TA0005", name: "Обход защиты" },
  { id: "credential-access", mitreId: "TA0006", name: "Доступ к учётным данным" },
  { id: "discovery", mitreId: "TA0007", name: "Разведка в сети" },
  { id: "lateral-movement", mitreId: "TA0008", name: "Латеральное перемещение" },
  { id: "collection", mitreId: "TA0009", name: "Сбор данных" },
  { id: "command-and-control", mitreId: "TA0011", name: "Командование и контроль" },
  { id: "exfiltration", mitreId: "TA0010", name: "Эксфильтрация" },
  { id: "impact", mitreId: "TA0040", name: "Воздействие" }
];

// Курируемый набор техник для MVP (охватывает основные тактики).
// keywords — простые подстроки (ru/en), достаточные для demo-уровня точности;
// для продакшена стоит доработать через NLP/эмбеддинги вместо чистых regex.
const SOC_COPILOT_TECHNIQUE_SIGNATURES = [
  { id: "T1566", name: "Phishing", tacticId: "initial-access", keywords: ["фишинг", "phishing", "spearphish", "вредоносн вложен", "вложение письма"] },
  { id: "T1190", name: "Exploit Public-Facing Application", tacticId: "initial-access", keywords: ["exploit", "эксплойт", "rce", "уязвимост", "cve-"] },
  { id: "T1204", name: "User Execution", tacticId: "execution", keywords: ["открыл вложение", "кликнул по ссылке", "user execution", "запустил файл"] },
  { id: "T1059", name: "Command and Scripting Interpreter", tacticId: "execution", keywords: ["powershell", "cmd.exe", "wscript", "mshta", "bash -c", "скрипт запущен"] },
  { id: "T1053", name: "Scheduled Task/Job", tacticId: "persistence", keywords: ["schtasks", "scheduled task", "cron", "планировщик задач"] },
  { id: "T1547", name: "Boot or Logon Autostart Execution", tacticId: "persistence", keywords: ["autorun", "startup folder", "run key", "автозагрузк"] },
  { id: "T1055", name: "Process Injection", tacticId: "privilege-escalation", keywords: ["process injection", "инъекция в процесс", "process hollowing", "dll injection"] },
  { id: "T1068", name: "Exploitation for Privilege Escalation", tacticId: "privilege-escalation", keywords: ["privilege escalation", "повышение привилегий", "privesc"] },
  { id: "T1070", name: "Indicator Removal", tacticId: "defense-evasion", keywords: ["очистка логов", "log clearing", "wevtutil", "clear-eventlog"] },
  { id: "T1027", name: "Obfuscated Files or Information", tacticId: "defense-evasion", keywords: ["obfuscat", "обфусц", "base64 encoded payload", "packed binary", "упакован"] },
  { id: "T1562", name: "Impair Defenses", tacticId: "defense-evasion", keywords: ["disable defender", "отключение защитника", "disable antivirus", "stop-service", "отключ.. защит"] },
  { id: "T1003", name: "OS Credential Dumping", tacticId: "credential-access", keywords: ["mimikatz", "lsass", "dump credentials", "sam hive", "дамп учётных данных"] },
  { id: "T1110", name: "Brute Force", tacticId: "credential-access", keywords: ["brute force", "перебор пароля", "password spray"] },
  { id: "T1082", name: "System Information Discovery", tacticId: "discovery", keywords: ["systeminfo", "whoami", "ipconfig /all", "uname -a"] },
  { id: "T1087", name: "Account Discovery", tacticId: "discovery", keywords: ["net user", "get-aduser", "перечисление учётных записей"] },
  { id: "T1021", name: "Remote Services", tacticId: "lateral-movement", keywords: ["psexec", "wmi", "rdp подключение", "smb доступ", "winrm"] },
  { id: "T1550", name: "Use Alternate Authentication Material", tacticId: "lateral-movement", keywords: ["pass the hash", "pass-the-ticket", "pth"] },
  { id: "T1560", name: "Archive Collected Data", tacticId: "collection", keywords: ["архивация данных", "7z архив создан", "rar архив перед"] },
  { id: "T1113", name: "Screen Capture", tacticId: "collection", keywords: ["screenshot", "скриншот экрана", "screen capture"] },
  { id: "T1071", name: "Application Layer Protocol", tacticId: "command-and-control", keywords: ["c2", "command and control", "beacon", "http callback"] },
  { id: "T1105", name: "Ingress Tool Transfer", tacticId: "command-and-control", keywords: ["certutil -urlcache", "download payload", "загрузка полезной нагрузки"] },
  { id: "T1041", name: "Exfiltration Over C2 Channel", tacticId: "exfiltration", keywords: ["эксфильтрация", "exfiltration", "выгрузка данных наружу"] },
  { id: "T1567", name: "Exfiltration Over Web Service", tacticId: "exfiltration", keywords: ["google drive exfil", "dropbox exfil", "выгрузка через облако"] },
  { id: "T1486", name: "Data Encrypted for Impact", tacticId: "impact", keywords: ["ransomware", "шифровальщик", "файлы зашифрованы", ".locked"] },
  { id: "T1490", name: "Inhibit System Recovery", tacticId: "impact", keywords: ["vssadmin delete shadows", "удаление теневых копий", "disable backup"] }
];

// Курируемая таблица типовых переходов "после этой техники злоумышленники
// часто делают следующее" — упрощённая модель классической kill chain,
// НЕ статистика по реальным инцидентам конкретной организации.
const SOC_COPILOT_NEXT_STEP_HINTS = {
  T1566: ["T1204", "T1059"],
  T1190: ["T1059", "T1068"],
  T1204: ["T1059", "T1547"],
  T1059: ["T1053", "T1547", "T1055"],
  T1053: ["T1055", "T1068"],
  T1547: ["T1055", "T1068"],
  T1055: ["T1070", "T1027", "T1562"],
  T1068: ["T1070", "T1027", "T1562"],
  T1070: ["T1003", "T1110"],
  T1027: ["T1003", "T1110"],
  T1562: ["T1003", "T1110"],
  T1003: ["T1082", "T1087"],
  T1110: ["T1082", "T1087"],
  T1082: ["T1021", "T1550"],
  T1087: ["T1021", "T1550"],
  T1021: ["T1560", "T1113"],
  T1550: ["T1560", "T1113"],
  T1560: ["T1071", "T1105"],
  T1113: ["T1071", "T1105"],
  T1071: ["T1041", "T1567"],
  T1105: ["T1041", "T1567"],
  T1041: ["T1486", "T1490"],
  T1567: ["T1486", "T1490"],
  T1486: [],
  T1490: []
};

function socCopilotTacticById(id) {
  return SOC_COPILOT_TACTIC_ORDER.find((t) => t.id === id);
}

function socCopilotTechniqueById(id, extraDB) {
  return (
    (extraDB && extraDB[id]) ||
    SOC_COPILOT_TECHNIQUE_SIGNATURES.find((t) => t.id === id)
  );
}

function socCopilotMitreUrl(techniqueId) {
  return `https://attack.mitre.org/techniques/${techniqueId}/`;
}

// Определяет техники, упомянутые в тексте карточки, по ключевым словам.
function socCopilotDetectTechniques(text) {
  if (!text) return [];
  const lower = text.toLowerCase();
  const found = [];
  for (const sig of SOC_COPILOT_TECHNIQUE_SIGNATURES) {
    const hitKeyword = sig.keywords.find((k) => lower.includes(k.toLowerCase()));
    if (hitKeyword) {
      const tactic = socCopilotTacticById(sig.tacticId);
      found.push({
        id: sig.id,
        name: sig.name,
        tacticId: sig.tacticId,
        tacticName: tactic ? tactic.name : sig.tacticId,
        matchedOn: hitKeyword,
        url: socCopilotMitreUrl(sig.id)
      });
    }
  }
  return found;
}

// Эвристический прогноз следующего шага атаки на основе обнаруженных техник.
// Возвращает ранжированный список гипотез с уровнем уверенности:
// 'curated'  — есть прямая курируемая связка "после X часто идёт Y"
// 'heuristic'— общий вывод по позиции тактики в типовой kill chain
function socCopilotPredictNextSteps(detectedTechniqueIds) {
  if (!detectedTechniqueIds || !detectedTechniqueIds.length) return [];

  const detectedSet = new Set(detectedTechniqueIds);
  const suggestions = new Map(); // techniqueId -> {confidence, sources:[]}

  detectedTechniqueIds.forEach((id) => {
    const hints = SOC_COPILOT_NEXT_STEP_HINTS[id] || [];
    hints.forEach((hintId) => {
      if (detectedSet.has(hintId)) return; // уже наблюдалось
      if (!suggestions.has(hintId)) {
        suggestions.set(hintId, { confidence: "curated", sources: [id] });
      } else {
        suggestions.get(hintId).sources.push(id);
      }
    });
  });

  // Если ничего курируемого не нашлось, подставим общий эвристический шаг:
  // следующая тактика по порядку kill chain после самой "продвинутой" из обнаруженных.
  if (suggestions.size === 0) {
    const observedTactics = new Set(
      detectedTechniqueIds
        .map((id) => socCopilotTechniqueById(id))
        .filter(Boolean)
        .map((t) => t.tacticId)
    );
    const maxIdx = Math.max(
      ...Array.from(observedTactics).map((t) => SOC_COPILOT_TACTIC_ORDER.findIndex((x) => x.id === t)),
      -1
    );
    const nextTactic = SOC_COPILOT_TACTIC_ORDER[maxIdx + 1];
    if (nextTactic) {
      const candidate = SOC_COPILOT_TECHNIQUE_SIGNATURES.find((s) => s.tacticId === nextTactic.id);
      if (candidate) suggestions.set(candidate.id, { confidence: "heuristic", sources: [] });
    }
  }

  return Array.from(suggestions.entries())
    .map(([id, meta]) => {
      const sig = socCopilotTechniqueById(id);
      if (!sig) return null;
      const tactic = socCopilotTacticById(sig.tacticId);
      return {
        id,
        name: sig.name,
        tacticName: tactic ? tactic.name : sig.tacticId,
        confidence: meta.confidence,
        sources: meta.sources,
        url: socCopilotMitreUrl(id)
      };
    })
    .filter(Boolean)
    .slice(0, 6);
}

// Прогресс по kill chain: какие тактики уже "закрашены" обнаруженными техниками.
function socCopilotKillChainProgress(detectedTechniques) {
  const observed = new Set(detectedTechniques.map((t) => t.tacticId));
  return SOC_COPILOT_TACTIC_ORDER.map((t) => ({ ...t, observed: observed.has(t.id) }));
}

if (typeof module !== "undefined") {
  module.exports = {
    SOC_COPILOT_TACTIC_ORDER,
    SOC_COPILOT_TECHNIQUE_SIGNATURES,
    SOC_COPILOT_NEXT_STEP_HINTS,
    socCopilotDetectTechniques,
    socCopilotPredictNextSteps,
    socCopilotKillChainProgress,
    socCopilotMitreUrl
  };
}
