// utils/ioc-extractor.js
// Извлекает IOC-сущности из произвольного текста карточки инцидента.

const SOC_COPILOT_IOC_PATTERNS = {
  ipv4: /\b(?:(?:25[0-5]|2[0-4]\d|1?\d?\d)\.){3}(?:25[0-5]|2[0-4]\d|1?\d?\d)\b/g,
  ipv6: /\b(?:[a-fA-F0-9]{1,4}:){2,7}[a-fA-F0-9]{1,4}\b/g,
  mac: /\b[0-9A-Fa-f]{2}(?:[:-][0-9A-Fa-f]{2}){5}\b/g,
  // Хэши: убраны \b на концах — они не пропускают некоторые форматы в HTML-контексте.
  // Поддерживаем форматы: чистый хэш, SHA256:, MD5:, sha1:, hash=, (хэш)
  md5: /(?:^|[^a-fA-F0-9])([a-fA-F0-9]{32})(?:[^a-fA-F0-9]|$)/gm,
  sha1: /(?:^|[^a-fA-F0-9])([a-fA-F0-9]{40})(?:[^a-fA-F0-9]|$)/gm,
  sha256: /(?:^|[^a-fA-F0-9])([a-fA-F0-9]{64})(?:[^a-fA-F0-9]|$)/gm,
  cve: /\bCVE-\d{4}-\d{4,7}\b/gi,
  email: /\b[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}\b/g,
  url: /\b(?:https?|hxxps?):\/\/[^\s"'<>)\]]+/gi,
  // Домен: избегаем ложных срабатываний на файлы (.exe, .dll) простым списком известных TLD-паттернов не занимаемся,
  // берём консервативный шаблон и потом дедуплицируем/фильтруем IP/URL пересечения.
  domain: /\b(?:[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?\.)+(?:[a-zA-Z]{2,24})\b/g,
  registryPath: /\bHKEY_[A-Z_]+\\[^\s"']+/g,
  filePath: /\b[A-Za-z]:\\(?:[^\\\/:*?"<>|\r\n]+\\)*[^\\\/:*?"<>|\r\n]+\b/g
};

const SOC_COPILOT_FILE_EXT_BLOCKLIST = new Set([
  "exe","dll","sys","bat","ps1","docx","xlsx","pptx","pdf","zip","rar","7z",
  "js","py","tmp","log","dat","bin","txt","json","xml","csv"
]);

function socCopilotExtractIOCs(text) {
  if (!text) return {};
  const result = {};
  // Хэши используют capture groups (группа 1 = сам хэш, без контекстных символов),
  // остальные паттерны — без групп, работают через .match() напрямую.
  const hashTypes = new Set(["md5", "sha1", "sha256"]);
  for (const [type, pattern] of Object.entries(SOC_COPILOT_IOC_PATTERNS)) {
    let matches;
    if (hashTypes.has(type)) {
      pattern.lastIndex = 0;
      matches = Array.from(new Set(
        [...text.matchAll(pattern)].map((m) => (m[1] || m[0]).trim().toLowerCase())
      ));
    } else {
      matches = Array.from(new Set((text.match(pattern) || []).map((m) => m.trim())));
    }
    if (matches.length) result[type] = matches;
  }

  // MAC-адрес (XX:XX:XX:XX:XX:XX) по форме совпадает с шаблоном ipv6 (группы hex через
  // двоеточие) — убираем такие значения из ipv6, раз они уже правильно распознаны как MAC.
  if (result.ipv6 && result.mac) {
    const macSet = new Set(result.mac.map((m) => m.toLowerCase()));
    result.ipv6 = result.ipv6.filter((v) => !macSet.has(v.toLowerCase()));
    if (!result.ipv6.length) delete result.ipv6;
  }

  // Фильтруем домены: убираем то, что похоже на имя файла по расширению,
  // и убираем то, что уже распознано как IP/URL.
  if (result.domain) {
    const urlHosts = new Set(
      (result.url || []).map((u) => {
        try {
          return new URL(u.replace(/^hxxp/i, "http")).hostname.toLowerCase();
        } catch {
          return "";
        }
      })
    );
    result.domain = result.domain.filter((d) => {
      const ext = d.split(".").pop().toLowerCase();
      if (SOC_COPILOT_FILE_EXT_BLOCKLIST.has(ext)) return false;
      if (urlHosts.has(d.toLowerCase())) return false;
      if ((result.ipv4 || []).includes(d)) return false;
      return true;
    });
    if (!result.domain.length) delete result.domain;
  }

  return result;
}

function socCopilotCountIOCs(iocMap) {
  return Object.values(iocMap).reduce((sum, arr) => sum + arr.length, 0);
}

if (typeof module !== "undefined") {
  module.exports = { socCopilotExtractIOCs, socCopilotCountIOCs, SOC_COPILOT_IOC_PATTERNS };
}
