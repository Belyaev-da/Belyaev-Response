// utils/alert-storm.js
// Обнаруживает, что один и тот же паттерн (набор IOC/техник) повторяется во многих
// событиях за короткое время — лекарство от alert fatigue: вместо разбора 20 карточек
// по одной, аналитик видит "это одна и та же причина 18 раз" и закрывает массово с
// единой корневой причиной.

// eventsLog: [{urlKey, date, title, iocsFingerprint?}] — используем title как грубый
// прокси паттерна, если fingerprint не передан (для простоты и отсутствия лишних
// вычислений на каждое событие).
function socCopilotDetectAlertStorm(eventsLog, { windowMinutes = 60, minCount = 5 } = {}) {
  if (!eventsLog || eventsLog.length < minCount) return [];
  const cutoff = Date.now() - windowMinutes * 60 * 1000;
  const recent = eventsLog.filter((e) => new Date(e.date).getTime() >= cutoff);

  const groups = {};
  recent.forEach((e) => {
    const key = normalizeTitle(e.title);
    if (!key) return;
    groups[key] = groups[key] || [];
    groups[key].push(e);
  });

  return Object.entries(groups)
    .filter(([, items]) => items.length >= minCount)
    .map(([pattern, items]) => ({
      pattern,
      count: items.length,
      firstSeen: items.reduce((min, e) => (e.date < min ? e.date : min), items[0].date),
      lastSeen: items.reduce((max, e) => (e.date > max ? e.date : max), items[0].date),
      urls: items.map((e) => e.urlKey)
    }))
    .sort((a, b) => b.count - a.count);
}

// Нормализация заголовка: убираем числа/ID (часто разные в одинаковых по сути
// алертах, например "Failed login on host WS-042" vs "WS-091") — грубая, но полезная
// эвристика для группировки массовых однотипных срабатываний.
function normalizeTitle(title) {
  if (!title) return "";
  return title
    .toLowerCase()
    .replace(/\b[0-9a-f]{6,}\b/g, "#") // хэши/ID
    .replace(/\d+/g, "#") // числа (IP-октеты, ID хостов и т.п.)
    .replace(/\s+/g, " ")
    .trim();
}

if (typeof module !== "undefined") {
  module.exports = { socCopilotDetectAlertStorm, normalizeTitle };
}
