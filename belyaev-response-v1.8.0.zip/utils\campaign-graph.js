// utils/campaign-graph.js
// Строит граф связей между закрытыми инцидентами из локальной истории заключений —
// вместо текстового списка "похожих инцидентов" видно структуру: какие карточки
// объединены общими IOC/техниками, возможно, это одна кампания, а не разрозненные
// срабатывания.

function socCopilotBuildCampaignGraph(conclusionsHistory, { maxNodes = 30 } = {}) {
  const history = (conclusionsHistory || []).slice(0, maxNodes);
  const nodes = history.map((h, i) => ({
    id: i,
    title: h.title || "(без заголовка)",
    verdict: h.verdict || "unset",
    url: h.url,
    date: h.date,
    iocs: new Set(h.iocs || []),
    techniques: new Set(h.techniques || [])
  }));

  const edges = [];
  for (let i = 0; i < nodes.length; i++) {
    for (let j = i + 1; j < nodes.length; j++) {
      const iocOverlap = intersectionSize(nodes[i].iocs, nodes[j].iocs);
      const techOverlap = intersectionSize(nodes[i].techniques, nodes[j].techniques);
      const weight = iocOverlap * 2 + techOverlap;
      if (weight > 0) edges.push({ source: i, target: j, weight });
    }
  }

  // Узлы без единой связи неинтересны для графа кампании — отфильтровываем, чтобы
  // не загромождать визуализацию полностью изолированными точками.
  const connectedIds = new Set();
  edges.forEach((e) => {
    connectedIds.add(e.source);
    connectedIds.add(e.target);
  });

  return {
    nodes: nodes
      .filter((n) => connectedIds.has(n.id))
      .map((n) => ({ id: n.id, title: n.title, verdict: n.verdict, url: n.url, date: n.date })),
    edges
  };
}

function intersectionSize(setA, setB) {
  let count = 0;
  for (const item of setA) {
    if (setB.has(item)) count++;
  }
  return count;
}

// Простая детерминированная круговая раскладка узлов — без физической симуляции
// (force-directed), т.к. для десятков узлов кругового расположения достаточно для
// читаемости, а детерминированность упрощает тестирование и предсказуемость UI.
function socCopilotLayoutCircular(nodes, { width = 320, height = 260 } = {}) {
  const cx = width / 2;
  const cy = height / 2;
  const radius = Math.min(width, height) / 2 - 30;
  return nodes.map((n, i) => {
    const angle = (2 * Math.PI * i) / Math.max(1, nodes.length);
    return { ...n, x: cx + radius * Math.cos(angle), y: cy + radius * Math.sin(angle) };
  });
}

if (typeof module !== "undefined") {
  module.exports = { socCopilotBuildCampaignGraph, socCopilotLayoutCircular };
}
