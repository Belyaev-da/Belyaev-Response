// utils/conclusion-template.js
// Формирует формальное заключение по инциденту (для закрытия/архива/подписи),
// в отличие от report-template.js, который собирает рабочий черновик для эскалации.

const SOC_COPILOT_VERDICTS = {
  tp: "True Positive — подтверждённый инцидент",
  fp: "False Positive — ложное срабатывание",
  benign: "Benign — штатная активность, не инцидент",
  escalate: "Требует эскалации / дальнейшего расследования"
};

function socCopilotFormatIOCTableShort(iocMap) {
  const rows = [];
  for (const [type, values] of Object.entries(iocMap || {})) {
    values.forEach((v) => rows.push(`| ${type} | \`${v}\` |`));
  }
  if (!rows.length) return "_IOC не обнаружены._";
  return ["| Тип | Значение |", "|---|---|", ...rows].join("\n");
}

function socCopilotFormatTechniquesShort(techniques) {
  if (!techniques || !techniques.length) return "_техники ATT&CK не распознаны_";
  return techniques.map((t) => `- **${t.id}** ${t.name} _(${t.tacticName})_`).join("\n");
}

function socCopilotBuildConclusion({
  platformName,
  url,
  fields,
  iocMap,
  mitreTechniques,
  playbook,
  checkedSteps,
  verdict,
  rootCause,
  impact,
  actionsTaken,
  recommendations
}) {
  const date = new Date().toISOString().slice(0, 16).replace("T", " ");
  const verdictLabel = SOC_COPILOT_VERDICTS[verdict] || "не выбран";
  const stepsDone = (playbook?.steps || [])
    .map((s, i) => `- [${checkedSteps?.[i] ? "x" : " "}] ${s}`)
    .join("\n");

  return `# Заключение по инциденту

**Платформа:** ${platformName || "—"}
**Ссылка:** ${url || "—"}
**Дата заключения:** ${date}
**Аналитик:** _впишите ФИО/логин_

## Вердикт
**${verdictLabel}**

## Краткое описание
${fields?.title || "_не извлечено_"}

${(fields?.description || "").slice(0, 500) || "_описание не извлечено_"}

## Причина / вектор атаки
${rootCause?.trim() || "_не указано аналитиком_"}

## Воздействие
${impact?.trim() || "_не указано аналитиком_"}

## Подтверждённые индикаторы (IOC)
${socCopilotFormatIOCTableShort(iocMap)}

## Тактики и техники MITRE ATT&CK
${socCopilotFormatTechniquesShort(mitreTechniques)}

## Пройденные шаги плейбука
${stepsDone || "_плейбук не использовался_"}

## Предпринятые действия
${actionsTaken?.trim() || "_не указано аналитиком_"}

## Рекомендации
${recommendations?.trim() || "_не указано аналитиком_"}

---
_Черновик сформирован Belyaev Response автоматически на основе данных карточки и ввода аналитика.
Перед архивированием/отправкой проверьте корректность всех полей и подпишите заключение._
`;
}

if (typeof module !== "undefined") {
  module.exports = { socCopilotBuildConclusion, SOC_COPILOT_VERDICTS };
}
