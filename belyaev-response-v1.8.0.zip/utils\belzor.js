// utils/belzor.js
// BelZor — внутренняя валюта поощрения за качественно закрытые инциденты.
// Название: "Бел" (Беляев) + "Зор" (зоркость/внимательность).
//
// Принцип начисления: базовая награда зависит от критичности инцидента (чем выше
// критичность — тем больше ответственности было на аналитике), плюс небольшие бонусы
// за индикаторы качественной работы (использование MITRE-контекста, полное прохождение
// плейбука, фактическая проверка IOC через TI вместо угадывания). Это НЕ оценка точности
// вердикта (у плагина нет способа проверить, кто прав) — только поощрение за тщательность
// процесса, что осознанно и не должно выдаваться за объективную метрику качества.

const SOC_COPILOT_BELZOR_BASE = {
  critical: 50,
  high: 30,
  medium: 15,
  low: 5
};

const SOC_COPILOT_BELZOR_BONUSES = {
  mitreMapped: 5, // техники ATT&CK были распознаны и учтены
  playbookComplete: 5, // чек-лист плейбука пройден полностью
  verifiedEnrichment: 10 // хотя бы один IOC был фактически проверен через TI (не просто предположен)
};

const SOC_COPILOT_BELZOR_RANKS = [
  { name: "Новобранец", min: 0, emoji: "🥉" },
  { name: "Внимательный", min: 100, emoji: "🥈" },
  { name: "Бдительный", min: 300, emoji: "🥇" },
  { name: "Страж (BelZor Guardian)", min: 700, emoji: "🛡️" },
  { name: "Мастер реагирования", min: 1500, emoji: "👑" }
];

// Определяет критичность инцидента: сперва пытается разобрать текст поля "критичность"
// с карточки (разные языки/термины разных SIEM), при неудаче — оценивает по эвристическому
// риск-скору (см. computeRiskBadge в content.js), который уже используется для бейджа на иконке.
function socCopilotDetectSeverityTier(severityText, riskScore) {
  const t = (severityText || "").toLowerCase();
  if (/critical|критич|блокер/.test(t)) return "critical";
  if (/high|высок/.test(t)) return "high";
  if (/medium|средн/.test(t)) return "medium";
  if (/low|низк|info|информац/.test(t)) return "low";
  const score = typeof riskScore === "number" ? riskScore : 0;
  if (score >= 12) return "critical";
  if (score >= 6) return "high";
  if (score >= 1) return "medium";
  return "low";
}

function socCopilotComputeBelZor({ severityText, riskScore, mitreCount, playbookCompleteRatio, hasVerifiedEnrichment }) {
  const tier = socCopilotDetectSeverityTier(severityText, riskScore);
  const base = SOC_COPILOT_BELZOR_BASE[tier];
  let bonus = 0;
  const bonusDetails = [];
  if (mitreCount > 0) {
    bonus += SOC_COPILOT_BELZOR_BONUSES.mitreMapped;
    bonusDetails.push(`+${SOC_COPILOT_BELZOR_BONUSES.mitreMapped} за использование MITRE ATT&CK`);
  }
  if (playbookCompleteRatio === 1) {
    bonus += SOC_COPILOT_BELZOR_BONUSES.playbookComplete;
    bonusDetails.push(`+${SOC_COPILOT_BELZOR_BONUSES.playbookComplete} за полное прохождение плейбука`);
  }
  if (hasVerifiedEnrichment) {
    bonus += SOC_COPILOT_BELZOR_BONUSES.verifiedEnrichment;
    bonusDetails.push(`+${SOC_COPILOT_BELZOR_BONUSES.verifiedEnrichment} за проверку IOC через TI`);
  }
  return { tier, base, bonus, total: base + bonus, bonusDetails };
}

function socCopilotBelZorRank(balance) {
  let rank = SOC_COPILOT_BELZOR_RANKS[0];
  for (const r of SOC_COPILOT_BELZOR_RANKS) {
    if (balance >= r.min) rank = r;
  }
  return rank;
}

function socCopilotBelZorNextRank(balance) {
  return SOC_COPILOT_BELZOR_RANKS.find((r) => r.min > balance) || null;
}

if (typeof module !== "undefined") {
  module.exports = {
    SOC_COPILOT_BELZOR_BASE,
    SOC_COPILOT_BELZOR_BONUSES,
    SOC_COPILOT_BELZOR_RANKS,
    socCopilotDetectSeverityTier,
    socCopilotComputeBelZor,
    socCopilotBelZorRank,
    socCopilotBelZorNextRank
  };
}
