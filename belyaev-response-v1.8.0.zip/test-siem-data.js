// test-siem-data.js — синтетические сценарии тестового стенда.
// Было инлайновым <script> внутри test-siem.html — вынесено в отдельный файл,
// потому что MV3 блокирует инлайн-скрипты на страницах расширения (CSP
// script-src 'self'): при открытии этой страницы через chrome-extension://
// (кнопка «Тестовый стенд SIEM» в popup) инлайн-скрипт не выполнялся вовсе,
// и карточка так и оставалась на «Загрузка…».

const SCENARIOS = {
  phishing: {
    title: "Подозрительная активность на WS-0042 после фишингового письма",
    severity: '<span class="sev-high">High</span>',
    category: "Фишинг / Credential Dumping",
    assets: "WS-0042, DC-01",
    description:
`Пользователь ivanov.i@test-company.example открыл вложение письма (тема: "Срочно: акт сверки Q3").
Через 2 мин на хосте WS-0042 запущен процесс powershell.exe со скачиванием payload:
  hxxps://evil-c2-test.example/update.exe (IP: 203.0.113.10)

Обнаружен процесс mimikatz.exe — выполнен дамп учётных данных из lsass.exe.
Создана задача через schtasks для закрепления: "WindowsUpdateHelper".
Зафиксировано RDP-подключение к DC-01 (192.0.2.55) с учётной записью TESTDOMAIN\\svc_backup.

Индикаторы компрометации:
  IPv4 C2: 203.0.113.10
  IPv4 DC: 192.0.2.55
  Домен C2: evil-c2-test.example
  SHA256 payload: a1b2c3d4e5f6a1b2c3d4e5f6a1b2c3d4e5f6a1b2c3d4e5f6a1b2c3d4e5f6a1b2
  MD5 mimikatz: 098f6bcd4621d373cade4e832627b4f6
  SHA1 lsass dump: aaf4c61ddcc5e8a2dabede0f3b482cd9aea9434d
  MAC заражённого хоста: 00:1A:2B:3C:4D:5E
  CVE-2024-12345 (использована для первичного доступа)

Фрагмент приватного ключа из артефактов (тест обезличивания!):
  -----BEGIN OPENSSH PRIVATE KEY-----
  b3BlbnNzaC1rZXktdjEAAAAEbm9uZQAAAAAAAAABAAAAMwAAAAtzc2gtZWQyNTUxOQ
  -----END OPENSSH PRIVATE KEY-----

Компания (тест обезличивания): АО «Тестовая Компания»`,
    timeline: "10:02 — открытие вложения · 10:04 — powershell download · 10:07 — mimikatz/lsass · 10:12 — schtasks · 10:15 — RDP на DC-01"
  },
  ransom: {
    title: "Активность шифровальщика на файловом сервере FS-01",
    severity: '<span class="sev-critical">Critical</span>',
    category: "Ransomware / Impact",
    assets: "FS-01, BACKUP-SRV",
    description:
`На хосте FS-01 (198.51.100.15) обнаружены массово зашифрованные файлы с расширением .locked.
Общий объём: ~15 000 файлов в \\\\FS-01\\SHARE_DOCS за 8 минут.

Предшествующие действия (найдены в EDR-логах):
  - vssadmin.exe delete shadows /all /quiet  — удаление теневых копий
  - wevtutil.exe cl System  — очистка системных логов
  - sc config WinDefend start=disabled  — отключение Defender
  - bcdedit.exe /set {default} recoveryenabled No

Связь с C2 до начала шифрования:
  Домен: evil-c2-test.example (IP: 203.0.113.44)
  Паттерн: HTTP POST каждые 60 сек (beacon), UA: "Mozilla/5.0 (Windows NT 10.0)"

SHA256 образца: b2c3d4e5f6a1b2c3d4e5f6a1b2c3d4e5f6a1b2c3d4e5f6a1b2c3d4e5f6a1b2c3
MD5 образца: 5d41402abc4b2a76b9719d911017c592
CVE-2023-98765 — использована для первичного доступа через VPN.

Бэкап: BACKUP-SRV — статус проверяется (возможно зашифрован).`,
    timeline: "14:50 — C2 beacon · 14:55 — vssadmin/wevtutil/defender · 15:03 — старт шифрования · 15:11 — ~15k файлов зашифровано"
  },
  c2: {
    title: "Обнаружен периодический C2-трафик с хоста DEV-07",
    severity: '<span class="sev-medium">Medium</span>',
    category: "Command & Control / Beaconing",
    assets: "DEV-07",
    description:
`Система обнаружения аномалий зафиксировала периодический (каждые 300 сек) HTTP-трафик
с хоста DEV-07 (198.51.100.77) на внешний адрес 203.0.113.200.

Характеристики трафика (признаки beacon):
  - Интервал: 300±10 сек (jitter 3%)
  - Размер запросов: 142-198 байт (фиксированный, характерно для Cobalt Strike)
  - User-Agent: "Mozilla/5.0 (Windows NT 10.0; Win64; x64)" (часто подделывается)
  - Протокол: HTTPS (cert самоподписанный, CN=*.microsoft-update.example)
  - Домен C2: microsoft-update.example (зарегистрирован 3 дня назад)

Процесс-источник: svchost.exe (PID 4832, parent: services.exe)
Path: C:\\Windows\\Temp\\svchost32.exe → инъектирован в настоящий svchost.exe

Хэши:
  SHA256 svchost32.exe: c3d4e5f6a1b2c3d4e5f6a1b2c3d4e5f6a1b2c3d4e5f6a1b2c3d4e5f6a1b2c3d4
  MD5: d41d8cd98f00b204e9800998ecf8427e

IP C2: 203.0.113.200
Домен C2: microsoft-update.example
MAC хоста: AA:BB:CC:11:22:33

Первый коммит трафика: 5 дней назад. Возможно медленное закрепление (low&slow).`,
    timeline: "5 дней назад — первый beacon · сегодня 08:14 — алерт NTA-системы · 09:02 — подтверждение SOC L2 · 09:15 — открытие инцидента"
  }
};

function render(scn) {
  const s = SCENARIOS[scn];
  document.getElementById("bt-title").textContent = s.title;
  document.getElementById("bt-severity").innerHTML = s.severity;
  document.getElementById("bt-category").textContent = s.category;
  document.getElementById("bt-assets").textContent = s.assets;
  document.getElementById("bt-description").textContent = s.description;
  document.getElementById("bt-timeline").textContent = s.timeline;
  document.querySelectorAll(".scn-btns button").forEach(b => b.classList.remove("active"));
  document.getElementById("scn-" + scn).classList.add("active");
}

document.getElementById("scn-phishing").addEventListener("click", () => render("phishing"));
document.getElementById("scn-ransom").addEventListener("click", () => render("ransom"));
document.getElementById("scn-c2").addEventListener("click", () => render("c2"));
render("phishing");
