// utils/response-snippets.js
// Готовые команды для блокировки/изоляции подтверждённого IOC на типовых
// инструментах. ВСЕГДА copy-paste — плагин НИКОГДА не выполняет их сам (нет ни
// одного fetch/exec в этом файле). Аналитик проверяет и запускает вручную в своей
// консоли — это осознанная защита от случайного/автоматического деструктивного
// действия по ложному срабатыванию.

function socCopilotBuildResponseSnippets(iocType, value) {
  const v = String(value || "").trim();
  if (!v) return [];

  if (iocType === "ipv4" || iocType === "ipv6") {
    return [
      { tool: "Windows Firewall (netsh)", command: `netsh advfirewall firewall add rule name="Block-${v}" dir=out action=block remoteip=${v}` },
      { tool: "Linux iptables", command: `iptables -A OUTPUT -d ${v} -j DROP && iptables -A INPUT -s ${v} -j DROP` },
      { tool: "Cisco ASA/IOS ACL", command: `access-list BLOCK_C2 deny ip any host ${v}` },
      { tool: "pfSense/OPNsense (alias)", command: `# Добавить ${v} в алиас блок-листа через Firewall → Aliases, затем правило Block на WAN` }
    ];
  }
  if (iocType === "domain" || iocType === "url") {
    const domain = iocType === "url" ? (() => {
      try { return new URL(v.replace(/^hxxp/i, "http")).hostname; } catch { return v; }
    })() : v;
    return [
      { tool: "Windows hosts-файл (быстрая блокировка)", command: `Add-Content -Path C:\\Windows\\System32\\drivers\\etc\\hosts -Value "0.0.0.0 ${domain}"` },
      { tool: "BIND DNS RPZ", command: `${domain} CNAME . ; блокировка через Response Policy Zone` },
      { tool: "Squid proxy ACL", command: `acl blocked_domains dstdomain ${domain}\nhttp_access deny blocked_domains` }
    ];
  }
  if (iocType === "hash" || iocType === "md5" || iocType === "sha1" || iocType === "sha256") {
    return [
      { tool: "Windows Defender (PowerShell)", command: `Add-MpPreference -ThreatIDDefaultAction_Actions Block -ThreatIDDefaultAction_Ids <ID> # либо через Indicator: New-MpThreatCatalogEntry` },
      { tool: "CrowdStrike Falcon (пример IOC API)", command: `# Добавить в Custom IOC: тип=hash, значение=${v}, действие=Block через консоль Falcon` },
      { tool: "YARA (сигнатура для сканирования)", command: `rule Block_${v.slice(0, 8)} {\n  strings:\n    $hash = "${v}"\n  condition:\n    hash.sha256(0, filesize) == "${v}"\n}` }
    ];
  }
  return [];
}

if (typeof module !== "undefined") {
  module.exports = { socCopilotBuildResponseSnippets };
}
