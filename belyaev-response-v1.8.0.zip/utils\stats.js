// utils/stats.js
// Счётчики и отчёты. Определения (важно для прозрачности перед аналитиком/руководителем):
// - "Событие" = уникальная карточка (по URL), которую плагин распознал и разобрал хотя бы
//   один раз — то есть аналитик её открывал и работал с ней в этом браузере.
// - "Инцидент" = карточка, по которой аналитик СОХРАНИЛ заключение (вкладка «Заключение» →
//   «Сохранить как завершённое»). Просмотренная, но не завершённая карточка в инциденты
//   не попадает — так счётчик отражает реально закрытую работу, а не количество кликов.
// Все данные считаются ТОЛЬКО локально, по истории конкретного браузера конкретного
// аналитика — это не агрегированная статистика по всей команде SOC.

const SOC_COPILOT_PERIODS = [
  { id: "week", label: "Неделя", days: 7 },
  { id: "month", label: "Месяц", days: 30 },
  { id: "quarter", label: "Квартал", days: 91 },
  { id: "halfyear", label: "Полугодие", days: 182 },
  { id: "year", label: "Год", days: 365 }
];

function socCopilotFilterByPeriod(list, days, dateField = "date", now = Date.now()) {
  const cutoff = now - days * 24 * 60 * 60 * 1000;
  return (list || []).filter((item) => {
    const t = new Date(item[dateField]).getTime();
    return !isNaN(t) && t >= cutoff;
  });
}

function socCopilotAggregateStats(eventsLog, conclusionsHistory, belZorLog, days, now = Date.now()) {
  const events = socCopilotFilterByPeriod(eventsLog, days, "date", now);
  const incidents = socCopilotFilterByPeriod(conclusionsHistory, days, "date", now);
  const belZorEntries = socCopilotFilterByPeriod(belZorLog, days, "date", now);

  const byVerdict = { tp: 0, fp: 0, benign: 0, escalate: 0, unset: 0 };
  incidents.forEach((h) => {
    const key = h.verdict && byVerdict.hasOwnProperty(h.verdict) ? h.verdict : "unset";
    byVerdict[key] += 1;
  });

  const belZorEarned = belZorEntries.reduce((sum, e) => sum + (e.amount || 0), 0);
  const byTier = { critical: 0, high: 0, medium: 0, low: 0 };
  belZorEntries.forEach((e) => {
    if (e.tier && byTier.hasOwnProperty(e.tier)) byTier[e.tier] += 1;
  });

  return {
    eventsCount: events.length,
    incidentsCount: incidents.length,
    byVerdict,
    belZorEarned,
    byTier
  };
}

function socCopilotEscapeCSV(value) {
  const s = String(value ?? "");
  if (/[",\n]/.test(s)) return '"' + s.replace(/"/g, '""') + '"';
  return s;
}

function socCopilotBuildCSVReport(conclusionsHistory) {
  const header = ["Дата", "Заголовок", "Платформа", "Вердикт", "Ссылка"];
  const rows = (conclusionsHistory || []).map((h) => [
    h.date ? new Date(h.date).toLocaleString("ru-RU") : "",
    h.title || "",
    h.platform || "",
    h.verdict || "",
    h.url || ""
  ]);
  const lines = [header, ...rows].map((row) => row.map(socCopilotEscapeCSV).join(","));
  return "\uFEFF" + lines.join("\r\n"); // BOM для корректного открытия кириллицы в Excel
}

if (typeof module !== "undefined") {
  module.exports = {
    SOC_COPILOT_PERIODS,
    socCopilotFilterByPeriod,
    socCopilotAggregateStats,
    socCopilotBuildCSVReport,
    socCopilotEscapeCSV
  };
}
