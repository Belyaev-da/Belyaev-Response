// utils/detection-rules.js
// Черновик detection-правила (Sigma/YARA) из уже закрытого инцидента — замыкает цикл
// "расследовал -> научи систему ловить это автоматически", а не только вручную.
// Это ЧЕРНОВИК: аналитик/detection engineer обязан проверить синтаксис и логику
// перед внедрением в продуктив — плагин не гарантирует валидность правила.

function socCopilotBuildSigmaDraft({ title, mitreTechniques, iocMap, platformName }) {
  const techniqueTags = (mitreTechniques || []).map((t) => `attack.${t.id.toLowerCase()}`);
  const iocLines = [];
  if (iocMap?.ipv4?.length) iocLines.push(`      DestinationIp:\n${iocMap.ipv4.map((v) => `        - '${v}'`).join("\n")}`);
  if (iocMap?.domain?.length) iocLines.push(`      DestinationHostname:\n${iocMap.domain.map((v) => `        - '${v}'`).join("\n")}`);
  if (iocMap?.sha256?.length) iocLines.push(`      Hashes|contains:\n${iocMap.sha256.map((v) => `        - 'SHA256=${v.toUpperCase()}'`).join("\n")}`);

  return `title: ${title || "Черновик правила из инцидента Belyaev Response"}
id: ${cryptoRandomIdLike()}
status: experimental  # ОБЯЗАТЕЛЬНО проверьте перед переводом в production
description: Автосгенерированный черновик по закрытому инциденту (${platformName || "SIEM"}). Требует ревью detection engineer.
references:
  - internal-incident-review
tags:
${techniqueTags.map((t) => `  - ${t}`).join("\n") || "  # техники ATT&CK не определены — добавьте вручную"}
logsource:
  category: network_connection  # УТОЧНИТЕ под реальный источник логов
  product: windows
detection:
  selection:
${iocLines.join("\n") || "      # индикаторы не найдены — добавьте условия вручную"}
  condition: selection
falsepositives:
  - Требуется ручная проверка на легитимные случаи перед включением
level: medium
`;
}

function socCopilotBuildYaraDraft({ title, iocMap }) {
  const hashes = (iocMap?.sha256 || []).concat(iocMap?.md5 || []);
  const ruleName = "Belyaev_" + (title || "incident").replace(/[^A-Za-z0-9_]/g, "_").slice(0, 40);
  if (!hashes.length) {
    return `// Черновик YARA-правила: хэши файлов не найдены в этом инциденте.\n// YARA лучше всего работает по хэшам/строкам образца — добавьте условия вручную,\n// если есть образец вредоносного файла.\nrule ${ruleName} {\n  condition:\n    false // заполните вручную\n}\n`;
  }
  return `rule ${ruleName} {
  meta:
    description = "Черновик по закрытому инциденту Belyaev Response — ТРЕБУЕТ РЕВЬЮ"
    status = "experimental"
  condition:
${hashes.map((h) => `    hash.sha256(0, filesize) == "${h.toLowerCase()}" or hash.md5(0, filesize) == "${h.toLowerCase()}"`).join(" or\n")}
}
`;
}

// Простой детерминированный id-подобный идентификатор (не настоящий UUID, но
// достаточно уникален для черновика — заменяется реальным при ревью правила).
function cryptoRandomIdLike() {
  return "draft-" + Math.random().toString(16).slice(2, 10) + "-" + Date.now().toString(16);
}

if (typeof module !== "undefined") {
  module.exports = { socCopilotBuildSigmaDraft, socCopilotBuildYaraDraft };
}
