// utils/mentor.js
// Наставник для L1-аналитика. Педагогические принципы, на которых построен модуль:
// - Just-in-time learning: объяснения привязаны к РЕАЛЬНЫМ данным текущего инцидента,
//   а не к абстрактным примерам — так знание сразу применяется на практике.
// - Scaffolding: от простого (посмотреть на заголовок) к сложному (вынести вердикт).
// - Активное вспоминание вместо пассивного чтения: короткие квизы с мгновенной
//   обратной связью и объяснением "почему", а не просто "правильно/неправильно".
// - Рефлексия для задач без единственного правильного ответа (вердикт TP/FP,
//   приоретизация шагов плейбука) — сравнение своего рассуждения с эвристикой
//   опытного аналитика, а не жёсткая оценка.
// - Прогресс и лёгкая геймификация (уровни) — для мотивации и видимости роста.

const SOC_COPILOT_IOC_TYPE_LABELS = {
  ipv4: "IPv4-адрес",
  ipv6: "IPv6-адрес",
  mac: "MAC-адрес",
  domain: "домен",
  url: "URL-ссылка",
  md5: "хэш файла (MD5)",
  sha1: "хэш файла (SHA1)",
  sha256: "хэш файла (SHA256)",
  email: "email-адрес",
  cve: "идентификатор уязвимости (CVE)",
  registryPath: "путь в реестре Windows",
  filePath: "путь к файлу"
};

const SOC_COPILOT_MENTOR_LEVELS = [
  { name: "Стажёр", min: 0 },
  { name: "Начинающий L1", min: 5 },
  { name: "Уверенный L1", min: 15 },
  { name: "Готов к переходу на L2", min: 30 }
];

function socCopilotMentorLevel(correctCount) {
  let level = SOC_COPILOT_MENTOR_LEVELS[0];
  for (const l of SOC_COPILOT_MENTOR_LEVELS) {
    if (correctCount >= l.min) level = l;
  }
  return level;
}

function socCopilotMentorNextLevel(correctCount) {
  return SOC_COPILOT_MENTOR_LEVELS.find((l) => l.min > correctCount) || null;
}

// Строит трёхвариантный квиз "определи тип IOC" с двумя правдоподобными
// дистракторами (не случайными — из соседних категорий, чтобы квиз учил различать
// похожие вещи, а не угадывать очевидное).
function socCopilotBuildIOCQuiz(iocMap) {
  const entries = Object.entries(iocMap || {});
  if (!entries.length) return null;
  const [correctType, values] = entries[0];
  const value = values[0];
  const distractorPool = Object.keys(SOC_COPILOT_IOC_TYPE_LABELS).filter((t) => t !== correctType);
  const distractors = distractorPool.slice(0, 2);
  const options = [correctType, ...distractors]
    .map((t) => SOC_COPILOT_IOC_TYPE_LABELS[t] || t)
    .sort(() => 0.5 - hashSeed(value)); // детерминированное "перемешивание" по значению, без Math.random для тестируемости
  const correctIndex = options.indexOf(SOC_COPILOT_IOC_TYPE_LABELS[correctType]);
  return {
    question: `Как думаешь, что это за индикатор: "${value}"?`,
    options,
    correctIndex,
    explain: `Это ${SOC_COPILOT_IOC_TYPE_LABELS[correctType] || correctType}. Определить тип важно до похода в TI-сервис — для IP и доменов обычно используют AbuseIPDB/VirusTotal, для хэшей файлов — VirusTotal Files.`
  };
}

// Простой детерминированный "псевдослучайный" хэш строки в [0,1) — нужен только
// для стабильного порядка вариантов ответа (чтобы тесты были воспроизводимы).
function hashSeed(str) {
  let h = 0;
  for (let i = 0; i < str.length; i++) h = (h * 31 + str.charCodeAt(i)) >>> 0;
  return (h % 1000) / 1000;
}

function socCopilotBuildMitreQuiz(mitreTechniques, tacticOrder) {
  if (!mitreTechniques || !mitreTechniques.length) return null;
  const observedTacticIds = [...new Set(mitreTechniques.map((t) => t.tacticId))];
  const lastTacticId = observedTacticIds
    .map((id) => tacticOrder.findIndex((t) => t.id === id))
    .sort((a, b) => b - a)[0];
  const lastTactic = tacticOrder[lastTacticId];
  if (!lastTactic) return null;
  const distractors = tacticOrder.filter((t) => t.id !== lastTactic.id);
  const d1 = distractors[Math.floor(hashSeed(lastTactic.id) * distractors.length)];
  const d2 = distractors[(distractors.indexOf(d1) + 3) % distractors.length];
  const options = [lastTactic, d1, d2].map((t) => t.name);
  const correctIndex = 0; // после сборки не перемешиваем — детерминированность для тестов важнее
  return {
    question: "Судя по обнаруженным техникам, какая тактика ATT&CK уже была пройдена атакующим?",
    options,
    correctIndex,
    explain: `Наблюдалась тактика «${lastTactic.name}». Порядок тактик в ATT&CK примерно соответствует хронологии атаки — зная текущий этап, легче предположить следующий шаг.`
  };
}

// Главная функция: строит последовательность обучающих шагов для текущей карточки.
// ctx: { fields, iocMap, playbook, mitreTechniques, tacticOrder, adapterName }
function socCopilotBuildMentorSteps(ctx) {
  const steps = [];

  steps.push({
    id: "intro",
    title: "С чего начать разбор",
    highlightField: "title",
    explain:
      "Первым делом посмотри на заголовок и критичность карточки — они задают приоритет: " +
      "насколько срочно этим нужно заниматься прямо сейчас, и не стоит ли отложить менее " +
      "срочные задачи.",
    quiz: null,
    reflection: null
  });

  const iocCount = Object.values(ctx.iocMap || {}).reduce((s, v) => s + v.length, 0);
  steps.push({
    id: "ioc",
    title: "Индикаторы компрометации (IOC)",
    highlightField: "rawContainer",
    explain: iocCount
      ? `Плагин автоматически нашёл ${iocCount} индикатор(ов) в тексте карточки. Правило: ` +
        "каждый индикатор нужно проверить через TI-сервис перед выводами — свежий вредонос " +
        "может ещё не попасть в базы репутации, поэтому «чисто в VirusTotal» ≠ «безопасно»."
      : "На этой карточке индикаторы не найдены автоматическим парсером — это не значит, что их " +
        "нет. Посмотри на текст карточки вручную: иногда IOC спрятан в нестандартном формате.",
    quiz: iocCount ? socCopilotBuildIOCQuiz(ctx.iocMap) : null,
    reflection: null
  });

  steps.push({
    id: "playbook",
    title: "Зачем нужен плейбук",
    highlightField: null,
    explain: ctx.playbook
      ? `Плагин подобрал плейбук «${ctx.playbook.name}» — по совпадению ключевых слов в тексте ` +
        "карточки. Плейбук — это не бюрократия, а страховка: он не даёт пропустить важный шаг, " +
        "когда времени мало и хочется закрыть тикет побыстрее."
      : "Плейбук не подобрался автоматически. Уточни у старшего аналитика или в базе знаний, какой " +
        "чек-лист использовать для этого типа инцидента — не полагайся только на память.",
    quiz: null,
    reflection: ctx.playbook ? "Какой шаг из чек-листа сейчас самый важный и почему? Сравни свою логику с порядком шагов в плейбуке." : null
  });

  const mitreQuiz = socCopilotBuildMitreQuiz(ctx.mitreTechniques, ctx.tacticOrder || []);
  steps.push({
    id: "mitre",
    title: "MITRE ATT&CK — общий язык описания атак",
    highlightField: null,
    explain:
      ctx.mitreTechniques && ctx.mitreTechniques.length
        ? `Обнаружено техник: ${ctx.mitreTechniques.length}. MITRE ATT&CK — общий словарь, ` +
          "которым SOC по всему миру описывают действия атакующих. Используя его в заключении, " +
          "ты делаешь отчёт понятным для любого другого аналитика или платформы."
        : "На этой карточке техники ATT&CK не распознаны автоматически. Попробуй сам: судя по " +
          "тексту карточки, что делал атакующий, и к какой тактике (первичный доступ, " +
          "закрепление, эксфильтрация...) это ближе всего?",
    quiz: mitreQuiz,
    reflection: null
  });

  steps.push({
    id: "verdict",
    title: "Как принять решение: TP или FP",
    highlightField: null,
    explain:
      "Рабочее эмпирическое правило (не абсолютная истина): если хотя бы один IOC подтверждён " +
      "как вредоносный внешним TI-сервисом ИЛИ наблюдается цепочка из 2+ техник ATT&CK — " +
      "склоняйся к True Positive. Если индикатор — IP известного сканера безопасности или " +
      "легитимного мониторинга — вероятно False Positive. Финальное решение всегда за тобой " +
      "и контекстом конкретной инфраструктуры.",
    quiz: null,
    reflection: "Какой вердикт ты бы поставил прямо сейчас и почему? Запиши свою логику, потом сверься с чек-листом заключения."
  });

  steps.push({
    id: "conclusion",
    title: "Заключение — это коммуникация, не формальность",
    highlightField: null,
    explain:
      "Хорошее заключение позволяет следующему аналитику (или тебе самому через полгода) " +
      "быстро понять, что произошло и что делать. Заполни вкладку «Заключение»: вердикт, " +
      "причину, воздействие, предпринятые действия и рекомендации — коротко, но по существу.",
    quiz: null,
    reflection: null
  });

  return steps;
}

if (typeof module !== "undefined") {
  module.exports = {
    SOC_COPILOT_MENTOR_LEVELS,
    SOC_COPILOT_IOC_TYPE_LABELS,
    socCopilotMentorLevel,
    socCopilotMentorNextLevel,
    socCopilotBuildIOCQuiz,
    socCopilotBuildMitreQuiz,
    socCopilotBuildMentorSteps
  };
}
