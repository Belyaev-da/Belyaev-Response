// background.js — service worker. Здесь и только здесь выполняются внешние
// сетевые запросы (TI-обогащение, LLM, уведомления команде), чтобы ключи API
// не утекали в контекст веб-страницы и не были доступны скриптам SIEM-портала.

importScripts("utils/redaction.js", "utils/license.js", "utils/crypto.js");

const enrichCache = new Map(); // value -> {ts, result}
const CACHE_TTL_MS = 15 * 60 * 1000;

// --- Миграция секретов в шифрованный вид (для установок с версий < 0.8.0) --
// Однократно переносит plaintext-секреты в зашифрованные ключи и удаляет исходные.
async function migrateSecretsToEncrypted() {
  const data = await chrome.storage.local.get([
    "socCopilotApiKeys",
    "socCopilotApiKeysEnc",
    "socCopilotTelegramConfig",
    "socCopilotTelegramConfigEnc",
    "socCopilotMaxConfig",
    "socCopilotMaxConfigEnc",
    "socCopilotWebhookUrl",
    "socCopilotWebhookUrlEnc",
    "socCopilotLicense"
  ]);
  const updates = {};
  const removals = [];

  if (data.socCopilotApiKeys && !data.socCopilotApiKeysEnc) {
    updates.socCopilotApiKeysEnc = await socCopilotEncryptString(JSON.stringify(data.socCopilotApiKeys));
    updates.socCopilotSecretsMeta = {
      ...(await getSecretsMeta()),
      virustotal: !!data.socCopilotApiKeys.virustotal,
      abuseipdb: !!data.socCopilotApiKeys.abuseipdb,
      anthropic: !!data.socCopilotApiKeys.anthropic
    };
    removals.push("socCopilotApiKeys");
  }
  if (data.socCopilotTelegramConfig && !data.socCopilotTelegramConfigEnc) {
    updates.socCopilotTelegramConfigEnc = await socCopilotEncryptString(JSON.stringify(data.socCopilotTelegramConfig));
    removals.push("socCopilotTelegramConfig");
  }
  if (data.socCopilotMaxConfig && !data.socCopilotMaxConfigEnc) {
    updates.socCopilotMaxConfigEnc = await socCopilotEncryptString(JSON.stringify(data.socCopilotMaxConfig));
    removals.push("socCopilotMaxConfig");
  }
  if (data.socCopilotWebhookUrl && !data.socCopilotWebhookUrlEnc) {
    updates.socCopilotWebhookUrlEnc = await socCopilotEncryptString(data.socCopilotWebhookUrl);
    removals.push("socCopilotWebhookUrl");
  }
  if (data.socCopilotLicense && data.socCopilotLicense.key && !data.socCopilotLicense.keyEnc) {
    const license = { ...data.socCopilotLicense };
    license.keyEnc = await socCopilotEncryptString(license.key);
    delete license.key;
    updates.socCopilotLicense = license;
  }

  if (Object.keys(updates).length) await chrome.storage.local.set(updates);
  if (removals.length) await chrome.storage.local.remove(removals);
}

async function getSecretsMeta() {
  const data = await chrome.storage.local.get(["socCopilotSecretsMeta"]);
  return data.socCopilotSecretsMeta || {};
}

async function getDecryptedApiKeys() {
  const data = await chrome.storage.local.get(["socCopilotApiKeysEnc"]);
  const json = await socCopilotDecryptString(data.socCopilotApiKeysEnc);
  return json ? JSON.parse(json) : {};
}

async function getDecryptedTelegramConfig() {
  const data = await chrome.storage.local.get(["socCopilotTelegramConfigEnc"]);
  const json = await socCopilotDecryptString(data.socCopilotTelegramConfigEnc);
  return json ? JSON.parse(json) : {};
}

async function getDecryptedMaxConfig() {
  const data = await chrome.storage.local.get(["socCopilotMaxConfigEnc"]);
  const json = await socCopilotDecryptString(data.socCopilotMaxConfigEnc);
  return json ? JSON.parse(json) : {};
}

async function getDecryptedWebhookUrl() {
  const data = await chrome.storage.local.get(["socCopilotWebhookUrlEnc"]);
  return (await socCopilotDecryptString(data.socCopilotWebhookUrlEnc)) || "";
}

async function getDecryptedTeamsWebhookUrl() {
  const data = await chrome.storage.local.get(["socCopilotTeamsWebhookUrlEnc"]);
  return (await socCopilotDecryptString(data.socCopilotTeamsWebhookUrlEnc)) || "";
}

async function getDecryptedJiraConfig() {
  const data = await chrome.storage.local.get(["socCopilotJiraConfigEnc", "socCopilotJiraMeta"]);
  const json = await socCopilotDecryptString(data.socCopilotJiraConfigEnc);
  const secret = json ? JSON.parse(json) : {};
  return { ...secret, ...(data.socCopilotJiraMeta || {}) }; // baseUrl/projectKey/issueType не секретны, храним отдельно
}

async function getDecryptedLicenseKey(license) {
  if (!license) return null;
  return socCopilotDecryptString(license.keyEnc);
}

// --- Маркетплейс адаптеров --------------------------------------------------
// Лицензионный ключ расшифровывается ИСКЛЮЧИТЕЛЬНО здесь — options.js передаёт
// только нечувствительные данные адаптера (id/name/selectors — не секрет), а
// авторизацию к серверу маркетплейса background.js добавляет сам.

// ЕДИНЫЙ сервер лицензирования (см. также ту же константу в options.js) — лицензии
// выдаёт только владелец продукта, поэтому URL один и жёстко задан в коде, а не
// вводится каждым пользователем вручную. Enterprise-политика LicenseServerUrl (см.
// applyManagedPolicies ниже) может переопределить его для организаций с собственным
// зеркалом сервера — это отдельный, осознанный механизм для IT-администраторов, а не
// поле, которое видит рядовой аналитик.
const SOC_COPILOT_LICENSE_SERVER_URL = "https://belyaev.expert";

async function getLicenseAuth() {
  const { socCopilotLicense, socCopilotLicenseServerUrl } = await chrome.storage.local.get([
    "socCopilotLicense",
    "socCopilotLicenseServerUrl"
  ]);
  if (!socCopilotLicense) return null;
  const serverUrl = socCopilotLicenseServerUrl || SOC_COPILOT_LICENSE_SERVER_URL;
  const key = await getDecryptedLicenseKey(socCopilotLicense);
  if (!key) return null;
  return { key, serverUrl: serverUrl.replace(/\/$/, "") };
}

async function handleMarketplaceList() {
  const auth = await getLicenseAuth();
  if (!auth) return { error: "Нужна активная лицензия (см. раздел «Лицензия» в настройках)" };
  try {
    const resp = await fetch(`${auth.serverUrl}/api/marketplace/adapters`, {
      headers: { Authorization: `Bearer ${auth.key}` }
    });
    const data = await resp.json().catch(() => ({}));
    if (!resp.ok) return { error: data.error || `HTTP ${resp.status}` };
    return { ok: true, adapters: data.adapters || [] };
  } catch (e) {
    return { error: "сетевая ошибка: " + e.message };
  }
}

async function handleMarketplacePublish(adapter) {
  const auth = await getLicenseAuth();
  if (!auth) return { error: "Нужна активная лицензия (см. раздел «Лицензия» в настройках)" };
  try {
    const resp = await fetch(`${auth.serverUrl}/api/marketplace/adapters`, {
      method: "POST",
      headers: { "Content-Type": "application/json", Authorization: `Bearer ${auth.key}` },
      body: JSON.stringify({
        id: adapter.id,
        name: adapter.name,
        vendor: adapter.vendor,
        urlPatterns: adapter.urlPatterns,
        selectors: adapter.selectors
      })
    });
    const data = await resp.json().catch(() => ({}));
    if (!resp.ok) return { error: data.error || `HTTP ${resp.status}` };
    return { ok: true };
  } catch (e) {
    return { error: "сетевая ошибка: " + e.message };
  }
}

async function handleMarketplaceDownload(adapterId) {
  const auth = await getLicenseAuth();
  if (!auth) return { error: "Нужна активная лицензия (см. раздел «Лицензия» в настройках)" };
  try {
    const resp = await fetch(`${auth.serverUrl}/api/marketplace/adapters/${encodeURIComponent(adapterId)}/download`, {
      method: "POST",
      headers: { Authorization: `Bearer ${auth.key}` }
    });
    const data = await resp.json().catch(() => ({}));
    if (!resp.ok) return { error: data.error || `HTTP ${resp.status}` };
    return { ok: true, adapter: data.adapter };
  } catch (e) {
    return { error: "сетевая ошибка: " + e.message };
  }
}

// --- Живой глоссарий терминов SIEM ------------------------------------------

async function handleGlossaryList() {
  const auth = await getLicenseAuth();
  if (!auth) return { error: "Нужна активная лицензия (см. раздел «Лицензия» в настройках)" };
  try {
    const resp = await fetch(`${auth.serverUrl}/api/glossary/terms`, { headers: { Authorization: `Bearer ${auth.key}` } });
    const data = await resp.json().catch(() => ({}));
    if (!resp.ok) return { error: data.error || `HTTP ${resp.status}` };
    return { ok: true, terms: data.terms || [] };
  } catch (e) {
    return { error: "сетевая ошибка: " + e.message };
  }
}

async function handleGlossarySubmit(term) {
  const auth = await getLicenseAuth();
  if (!auth) return { error: "Нужна активная лицензия (см. раздел «Лицензия» в настройках)" };
  try {
    const resp = await fetch(`${auth.serverUrl}/api/glossary/terms`, {
      method: "POST",
      headers: { "Content-Type": "application/json", Authorization: `Bearer ${auth.key}` },
      body: JSON.stringify(term)
    });
    const data = await resp.json().catch(() => ({}));
    if (!resp.ok) return { error: data.error || `HTTP ${resp.status}` };
    return { ok: true };
  } catch (e) {
    return { error: "сетевая ошибка: " + e.message };
  }
}

async function handleGlossaryVote(termId, direction) {
  const auth = await getLicenseAuth();
  if (!auth) return { error: "Нужна активная лицензия (см. раздел «Лицензия» в настройках)" };
  try {
    const resp = await fetch(`${auth.serverUrl}/api/glossary/terms/${encodeURIComponent(termId)}/vote`, {
      method: "POST",
      headers: { "Content-Type": "application/json", Authorization: `Bearer ${auth.key}` },
      body: JSON.stringify({ direction })
    });
    const data = await resp.json().catch(() => ({}));
    if (!resp.ok) return { error: data.error || `HTTP ${resp.status}` };
    return { ok: true, ...data };
  } catch (e) {
    return { error: "сетевая ошибка: " + e.message };
  }
}

// --- Установка и enterprise-политики (chrome.storage.managed) -------------
chrome.runtime.onInstalled.addListener((details) => {
  if (details.reason === "install") {
    chrome.storage.local.set({ socCopilotInstallDate: new Date().toISOString() });
  }
  applyManagedPolicies();
  migrateSecretsToEncrypted();
  injectIntoExistingTabs(); // перезагрузка браузера не мешает — скрипты инициализируются сразу
});
chrome.runtime.onStartup.addListener(() => {
  applyManagedPolicies();
  migrateSecretsToEncrypted();
  injectIntoExistingTabs();
});

// Инъекция content scripts в уже открытые вкладки при старте расширения/браузера.
// Без этого плагин молчит 1-2 мин после перезагрузки компьютера — пока пользователь
// не переключит вкладку или не обновит страницу (что запускает нормальный lifecycle).
// Все content scripts из манифеста по порядку — без этого инъекция только content.js
// приводит к ReferenceError (SOC_COPILOT_DEFAULT_ADAPTERS is not defined), потому что
// зависимости (adapters.js, utils/*.js) не были загружены на уже открытой вкладке.
const SOC_COPILOT_ALL_SCRIPTS = [
  "adapters.js","utils/ioc-extractor.js","utils/playbooks.js","utils/report-template.js",
  "utils/mitre-attack.js","utils/conclusion-template.js","utils/crypto.js","utils/license.js",
  "utils/i18n.js","utils/dfir-tools.js","utils/szi-recommendations.js","utils/gossopka.js",
  "utils/diff-detector.js","utils/response-snippets.js","utils/burnout.js",
  "utils/detection-rules.js","utils/alert-storm.js","utils/mentor.js","utils/belzor.js",
  "utils/stats.js","utils/campaign-graph.js","utils/redaction.js","utils/panel-styles.js",
  "content.js"
];

async function injectIntoExistingTabs() {
  try {
    const tabs = await chrome.tabs.query({ url: ["http://*/*", "https://*/*"] });
    for (const tab of tabs) {
      if (!tab.id || tab.status !== "complete") continue;
      chrome.scripting.executeScript({
        target: { tabId: tab.id },
        files: SOC_COPILOT_ALL_SCRIPTS
      }).catch(() => {}); // часть вкладок заблокирует (chrome://, pdf и т.п.)
    }
  } catch (e) {
    console.warn("[belyaev-response] injectIntoExistingTabs:", e.message);
  }
}
chrome.storage.onChanged.addListener((changes, area) => {
  if (area === "managed") applyManagedPolicies();
});

// Зеркалим политики, заданные администратором (chrome.storage.managed), в обычный
// local storage под теми же ключами, что использует UI — так options.js/content.js
// не нужно знать о существовании managed storage, а поля с активной политикой можно
// показать как заблокированные для редактирования (см. options.js).
async function applyManagedPolicies() {
  let policies;
  try {
    policies = await chrome.storage.managed.get(null);
  } catch (e) {
    return; // managed storage недоступен (обычная, не enterprise-установка) — это норма
  }
  if (!policies || !Object.keys(policies).length) return;

  const updates = {};
  const locked = {};
  if (policies.LicenseKey) {
    updates.socCopilotPolicyLicenseKey = policies.LicenseKey;
    locked.licenseKey = true;
  }
  if (policies.LicenseServerUrl) {
    updates.socCopilotLicenseServerUrl = policies.LicenseServerUrl;
    locked.licenseServerUrl = true;
  }
  if (typeof policies.GrafanaSyncEnabled === "boolean") {
    updates.socCopilotGrafanaSyncEnabled = policies.GrafanaSyncEnabled;
    locked.grafanaSyncEnabled = true;
  }
  if (policies.AnalystPseudonym) {
    updates.socCopilotAnalystPseudonym = policies.AnalystPseudonym;
    locked.analystPseudonym = true;
  }
  if (Array.isArray(policies.CompanyNames)) {
    updates.socCopilotCompanyNames = policies.CompanyNames;
    locked.companyNames = true;
  }
  if (policies.WebhookUrl) {
    updates.socCopilotWebhookUrl = policies.WebhookUrl;
    locked.webhookUrl = true;
  }
  if (Array.isArray(policies.DisabledAdapters) && policies.DisabledAdapters.length) {
    const { socCopilotAdapters } = await chrome.storage.local.get(["socCopilotAdapters"]);
    if (Array.isArray(socCopilotAdapters)) {
      socCopilotAdapters.forEach((a) => {
        if (policies.DisabledAdapters.includes(a.id)) a.enabled = false;
      });
      updates.socCopilotAdapters = socCopilotAdapters;
    }
    locked.disabledAdapters = policies.DisabledAdapters;
  }

  updates.socCopilotPolicyLocks = locked;
  await chrome.storage.local.set(updates);

  // Если политика задаёт лицензионный ключ — активируем его автоматически.
  // LicenseServerUrl теперь не обязателен: если не задан, используется единый
  // сервер SOC_COPILOT_LICENSE_SERVER_URL (см. выше).
  if (policies.LicenseKey) {
    activateLicense(policies.LicenseKey, policies.LicenseServerUrl || SOC_COPILOT_LICENSE_SERVER_URL).catch(() => {});
  }
}

// --- Кросс-вкладочная корреляция за смену --------------------------------
// Сессионный (не персистентный) реестр открытых карточек инцидентов:
// tabId -> { url, title, iocs: string[], techniques: string[], updatedAt }
const openIncidentTabs = new Map();

chrome.tabs.onRemoved.addListener((tabId) => openIncidentTabs.delete(tabId));

function computeRelatedTabs(currentTabId, iocs, techniques) {
  const iocSet = new Set(iocs || []);
  const techSet = new Set(techniques || []);
  const related = [];
  for (const [tabId, entry] of openIncidentTabs.entries()) {
    if (tabId === currentTabId) continue;
    const iocOverlap = (entry.iocs || []).filter((v) => iocSet.has(v)).length;
    const techOverlap = (entry.techniques || []).filter((t) => techSet.has(t)).length;
    const score = iocOverlap * 2 + techOverlap;
    if (score > 0) related.push({ tabId, url: entry.url, title: entry.title, score });
  }
  return related.sort((a, b) => b.score - a.score).slice(0, 5);
}

// --- Контекстное меню: спросить AI про выделенный текст на любой странице -
chrome.runtime.onInstalled.addListener(() => {
  // removeAll перед create — иначе при "update" (не полной переустановке) можно
  // словить runtime.lastError "Cannot create item with duplicate id".
  chrome.contextMenus.removeAll(() => {
    chrome.contextMenus.create({
      id: "soc-copilot-ask-selection",
      title: "Спросить Belyaev Response про выделенное",
      contexts: ["selection"]
    });
  });
});

chrome.contextMenus.onClicked.addListener(async (info, tab) => {
  if (info.menuItemId !== "soc-copilot-ask-selection" || !tab?.id) return;
  const licenseState = await getCurrentLicenseState();
  if (!socCopilotIsPro(licenseState)) {
    chrome.tabs.sendMessage(tab.id, {
      type: "socCopilotAskSelectionResult",
      error: "«Спросить AI про выделенное» — Pro-функция. Активируйте лицензию или продлите бесплатный период в настройках расширения."
    });
    return;
  }
  const { socCopilotCompanyNames } = await chrome.storage.local.get(["socCopilotCompanyNames"]);
  const result = await handleAskSelection(info.selectionText || "", socCopilotCompanyNames || []);
  chrome.tabs.sendMessage(tab.id, { type: "socCopilotAskSelectionResult", ...result });
});

// Обезличивание выделенного текста происходит ЗДЕСЬ, в background.js, т.к. этот
// путь (контекстное меню на произвольной странице) не проходит через content.js
// и его логику сборки контекста — см. utils/redaction.js.
// --- Единая точка вызова LLM: Anthropic ИЛИ локальная LLM (Ollama-совместимый API) --
// Если в опциях включена локальная LLM (актуально для организаций, которым нельзя
// отправлять данные во внешние облачные сервисы даже в обезличенном виде — частый
// случай для российских заказчиков), запрос идёт на локальный/внутрикорпоративный
// эндпоинт вместо api.anthropic.com. Обезличивание (redaction) применяется ДО этой
// функции в обоих случаях одинаково — переключение бэкенда его не отключает.
async function callLLM(prompt, maxTokens = 500) {
  const { socCopilotLocalLLMEnabled, socCopilotLocalLLMUrl, socCopilotLocalLLMModel } = await chrome.storage.local.get([
    "socCopilotLocalLLMEnabled",
    "socCopilotLocalLLMUrl",
    "socCopilotLocalLLMModel"
  ]);

  if (socCopilotLocalLLMEnabled && socCopilotLocalLLMUrl) {
    try {
      const resp = await fetch(`${socCopilotLocalLLMUrl.replace(/\/$/, "")}/api/chat`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          model: socCopilotLocalLLMModel || "llama3",
          messages: [{ role: "user", content: prompt }],
          stream: false
        })
      });
      if (!resp.ok) return { error: `Локальная LLM вернула HTTP ${resp.status}` };
      const data = await resp.json();
      const text = data?.message?.content || "";
      return { text: text.trim() || "Пустой ответ модели." };
    } catch (e) {
      return { error: "Не удалось связаться с локальной LLM (проверьте URL и что сервер запущен): " + e.message };
    }
  }

  const apiKey = (await getDecryptedApiKeys()).anthropic;
  if (!apiKey) return { error: "не указан Anthropic API-ключ в настройках расширения (или включите локальную LLM)" };
  try {
    const resp = await fetch("https://api.anthropic.com/v1/messages", {
      method: "POST",
      headers: { "Content-Type": "application/json", "x-api-key": apiKey, "anthropic-version": "2023-06-01" },
      body: JSON.stringify({ model: "claude-sonnet-4-6", max_tokens: maxTokens, messages: [{ role: "user", content: prompt }] })
    });
    if (!resp.ok) {
      const errText = await resp.text();
      return { error: `Anthropic API ошибка ${resp.status}: ${errText.slice(0, 200)}` };
    }
    const data = await resp.json();
    const text = (data.content || []).map((b) => b.text || "").join("\n").trim();
    return { text: text || "Пустой ответ модели." };
  } catch (e) {
    return { error: "сетевая ошибка: " + e.message };
  }
}

async function handleAskSelection(selectionText, companyNames) {
  if (!selectionText.trim()) return { error: "пустое выделение" };
  const { text: redacted, mapping } = socCopilotRedactSensitiveData(selectionText.slice(0, 2000), { companyNames });
  const prompt = `Ты помогаешь SOC-аналитику разобраться в непонятном фрагменте с экрана
(лог, сообщение об ошибке, странная строка, вывод команды и т.п.). Кратко (до 120 слов)
объясни, что это может означать в контексте кибербезопасности, и стоит ли на это
обращать внимание. Если фрагмент не связан с ИБ — так и скажи. Часть данных в фрагменте
заменена плейсхолдерами вида [[TYPE_N]] (обезличивание перед отправкой) — используй их
как есть в рассуждении, не пытайся угадать исходные значения.

Фрагмент:
"""
${redacted}
"""`;
  const result = await callLLM(prompt, 350);
  if (result.error) return result;
  // Восстанавливаем плейсхолдеры в реальные значения ТОЛЬКО в ответе, который уходит
  // обратно аналитику в браузер — сама модель исходных значений не видела.
  const restored = socCopilotRestoreSensitiveData(result.text, mapping);
  return { text: restored, redacted: true };
}

// --- Горячие клавиши: пересылаем команду в активную вкладку ---------------
chrome.commands.onCommand.addListener((command) => {
  chrome.tabs.query({ active: true, currentWindow: true }, ([tab]) => {
    if (tab?.id) chrome.tabs.sendMessage(tab.id, { type: "socCopilotCommand", command }).catch(() => {});
  });
});

// --- Трансляция заключения в команду: Slack/Mattermost, Telegram, MAX -----
async function handleBroadcast(channel, text, title) {
  if (channel === "slack") return broadcastSlack(await getDecryptedWebhookUrl(), text);
  if (channel === "telegram") return broadcastTelegram(await getDecryptedTelegramConfig(), text);
  if (channel === "max") return broadcastMax(await getDecryptedMaxConfig(), text);
  if (channel === "teams") return broadcastTeams(await getDecryptedTeamsWebhookUrl(), text, title);
  if (channel === "jira") return broadcastJira(await getDecryptedJiraConfig(), text, title);
  return { error: "неизвестный канал: " + channel };
}

async function broadcastSlack(webhookUrl, text) {
  if (!webhookUrl) return { error: "webhook URL не настроен в опциях" };
  try {
    const resp = await fetch(webhookUrl, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ text })
    });
    if (!resp.ok) return { error: `webhook вернул HTTP ${resp.status}` };
    return { ok: true };
  } catch (e) {
    return { error: "сетевая ошибка webhook: " + e.message };
  }
}

async function broadcastTelegram(config, text) {
  if (!config?.token || !config?.chatId) return { error: "Telegram-бот не настроен в опциях" };
  try {
    const resp = await fetch(`https://api.telegram.org/bot${config.token}/sendMessage`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ chat_id: config.chatId, text })
    });
    const data = await resp.json().catch(() => ({}));
    if (!resp.ok || data.ok === false) return { error: `Telegram API ошибка: ${data.description || resp.status}` };
    return { ok: true };
  } catch (e) {
    return { error: "сетевая ошибка Telegram: " + e.message };
  }
}

// MAX Bot API: POST https://platform-api.max.ru/messages?chat_id={chatId}, заголовок
// Authorization: {token}. Токен и chat_id бота выдаются через @MasterBot в мессенджере.
// Официальная документация: https://dev.max.ru/docs-api — API развивается, при
// проблемах с отправкой сверьтесь с актуальной документацией (эндпоинты/домен могли измениться).
async function broadcastMax(config, text) {
  if (!config?.token || !config?.chatId) return { error: "MAX-бот не настроен в опциях" };
  try {
    const resp = await fetch(`https://platform-api.max.ru/messages?chat_id=${encodeURIComponent(config.chatId)}`, {
      method: "POST",
      headers: { "Content-Type": "application/json", Authorization: config.token },
      body: JSON.stringify({ text })
    });
    if (!resp.ok) {
      const errText = await resp.text().catch(() => "");
      return { error: `MAX API ошибка ${resp.status}: ${errText.slice(0, 150)}` };
    }
    return { ok: true };
  } catch (e) {
    return { error: "сетевая ошибка MAX: " + e.message };
  }
}

// Microsoft Teams Incoming Webhook — легаси формат MessageCard, всё ещё широко
// поддерживается существующими коннекторами Teams (Adaptive Card требует более
// новый Workflow-коннектор, который настраивается индивидуально на стороне Teams —
// MessageCard остаётся самым простым общим знаменателем для webhook-интеграции).
async function broadcastTeams(webhookUrl, text, title) {
  if (!webhookUrl) return { error: "webhook Teams не настроен в опциях" };
  try {
    const resp = await fetch(webhookUrl, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        "@type": "MessageCard",
        "@context": "http://schema.org/extensions",
        summary: title || "Belyaev Response",
        themeColor: "6366F1",
        sections: [{ activityTitle: title || "Belyaev Response", text: text.replace(/\n/g, "  \n") }]
      })
    });
    if (!resp.ok) return { error: `Teams webhook вернул HTTP ${resp.status}` };
    return { ok: true };
  } catch (e) {
    return { error: "сетевая ошибка Teams: " + e.message };
  }
}

// Jira Service Desk / Jira Cloud — создание задачи через REST API v3 (Basic Auth:
// email + API-токен). Не требует Jira-плагинов, работает с любым облачным Jira.
async function broadcastJira(config, text, title) {
  if (!config?.baseUrl || !config?.email || !config?.apiToken || !config?.projectKey) {
    return { error: "Jira не настроена полностью в опциях (URL/email/токен/ключ проекта)" };
  }
  try {
    const auth = btoa(`${config.email}:${config.apiToken}`);
    const resp = await fetch(`${config.baseUrl.replace(/\/$/, "")}/rest/api/3/issue`, {
      method: "POST",
      headers: { "Content-Type": "application/json", Authorization: `Basic ${auth}` },
      body: JSON.stringify({
        fields: {
          project: { key: config.projectKey },
          summary: title || "Инцидент из Belyaev Response",
          description: {
            type: "doc",
            version: 1,
            content: [{ type: "paragraph", content: [{ type: "text", text }] }]
          },
          issuetype: { name: config.issueType || "Task" }
        }
      })
    });
    const data = await resp.json().catch(() => ({}));
    if (!resp.ok) return { error: `Jira API ошибка ${resp.status}: ${JSON.stringify(data).slice(0, 200)}` };
    return { ok: true, issueKey: data.key };
  } catch (e) {
    return { error: "сетевая ошибка Jira: " + e.message };
  }
}

// --- Лицензирование ---------------------------------------------------------

function getOrCreateDeviceId() {
  return chrome.storage.local.get(["socCopilotDeviceId"]).then((data) => {
    if (data.socCopilotDeviceId) return data.socCopilotDeviceId;
    const id = crypto.randomUUID();
    return chrome.storage.local.set({ socCopilotDeviceId: id }).then(() => id);
  });
}

async function getCurrentLicenseState() {
  const data = await chrome.storage.local.get(["socCopilotInstallDate", "socCopilotLicense"]);
  return socCopilotComputeLicenseState({
    installDate: data.socCopilotInstallDate || new Date().toISOString(),
    license: data.socCopilotLicense || null
  });
}

async function activateLicense(key, serverUrl) {
  if (!key || !serverUrl) return { valid: false, reason: "Не заданы ключ или адрес сервера лицензирования" };
  const deviceId = await getOrCreateDeviceId();
  try {
    const resp = await fetch(new URL("/api/license/activate", serverUrl).toString(), {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ key, deviceId, deviceName: navigator.userAgent.slice(0, 100) })
    });
    const data = await resp.json().catch(() => ({}));
    if (data.valid) {
      await chrome.storage.local.set({
        socCopilotLicense: { key, status: "active", tier: data.tier, orgName: data.orgName, expiresAt: data.expiresAt, lastValidated: new Date().toISOString() },
        socCopilotLicenseServerUrl: serverUrl
      });
      return { valid: true, ...data };
    }
    return { valid: false, reason: data.reason || `HTTP ${resp.status}` };
  } catch (e) {
    return { valid: false, reason: "сетевая ошибка: " + e.message };
  }
}

async function validateLicense() {
  const data = await chrome.storage.local.get(["socCopilotLicense", "socCopilotLicenseServerUrl"]);
  const license = data.socCopilotLicense;
  const serverUrl = data.socCopilotLicenseServerUrl;
  if (!license || !serverUrl) return;
  const deviceId = await getOrCreateDeviceId();
  try {
    const resp = await fetch(new URL("/api/license/validate", serverUrl).toString(), {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ key: license.key, deviceId })
    });
    const result = await resp.json().catch(() => ({}));
    if (result.valid) {
      license.status = "active";
      license.expiresAt = result.expiresAt;
      license.lastValidated = new Date().toISOString();
    } else {
      // Оффлайн-грейс период: если сервер недоступен по сети, не понижаем лицензию
      // молча — только если сервер ЯВНО ответил "невалидна" (revoked/expired/не найдена).
      license.status = "inactive";
      license.reason = result.reason;
    }
    await chrome.storage.local.set({ socCopilotLicense: license });
  } catch (e) {
    // Сетевая ошибка — оставляем последнее известное состояние как есть (grace period),
    // чтобы временная недоступность сервера не отключала Pro-функции у аналитика.
    console.warn("[license] Не удалось перепроверить лицензию (сеть недоступна?):", e.message);
  }
}

async function ingestStats(payload) {
  const data = await chrome.storage.local.get(["socCopilotLicense", "socCopilotLicenseServerUrl", "socCopilotAnalystPseudonym"]);
  const license = data.socCopilotLicense;
  const serverUrl = data.socCopilotLicenseServerUrl;
  if (!license || license.status !== "active" || !serverUrl) {
    return { ok: false, reason: "Grafana-синхронизация требует активной Pro-лицензии" };
  }
  const deviceId = await getOrCreateDeviceId();
  try {
    const resp = await fetch(new URL("/api/ingest", serverUrl).toString(), {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        key: license.key,
        deviceId,
        analystPseudonym: data.socCopilotAnalystPseudonym || "anonymous",
        stats: payload
      })
    });
    const result = await resp.json().catch(() => ({}));
    return resp.ok ? { ok: true } : { ok: false, reason: result.reason || `HTTP ${resp.status}` };
  } catch (e) {
    return { ok: false, reason: "сетевая ошибка: " + e.message };
  }
}

// Периодическая перепроверка лицензии (раз в сутки, через chrome.alarms — переживает
// перезапуск service worker, в отличие от setInterval).
chrome.alarms.create("socCopilotLicenseRecheck", { periodInMinutes: 24 * 60 });
chrome.alarms.onAlarm.addListener((alarm) => {
  if (alarm.name === "socCopilotLicenseRecheck") validateLicense();
});

chrome.runtime.onMessage.addListener((msg, sender, sendResponse) => {
  if (msg.type === "socCopilotEnrich") {
    handleEnrich(msg.value, msg.iocType).then(sendResponse);
    return true; // async
  }
  if (msg.type === "socCopilotLLMSummary") {
    handleLLMSummary(msg.payload).then(sendResponse);
    return true;
  }
  if (msg.type === "socCopilotLLMPredict") {
    handleLLMPredict(msg.payload).then(sendResponse);
    return true;
  }
  if (msg.type === "socCopilotLLMMentor") {
    handleLLMMentor(msg.payload).then(sendResponse);
    return true;
  }
  if (msg.type === "socCopilotSyncAttack") {
    handleSyncAttack().then(sendResponse);
    return true;
  }
  if (msg.type === "socCopilotPickerResult") {
    // Транслируем результат пикера всем страницам расширения (options.js слушает это же событие)
    chrome.runtime.sendMessage(msg).catch(() => {});
  }
  if (msg.type === "socCopilotRegisterTab" && sender.tab?.id) {
    openIncidentTabs.set(sender.tab.id, {
      url: msg.url,
      title: msg.title,
      iocs: msg.iocs || [],
      techniques: msg.techniques || [],
      updatedAt: Date.now()
    });
  }
  if (msg.type === "socCopilotGetRelatedTabs" && sender.tab?.id) {
    sendResponse(computeRelatedTabs(sender.tab.id, msg.iocs, msg.techniques));
    return true;
  }
  if (msg.type === "socCopilotSetBadge" && sender.tab?.id) {
    chrome.action.setBadgeText({ tabId: sender.tab.id, text: msg.text || "" });
    chrome.action.setBadgeBackgroundColor({ tabId: sender.tab.id, color: msg.color || "#6366f1" });
  }
  if (msg.type === "socCopilotBroadcast") {
    handleBroadcast(msg.channel, msg.text, msg.title).then(sendResponse);
    return true;
  }
  if (msg.type === "socCopilotGetLicenseState") {
    getCurrentLicenseState().then(sendResponse);
    return true;
  }
  if (msg.type === "socCopilotLicenseActivate") {
    activateLicense(msg.key, msg.serverUrl).then(sendResponse);
    return true;
  }
  if (msg.type === "socCopilotIngestStats") {
    ingestStats(msg.payload).then(sendResponse);
    return true;
  }
  if (msg.type === "socCopilotGetSecretsMeta") {
    getSecretsMeta().then(sendResponse);
    return true;
  }
  if (msg.type === "socCopilotMarketplaceList") {
    handleMarketplaceList().then(sendResponse);
    return true;
  }
  if (msg.type === "socCopilotMarketplacePublish") {
    handleMarketplacePublish(msg.adapter).then(sendResponse);
    return true;
  }
  if (msg.type === "socCopilotMarketplaceDownload") {
    handleMarketplaceDownload(msg.adapterId).then(sendResponse);
    return true;
  }
  if (msg.type === "socCopilotGlossaryList") {
    handleGlossaryList().then(sendResponse);
    return true;
  }
  if (msg.type === "socCopilotGlossarySubmit") {
    handleGlossarySubmit(msg.term).then(sendResponse);
    return true;
  }
  if (msg.type === "socCopilotGlossaryVote") {
    handleGlossaryVote(msg.termId, msg.direction).then(sendResponse);
    return true;
  }
});

async function handleEnrich(value, iocType) {
  const cacheKey = `${iocType}:${value}`;
  const cached = enrichCache.get(cacheKey);
  if (cached && Date.now() - cached.ts < CACHE_TTL_MS) return cached.result;

  const apiKeys = await getDecryptedApiKeys();
  let result;
  try {
    if (iocType === "hash") {
      result = await enrichVirusTotal(value, "files", apiKeys.virustotal);
    } else if (iocType === "ipv4" || iocType === "ipv6") {
      result = (await enrichAbuseIPDB(value, apiKeys.abuseipdb)) || (await enrichVirusTotal(value, "ip_addresses", apiKeys.virustotal));
    } else if (iocType === "domain" || iocType === "url") {
      result = await enrichVirusTotal(value, iocType === "domain" ? "domains" : "urls", apiKeys.virustotal);
    } else {
      result = { error: "тип IOC не поддерживается для обогащения" };
    }
  } catch (e) {
    result = { error: "сетевая ошибка: " + e.message };
  }

  enrichCache.set(cacheKey, { ts: Date.now(), result });
  return result;
}

async function enrichVirusTotal(value, endpoint, apiKey) {
  if (!apiKey) return { error: "нет ключа VirusTotal" };
  let id = value;
  if (endpoint === "urls") {
    id = btoa(value).replace(/=+$/, "").replace(/\//g, "_").replace(/\+/g, "-");
  }
  const resp = await fetch(`https://www.virustotal.com/api/v3/${endpoint}/${encodeURIComponent(id)}`, {
    headers: { "x-apikey": apiKey }
  });
  if (resp.status === 404) return { summary: "не найдено в VT", malicious: false };
  if (!resp.ok) return { error: `VT ошибка ${resp.status}` };
  const data = await resp.json();
  const stats = data?.data?.attributes?.last_analysis_stats;
  if (!stats) return { summary: "нет данных анализа VT", malicious: false };
  const malicious = stats.malicious > 0;
  return {
    summary: `VT: ${stats.malicious} вред. / ${stats.suspicious} подозр. / ${stats.harmless} безоп.`,
    malicious
  };
}

async function enrichAbuseIPDB(ip, apiKey) {
  if (!apiKey) return null; // даст возможность fallback на VT
  const resp = await fetch(
    `https://api.abuseipdb.com/api/v2/check?ipAddress=${encodeURIComponent(ip)}&maxAgeInDays=90`,
    { headers: { Key: apiKey, Accept: "application/json" } }
  );
  if (!resp.ok) return { error: `AbuseIPDB ошибка ${resp.status}` };
  const data = await resp.json();
  const score = data?.data?.abuseConfidenceScore ?? 0;
  return {
    summary: `AbuseIPDB score: ${score}% (репортов: ${data?.data?.totalReports ?? 0})`,
    malicious: score >= 50
  };
}

// payload.redactedContext уже обезличен на стороне content.js (см. buildRedactedContext) —
// background.js только оборачивает его в инструктивный промпт и НИКОГДА не видит и не
// запрашивает исходные (неотредактированные) fields/iocMap напрямую для LLM-вызовов.
async function handleLLMPredict(payload) {
  const prompt = `Ты помогаешь SOC-аналитику оценить вероятное развитие инцидента в терминах MITRE ATT&CK.
Дай КРАТКИЙ (не более 150 слов) обоснованный прогноз наиболее вероятных следующих 2-3 шагов атакующего
(тактика + техника с ID, если применимо), опираясь на уже наблюдаемые признаки. Обязательно укажи
уровень уверенности (низкий/средний/высокий) и явно отметь, что это гипотеза, требующая проверки,
а не факт. Не выдумывай технические детали, которых нет в описании. Часть данных заменена
плейсхолдерами вида [[TYPE_N]] (обезличивание перед отправкой) — используй их как есть.

${payload.redactedContext || "(контекст пуст)"}`;

  return callLLM(prompt, 500);
}

// Синхронизация с официальным CTI-репозиторием MITRE (GitHub, публичный STIX-бандл).
// Расширяет курируемый набор техник полными названиями/тактиками из актуальной базы ATT&CK.
// Не требует ключа — репозиторий публичный.
async function handleSyncAttack() {
  const url = "https://raw.githubusercontent.com/mitre-attack/attack-stix-data/master/enterprise-attack/enterprise-attack.json";
  try {
    const resp = await fetch(url);
    if (!resp.ok) return { error: `Не удалось загрузить базу ATT&CK: HTTP ${resp.status}` };
    const bundle = await resp.json();
    const objects = bundle.objects || [];
    const db = {};
    for (const obj of objects) {
      if (obj.type !== "attack-pattern" || obj.revoked || obj.x_mitre_deprecated) continue;
      const extRef = (obj.external_references || []).find((r) => r.source_name === "mitre-attack");
      if (!extRef?.external_id) continue;
      const tactics = (obj.kill_chain_phases || [])
        .filter((k) => k.kill_chain_name === "mitre-attack")
        .map((k) => k.phase_name);
      db[extRef.external_id] = {
        id: extRef.external_id,
        name: obj.name,
        tacticId: tactics[0] || null,
        description: (obj.description || "").slice(0, 300)
      };
    }
    const count = Object.keys(db).length;
    await chrome.storage.local.set({
      socCopilotAttackDB: db,
      socCopilotAttackSyncMeta: { syncedAt: new Date().toISOString(), count }
    });
    return { ok: true, count };
  } catch (e) {
    return { error: "сетевая ошибка при синхронизации: " + e.message };
  }
}

// Наставник L1: Socratic-стиль — модель поощряется задавать наводящие вопросы и
// объяснять ход рассуждения, а не сразу выдавать готовый вердикт. Если аналитик
// прямо просит ответ ("скажи прямо", "не хочу гадать") — модель может дать его,
// но по умолчанию учит рассуждать самостоятельно (см. CHANGELOG 0.6.0).
async function handleLLMMentor(payload) {
  const prompt = `Ты — опытный наставник (Senior SOC-аналитик), который обучает начинающего
L1-аналитика прямо в процессе разбора реального инцидента. Твоя цель — развить его навык
рассуждения, а не просто дать ответ.

Стиль общения:
- Если вопрос предполагает рассуждение (например "это FP?", "что делать дальше?") — сначала
  задай 1-2 наводящих вопроса, которые помогут аналитику самому прийти к выводу, и только
  затем кратко подтверди/поправь его логику. Не растягивай — максимум 100 слов.
- Если аналитик просит прямой ответ явно (например пишет "скажи прямо", "не хочу гадать",
  "просто ответь") — дай прямой краткий ответ без наводящих вопросов.
- Всегда доброжелательный, поддерживающий тон, без снисходительности.
- Часть данных в контексте заменена плейсхолдерами вида [[TYPE_N]] (обезличивание перед
  отправкой) — используй их как есть, не пытайся угадать исходные значения.

Контекст (уже обезличен):
${payload.redactedContext || "(контекст пуст)"}`;

  return callLLM(prompt, 400);
}

async function handleLLMSummary(payload) {
  const prompt = `Ты помогаешь SOC-аналитику. Составь краткую сводку по инциденту на русском языке:
кратко опиши суть, вероятные тактики/техники MITRE ATT&CK (если можно предположить),
уровень уверенности, и 3-5 рекомендованных следующих шагов. Будь лаконичен. Часть данных
заменена плейсхолдерами вида [[TYPE_N]] (обезличивание перед отправкой) — используй их как есть,
не пытайся угадать исходные значения.

Платформа: ${payload.platform || "неизвестна"}
${payload.redactedContext || "(контекст пуст)"}`;

  return callLLM(prompt, 700);
}
