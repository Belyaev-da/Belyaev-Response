// utils/burnout.js
// Мягкий, ненавязчивый детектор признаков выгорания/усталости. НЕ диагностирует
// и не ставит психологических оценок — только замечает поведенческие паттерны
// (падение точности квизов наставника, работа в нетипичные часы) и предлагает
// сделать паузу. Полностью локально, ничего никуда не отправляется.
//
// Важно: это НЕ клинический инструмент и не должно восприниматься как оценка
// психического состояния сотрудника. Единственная цель — дружелюбное напоминание
// позаботиться о себе, не более.

// Принимает историю ответов квизов наставника вида [{correct: bool, timestamp}]
// (новые в начале ИЛИ конце — сортируем сами) и возвращает тренд точности:
// сравнивает последние N ответов с предыдущими N.
function socCopilotQuizAccuracyTrend(quizHistory, windowSize = 10) {
  if (!quizHistory || quizHistory.length < windowSize * 2) return null;
  const sorted = [...quizHistory].sort((a, b) => new Date(a.timestamp) - new Date(b.timestamp));
  const recent = sorted.slice(-windowSize);
  const previous = sorted.slice(-windowSize * 2, -windowSize);
  const recentAcc = recent.filter((q) => q.correct).length / recent.length;
  const previousAcc = previous.filter((q) => q.correct).length / previous.length;
  return { recentAccuracy: recentAcc, previousAccuracy: previousAcc, delta: recentAcc - previousAcc };
}

// Проверяет, работает ли аналитик в нетипично позднее/раннее время последние N дней
// подряд (частый маркер переработки/ночных смен без отдыха).
function socCopilotLateNightPattern(eventsLog, days = 5) {
  if (!eventsLog || !eventsLog.length) return { lateNightDays: 0, flagged: false };
  const cutoff = Date.now() - days * 24 * 60 * 60 * 1000;
  const recentByDay = {};
  eventsLog.forEach((e) => {
    const t = new Date(e.date).getTime();
    if (t < cutoff) return;
    const hour = new Date(e.date).getHours();
    const dayKey = new Date(e.date).toISOString().slice(0, 10);
    if (hour >= 23 || hour < 5) {
      recentByDay[dayKey] = true;
    }
  });
  const lateNightDays = Object.keys(recentByDay).length;
  return { lateNightDays, flagged: lateNightDays >= 3 };
}

// Главная функция: собирает сигналы и решает, показывать ли мягкое напоминание.
// Возвращает null, если сигналов недостаточно/всё в норме (по умолчанию — молчать,
// не создавать лишний шум).
function socCopilotCheckBurnoutSignals({ quizHistory, eventsLog }) {
  const accuracyTrend = socCopilotQuizAccuracyTrend(quizHistory);
  const lateNight = socCopilotLateNightPattern(eventsLog);

  const reasons = [];
  if (accuracyTrend && accuracyTrend.delta <= -0.25) {
    reasons.push("точность ответов в наставнике заметно снизилась за последние ответы");
  }
  if (lateNight.flagged) {
    reasons.push(`работа в позднее/раннее время ${lateNight.lateNightDays} дн. за последние 5 дней`);
  }

  if (!reasons.length) return null;
  return {
    reasons,
    message:
      "Заметил несколько сигналов, которые иногда говорят об усталости: " +
      reasons.join("; ") +
      ". Это не диагноз и может быть просто загруженной неделей — но если чувствуешь " +
      "выгорание, короткий перерыв сейчас обычно эффективнее, чем героизм."
  };
}

if (typeof module !== "undefined") {
  module.exports = {
    socCopilotQuizAccuracyTrend,
    socCopilotLateNightPattern,
    socCopilotCheckBurnoutSignals
  };
}
