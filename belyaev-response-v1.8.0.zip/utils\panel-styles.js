// utils/panel-styles.js
const SOC_COPILOT_PANEL_CSS = `
:host { all: initial; }
.sc-toggle {
  position: fixed; top: 100px; right: 0; z-index: 2147483000;
  background: #1f2937; color: #fff; border: none; border-radius: 8px 0 0 8px;
  padding: 10px 8px; font: 600 12px system-ui, sans-serif; cursor: pointer;
  writing-mode: vertical-rl; letter-spacing: 1px;
}
.sc-panel {
  position: fixed; top: 0; right: 0; height: 100vh; width: 440px; max-width: 92vw;
  background: var(--sc-bg, #0f172a); color: var(--sc-text, #e2e8f0); z-index: 2147483001;
  box-shadow: -4px 0 20px rgba(0,0,0,.4);
  font: 13px/1.4 system-ui, -apple-system, sans-serif;
  display: flex; flex-direction: column;
  transition: transform .2s ease;
}
.sc-panel.sc-hidden { transform: translateX(100%); }
.sc-header {
  display: flex; justify-content: space-between; align-items: center;
  padding: 12px 14px; background: var(--sc-bg2, #1e293b); font-weight: 700; font-size: 14px;
}
.sc-header .sc-close { background: none; border: none; color: var(--sc-text-muted, #94a3b8); font-size: 20px; cursor: pointer; }
.sc-highlight-toggle {
  background: var(--sc-bg3, #334155); border: none; color: var(--sc-text-muted, #94a3b8); font-size: 11px; cursor: pointer;
  border-radius: 4px; padding: 3px 7px; margin-left: auto; margin-right: 6px; white-space: nowrap;
}
.sc-highlight-toggle.sc-active { background: #fbbf24; color: #111; }
.sc-platform { padding: 8px 14px; font-size: 12px; color: var(--sc-text-muted, #94a3b8); border-bottom: 1px solid var(--sc-bg2, #1e293b); }
.sc-tabs { display: flex; border-bottom: 1px solid var(--sc-bg2, #1e293b); overflow-x: auto; flex-shrink: 0; }
.sc-tabs::-webkit-scrollbar { height: 3px; }
.sc-tab-btn {
  flex-shrink: 0; background: none; border: none; color: var(--sc-text-muted, #94a3b8); padding: 8px 10px;
  cursor: pointer; font-size: 11px; border-bottom: 2px solid transparent; white-space: nowrap;
}
.sc-tab-btn:hover { color: var(--sc-text, #e2e8f0); background: var(--sc-bg2, #1e293b); }
.sc-tab-btn.sc-active {
  color: var(--sc-text, #e2e8f0);
  background: var(--sc-bg2, #1e293b);
  border-bottom-color: var(--sc-accent, #6366f1);
  font-weight: 600;
}
.sc-tab-content { padding: 12px 14px; overflow-y: auto; flex: 1; }
.sc-tab-content.sc-hidden { display: none; }
.sc-os-selector { display: flex; gap: 6px; margin: 8px 0; flex-wrap: wrap; }
.sc-os-btn { background: var(--sc-bg2, #1e293b); color: var(--sc-text-muted, #94a3b8); border: 1px solid var(--sc-bg3, #334155); border-radius: 4px; padding: 4px 10px; font-size: 11px; cursor: pointer; }
.sc-os-btn:hover { background: var(--sc-bg3, #334155); color: var(--sc-text, #e2e8f0); }
.sc-os-btn.sc-os-active { background: var(--sc-accent, #6366f1); color: #fff; border-color: var(--sc-accent, #6366f1); font-weight: 600; }
.sc-ioc-group { margin-bottom: 12px; }
.sc-ioc-type { font-weight: 700; color: var(--sc-accent-light, #a5b4fc); margin-bottom: 4px; text-transform: uppercase; font-size: 11px; }
.sc-ioc-row { display: flex; flex-wrap: wrap; align-items: center; gap: 6px; padding: 4px 0; border-bottom: 1px solid var(--sc-bg2, #1e293b); }
.sc-ioc-row code { background: var(--sc-bg2, #1e293b); padding: 2px 5px; border-radius: 4px; word-break: break-all; flex: 1; min-width: 120px; }
.sc-ioc-actions { display: flex; gap: 4px; }
.sc-ioc-actions button, .sc-report-btn, .sc-llm-btn {
  background: var(--sc-bg3, #334155); color: var(--sc-text, #e2e8f0); border: none; border-radius: 4px;
  padding: 3px 7px; font-size: 11px; cursor: pointer;
}
.sc-ioc-actions button:hover, .sc-report-btn:hover, .sc-llm-btn:hover { background: var(--sc-bg3-hover, #475569); }
.sc-enrich-result { font-size: 11px; width: 100%; }
.sc-enrich-result.sc-bad { color: #f87171; font-weight: 700; }
.sc-enrich-result.sc-ok { color: #4ade80; }
.sc-field { margin-bottom: 8px; }
.sc-muted { color: #64748b; }
.sc-playbook-title { font-weight: 700; margin-bottom: 8px; color: var(--sc-accent-light, #a5b4fc); }
.sc-step { display: flex; gap: 6px; align-items: flex-start; margin-bottom: 6px; cursor: pointer; }
.sc-report-btn, .sc-llm-btn, .sc-llm-predict-btn { margin-bottom: 10px; width: 100%; padding: 8px; background: var(--sc-bg3, #334155); color: var(--sc-text, #e2e8f0); border: none; border-radius: 4px; cursor: pointer; font-size: 11px; }
.sc-report-btn:hover, .sc-llm-btn:hover, .sc-llm-predict-btn:hover { background: var(--sc-bg3-hover, #475569); }
.sc-section-title { font-weight: 700; color: var(--sc-accent-light, #a5b4fc); margin: 14px 0 6px; font-size: 12px; text-transform: uppercase; }
.sc-section-title:first-child { margin-top: 0; }
.sc-killchain { display: flex; flex-wrap: wrap; gap: 4px; margin-bottom: 6px; }
.sc-kc-pill { font-size: 10px; padding: 3px 6px; border-radius: 10px; background: var(--sc-bg2, #1e293b); color: #64748b; }
.sc-kc-pill.sc-kc-hit { background: var(--sc-accent, #6366f1); color: #fff; }
.sc-technique { display: flex; align-items: center; gap: 6px; padding: 5px 0; border-bottom: 1px solid var(--sc-bg2, #1e293b); flex-wrap: wrap; font-size: 12px; }
.sc-technique a { color: var(--sc-link, #818cf8); text-decoration: none; font-weight: 700; }
.sc-technique a:hover { text-decoration: underline; }
.sc-tactic-tag { background: var(--sc-bg2, #1e293b); color: var(--sc-text-muted, #94a3b8); font-size: 10px; padding: 2px 6px; border-radius: 8px; margin-left: auto; }
.sc-badge-beta { background: #7c3aed; color: #fff; font-size: 9px; padding: 1px 5px; border-radius: 6px; text-transform: none; margin-left: 6px; }
.sc-disclaimer { color: var(--sc-warning, #f59e0b); font-size: 11px; margin: 0 0 8px; }
.sc-hint-bubble {
  display: flex; align-items: flex-start; gap: 8px; background: var(--sc-bg2, #1e293b);
  border: 1px solid var(--sc-accent, #6366f1); border-left-width: 3px; border-radius: 6px;
  padding: 8px 10px; margin-bottom: 10px; font-size: 12px; line-height: 1.45; color: var(--sc-text-secondary, #cbd5e1);
}
.sc-hint-bubble .sc-hint-icon { flex-shrink: 0; }
.sc-hint-bubble .sc-hint-text { flex: 1; }
.sc-hint-dismiss {
  flex-shrink: 0; background: none; border: none; color: var(--sc-text-muted, #94a3b8);
  cursor: pointer; font-size: 14px; line-height: 1; padding: 0 2px;
}
.sc-hint-dismiss:hover { color: var(--sc-text, #e2e8f0); }
.sc-predict-card { background: var(--sc-bg2, #1e293b); border-radius: 6px; padding: 8px; margin-bottom: 6px; }
.sc-predict-head { display: flex; gap: 6px; align-items: center; }
.sc-predict-head a { color: var(--sc-link, #818cf8); font-weight: 700; text-decoration: none; }
.sc-predict-meta { font-size: 11px; color: var(--sc-text-muted, #94a3b8); margin-top: 2px; }
.sc-conf-curated { color: #4ade80; }
.sc-conf-heuristic { color: #fbbf24; }
.sc-llm-predict-output { white-space: pre-wrap; font-size: 11px; background: var(--sc-bg2, #1e293b); padding: 8px; border-radius: 6px; max-height: 250px; overflow-y: auto; }
.sc-redaction-preview { margin-bottom: 8px; font-size: 11px; }
.sc-redaction-preview summary { cursor: pointer; color: #4ade80; padding: 4px 0; }
.sc-redaction-preview pre { white-space: pre-wrap; background: var(--sc-bg2, #1e293b); padding: 8px; border-radius: 6px; max-height: 180px; overflow-y: auto; margin-top: 4px; color: var(--sc-text-muted, #94a3b8); }
.sc-mentor-progress { font-size: 11px; color: var(--sc-text-muted, #94a3b8); background: var(--sc-bg2, #1e293b); padding: 8px 10px; border-radius: 6px; margin-bottom: 8px; line-height: 1.5; }
.sc-mentor-dots { display: flex; gap: 5px; margin-bottom: 10px; }
.sc-mentor-dot { width: 8px; height: 8px; border-radius: 50%; background: var(--sc-bg3, #334155); }
.sc-mentor-dot-active { background: var(--sc-accent, #6366f1); transform: scale(1.3); }
.sc-mentor-dot-done { background: #4ade80; }
.sc-mentor-step { background: var(--sc-bg2, #1e293b); border-radius: 8px; padding: 12px; margin-bottom: 10px; }
.sc-mentor-step-title { font-weight: 700; color: var(--sc-accent-light, #a5b4fc); margin-bottom: 6px; font-size: 13px; }
.sc-mentor-explain { font-size: 12px; line-height: 1.55; color: var(--sc-text, #e2e8f0); margin: 0 0 10px; }
.sc-mentor-quiz p { font-size: 12px; margin-bottom: 8px; }
.sc-mentor-quiz-option {
  display: block; width: 100%; text-align: left; background: var(--sc-bg3, #334155); color: var(--sc-text, #e2e8f0); border: none;
  border-radius: 6px; padding: 8px 10px; margin-bottom: 6px; cursor: pointer; font-size: 12px;
}
.sc-mentor-quiz-option:hover { background: var(--sc-bg3-hover, #475569); }
.sc-mentor-quiz-result { font-size: 12px; padding: 10px; border-radius: 6px; line-height: 1.5; }
.sc-mentor-correct { background: rgba(74, 222, 128, .15); color: #4ade80; }
.sc-mentor-incorrect { background: rgba(248, 113, 113, .15); color: #f87171; }
.sc-mentor-reflection-q { font-size: 12px; margin-bottom: 6px; }
.sc-mentor-reflection-input {
  width: 100%; box-sizing: border-box; background: var(--sc-bg, #0f172a); color: var(--sc-text, #e2e8f0); border: 1px solid var(--sc-bg3, #334155);
  border-radius: 6px; padding: 6px 8px; font: inherit; font-size: 12px; resize: vertical;
}
.sc-mentor-nav { display: flex; flex-wrap: wrap; gap: 8px; margin-bottom: 14px; }
.sc-mentor-nav button { min-width: 90px; }
.sc-mentor-nav button {
  flex: 1; background: var(--sc-bg3, #334155); color: var(--sc-text, #e2e8f0); border: none; border-radius: 4px; padding: 8px; cursor: pointer; font-size: 12px;
}
.sc-mentor-nav button:hover:not(:disabled) { background: var(--sc-bg3-hover, #475569); }
.sc-mentor-nav button:disabled { opacity: .4; cursor: default; }
.sc-hint-inline { font-size: 11px; color: #64748b; margin: 0 0 6px; }
.sc-mentor-ask-input {
  width: 100%; box-sizing: border-box; background: var(--sc-bg2, #1e293b); color: var(--sc-text, #e2e8f0); border: 1px solid var(--sc-bg3, #334155);
  border-radius: 6px; padding: 6px 8px; font: inherit; font-size: 12px; margin-bottom: 6px; resize: vertical;
}
.sc-mentor-ask-btn { width: 100%; padding: 8px; margin-bottom: 8px; background: #7c3aed; color: #fff; border: none; border-radius: 4px; cursor: pointer; font-size: 12px; }
.sc-mentor-ask-btn:hover { background: #6d28d9; }
.sc-mentor-ask-output { white-space: pre-wrap; font-size: 12px; background: var(--sc-bg2, #1e293b); padding: 8px; border-radius: 6px; max-height: 220px; overflow-y: auto; }
.sc-belzor-toast { border-color: var(--sc-warning, #f59e0b); white-space: pre-line; }
.sc-belzor-card {
  background: linear-gradient(135deg, #7c3aed, #4338ca); border-radius: 8px; padding: 14px;
  margin-bottom: 12px; text-align: center;
}
.sc-belzor-balance { font-size: 20px; font-weight: 800; color: #fff; }
.sc-belzor-rank { font-size: 11px; color: #ede9fe; margin-top: 4px; }
.sc-stats-row { display: flex; justify-content: space-between; padding: 5px 0; border-bottom: 1px solid var(--sc-bg2, #1e293b); font-size: 12px; }
.sc-stats-periods { display: flex; flex-wrap: wrap; gap: 4px; margin-bottom: 10px; }
.sc-stats-period-btn {
  background: var(--sc-bg3, #334155); color: var(--sc-text-muted, #94a3b8); border: none; border-radius: 12px; padding: 4px 10px;
  font-size: 11px; cursor: pointer;
}
.sc-stats-period-btn.sc-active { background: var(--sc-accent, #6366f1); color: #fff; }
.sc-stats-export-btn { width: 100%; padding: 8px; margin: 12px 0 6px; background: #16a34a; color: #fff; border: none; border-radius: 4px; cursor: pointer; font-size: 12px; }
.sc-stats-export-btn:hover { background: #15803d; }
.sc-pro-badge {
  background: #f59e0b; color: #111; font-size: 9px; font-weight: 800; padding: 1px 5px;
  border-radius: 4px; margin-left: 4px; vertical-align: middle;
}
.sc-mentor-track-switch { display: flex; flex-wrap: wrap; gap: 4px; margin-bottom: 10px; }
.sc-mentor-track-btn {
  flex: 1; background: var(--sc-bg3, #334155); color: var(--sc-text-muted, #94a3b8); border: none; border-radius: 6px;
  padding: 6px 4px; font-size: 11px; cursor: pointer;
}
.sc-mentor-track-btn.sc-active { background: #7c3aed; color: #fff; }
.sc-dfir-tool { background: var(--sc-bg2, #1e293b); border-radius: 6px; padding: 10px; margin-bottom: 8px; }
.sc-dfir-tool-head { display: flex; align-items: center; gap: 6px; flex-wrap: wrap; }
.sc-dfir-tool-head a { color: var(--sc-link, #818cf8); font-weight: 700; text-decoration: none; font-size: 13px; }
.sc-dfir-tool-head a:hover { text-decoration: underline; }
.sc-dfir-tool-desc { font-size: 11px; color: var(--sc-text-secondary, #cbd5e1); margin: 4px 0; }
.sc-dfir-tool-license { font-size: 10px; color: var(--sc-warning, #f59e0b); margin: 0 0 4px; }
.sc-dfir-quickstart summary { cursor: pointer; color: #4ade80; font-size: 11px; }
.sc-dfir-quickstart ol { font-size: 11px; color: var(--sc-text-secondary, #cbd5e1); margin: 6px 0 0; padding-left: 18px; }
.sc-dfir-quickstart li { margin-bottom: 3px; }
.sc-szi-rec { background: var(--sc-bg2, #1e293b); border-radius: 6px; padding: 8px 10px; margin-bottom: 6px; font-size: 12px; }
.sc-l3-list { font-size: 12px; line-height: 1.6; padding-left: 18px; margin: 0 0 10px; color: var(--sc-text-secondary, #cbd5e1); }
.sc-l3-list li { margin-bottom: 6px; }
.sc-gossopka-draft-btn { width: 100%; padding: 8px; background: var(--sc-bg3, #334155); color: var(--sc-text, #e2e8f0); border: none; border-radius: 4px; cursor: pointer; font-size: 12px; margin-bottom: 6px; }
.sc-gossopka-draft-btn:hover { background: var(--sc-bg3-hover, #475569); }
.sc-gossopka-link { display: block; font-size: 12px; color: var(--sc-link, #818cf8); text-decoration: none; margin-bottom: 8px; }
.sc-gossopka-link:hover { text-decoration: underline; }
.sc-gossopka-draft-preview { white-space: pre-wrap; font-size: 11px; background: var(--sc-bg2, #1e293b); padding: 8px; border-radius: 6px; max-height: 280px; overflow-y: auto; }
.sc-verdict-options { display: flex; flex-direction: column; gap: 4px; margin-bottom: 10px; }
.sc-verdict-option { display: flex; align-items: center; gap: 6px; font-size: 12px; cursor: pointer; }
.sc-conclusion-input {
  width: 100%; box-sizing: border-box; background: var(--sc-bg2, #1e293b); color: var(--sc-text, #e2e8f0); border: 1px solid var(--sc-bg3, #334155);
  border-radius: 6px; padding: 6px 8px; font: inherit; font-size: 12px; margin-bottom: 4px; resize: vertical;
}
.sc-conclusion-generate-btn, .sc-conclusion-pdf-btn, .sc-conclusion-save-btn {
  width: 100%; padding: 8px; margin-bottom: 8px; background: var(--sc-bg3, #334155); color: var(--sc-text, #e2e8f0); border: none; border-radius: 4px; cursor: pointer; font-size: 12px;
}
.sc-conclusion-save-btn { background: #16a34a; }
.sc-conclusion-broadcast-btn { width: 100%; padding: 8px; margin-bottom: 8px; background: #0ea5e9; color: #fff; border: none; border-radius: 4px; cursor: pointer; font-size: 12px; }
.sc-conclusion-broadcast-btn:hover { background: #0284c7; }
.sc-conclusion-generate-btn:hover, .sc-conclusion-pdf-btn:hover { background: var(--sc-bg3-hover, #475569); }
.sc-conclusion-save-btn:hover { background: #15803d; }
.sc-conclusion-preview { white-space: pre-wrap; font-size: 11px; background: var(--sc-bg2, #1e293b); padding: 8px; border-radius: 6px; max-height: 280px; overflow-y: auto; }
.sc-similar-row { display: flex; align-items: center; gap: 6px; padding: 4px 0; border-bottom: 1px solid var(--sc-bg2, #1e293b); font-size: 12px; flex-wrap: wrap; }
.sc-similar-row a { color: var(--sc-link, #818cf8); text-decoration: none; }
.sc-similar-row a:hover { text-decoration: underline; }
.sc-verdict-badge { font-size: 10px; padding: 1px 6px; border-radius: 8px; font-weight: 700; }
.sc-verdict-tp { background: #dc2626; color: #fff; }
.sc-verdict-fp { background: #16a34a; color: #fff; }
.sc-verdict-benign { background: #64748b; color: #fff; }
.sc-verdict-escalate { background: #f59e0b; color: #111; }
.sc-ask-toast {
  position: fixed; bottom: 24px; right: 20px; max-width: 340px; z-index: 2147483002;
  background: var(--sc-bg2, #1e293b); color: var(--sc-text, #e2e8f0); border: 1px solid var(--sc-accent, #6366f1); border-radius: 8px;
  padding: 12px 14px; font: 12px/1.5 system-ui, sans-serif; box-shadow: 0 8px 24px rgba(0,0,0,.4);
  opacity: 0; transform: translateY(10px); transition: opacity .25s, transform .25s; white-space: pre-wrap;
}
.sc-ask-toast.sc-show { opacity: 1; transform: translateY(0); }
.sc-report-preview, .sc-llm-output { white-space: pre-wrap; font-size: 11px; background: var(--sc-bg2, #1e293b); padding: 8px; border-radius: 6px; max-height: 300px; overflow-y: auto; }
.sc-storm-banner {
  background: var(--sc-warning-bg, rgba(245, 158, 11, .15)); border: 1px solid var(--sc-warning, #f59e0b); border-radius: 6px;
  padding: 8px 10px; font-size: 11px; color: var(--sc-warning-text, #fcd34d); margin-bottom: 10px; line-height: 1.5;
}
.sc-snippets-panel { width: 100%; margin-top: 4px; display: none; }
.sc-snippets-panel.sc-snippets-open { display: block; }
.sc-snippet { background: var(--sc-bg, #0f172a); border-radius: 6px; padding: 8px; margin-bottom: 6px; }
.sc-snippet-tool { font-size: 10px; color: var(--sc-accent-light, #a5b4fc); font-weight: 700; margin-bottom: 4px; }
.sc-snippet-code { font-size: 10px; white-space: pre-wrap; word-break: break-all; color: var(--sc-text-secondary, #cbd5e1); margin: 0 0 6px; }
.sc-snippet-copy { background: var(--sc-bg3, #334155); color: var(--sc-text, #e2e8f0); border: none; border-radius: 4px; padding: 3px 8px; font-size: 10px; cursor: pointer; }
.sc-snippet-copy:hover { background: var(--sc-bg3-hover, #475569); }
.sc-burnout-toast { border-color: #38bdf8; white-space: pre-line; }
.sc-voice-btn {
  background: none; border: none; cursor: pointer; font-size: 12px; padding: 0 4px;
  vertical-align: middle; opacity: .8;
}
.sc-voice-btn:hover { opacity: 1; }
.sc-section-title { display: flex; align-items: center; gap: 4px; }
.sc-campaign-canvas { width: 100%; max-width: 320px; background: var(--sc-bg, #0f172a); border-radius: 8px; cursor: pointer; display: block; margin: 0 auto; }

/* ===== Темы оформления =====
   По умолчанию (без класса) — тёмная тема "Indigo Night", как было изначально.
   Класс добавляется на shadowHost (элемент в light DOM, владелец shadow root) в JS
   по выбору в настройках — используем :host(), чтобы стили унаследовались во ВСЁ
   shadow-дерево, включая кнопку-тумблер .sc-toggle, которая лежит вне .sc-panel. */

:host(.sc-theme-light) {
  --sc-bg: #ffffff;
  --sc-bg2: #f1f5f9;
  --sc-bg3: #e2e8f0;
  --sc-bg3-hover: #cbd5e1;
  --sc-text: #0f172a;
  --sc-text-muted: #64748b;
  --sc-text-secondary: #334155;
  --sc-accent: #4f46e5;
  --sc-accent-light: #4338ca;
  --sc-link: #4f46e5;
  /* Тёмный янтарный, а не стандартный #f59e0b — на светлом/сером фоне обычный
     амбер даёт контраст ~1.9:1 (не читается, жалоба из аудита UI). #b45309
     даёт ~4.6:1 на белом — проходит WCAG AA для обычного текста. */
  --sc-warning: #b45309;
  --sc-warning-bg: rgba(180, 83, 9, .10);
  --sc-warning-text: #92400e;
}

:host(.sc-theme-contrast) {
  --sc-bg: #000000;
  --sc-bg2: #0a0a0a;
  --sc-bg3: #1a1a1a;
  --sc-bg3-hover: #2a2a2a;
  --sc-text: #ffffff;
  --sc-text-muted: #d4d4d4;
  --sc-text-secondary: #ffffff;
  --sc-accent: #ffff00;
  --sc-accent-light: #ffff00;
  --sc-link: #00ffff;
  --sc-warning: #ffaa00;
  --sc-warning-bg: rgba(255, 170, 0, .15);
  --sc-warning-text: #ffaa00;
}
/* Высокий контраст: жирные видимые границы у интерактивных элементов —
   для WCAG-совместимости недостаточно только смены цвета, нужна ещё и форма/контур. */
:host(.sc-theme-contrast) button, :host(.sc-theme-contrast) input, :host(.sc-theme-contrast) textarea {
  border: 1px solid #ffffff !important;
}
:host(.sc-theme-contrast) .sc-tab-btn.sc-active { border-bottom-width: 3px; }

/* RTL: сам flexbox отзеркаливается автоматически через dir="rtl" на .sc-panel.
   Точечные исключения — элементы, которые НЕ должны переворачиваться визуально:
   canvas с графом (координаты рисуются в фиксированной системе) и переключатель
   вкладки-тумблера (остаётся у правого края экрана независимо от языка панели). */
.sc-panel.sc-rtl .sc-campaign-canvas { direction: ltr; }
.sc-glossary-refresh-btn { width: 100%; padding: 8px; margin-bottom: 10px; background: var(--sc-bg3, #334155); color: var(--sc-text, #e2e8f0); border: none; border-radius: 4px; cursor: pointer; font-size: 12px; }
.sc-glossary-refresh-btn:hover { background: var(--sc-bg3-hover, #475569); }
.sc-glossary-term { background: var(--sc-bg2, #1e293b); border-radius: 8px; padding: 10px; margin-bottom: 8px; }
.sc-glossary-head { display: flex; align-items: center; gap: 6px; flex-wrap: wrap; }
.sc-glossary-def { font-size: 12px; color: var(--sc-text-secondary, #cbd5e1); margin: 4px 0 6px; }
.sc-glossary-meta { display: flex; align-items: center; gap: 8px; font-size: 11px; }
.sc-glossary-vote { background: var(--sc-bg3, #334155); color: var(--sc-text, #e2e8f0); border: none; border-radius: 10px; padding: 2px 8px; font-size: 11px; cursor: pointer; }
.sc-glossary-vote:hover { background: var(--sc-bg3-hover, #475569); }
.sc-glossary-input {
  width: 100%; box-sizing: border-box; background: var(--sc-bg2, #1e293b); color: var(--sc-text, #e2e8f0);
  border: 1px solid var(--sc-bg3, #334155); border-radius: 6px; padding: 6px 8px; font: inherit; font-size: 12px;
  margin-bottom: 6px; resize: vertical;
}
.sc-glossary-submit-btn { width: 100%; padding: 8px; background: var(--sc-accent, #6366f1); color: #fff; border: none; border-radius: 4px; cursor: pointer; font-size: 12px; }
.sc-glossary-submit-btn:hover { background: var(--sc-accent-light, #a5b4fc); }
`;
