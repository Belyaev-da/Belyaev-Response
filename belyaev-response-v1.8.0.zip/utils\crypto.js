// utils/crypto.js
// Шифрование чувствительных данных (API-ключи, токены ботов, лицензионный ключ)
// перед записью в chrome.storage.local — AES-256-GCM через встроенный WebCrypto API
// (никаких сторонних крипто-библиотек).
//
// Модель угроз и что это даёт:
// - chrome.storage.local физически хранится на диске в открытом виде (LevelDB) и
//   технически может быть прочитан любым процессом с доступом к профилю браузера,
//   другим расширением с широкими правами, синхронизирован в облако и т.п. Хранить
//   секреты открытым текстом там — плохая практика по умолчанию.
// - Шифрование ключом, сгенерированным на устройстве (см. ниже), означает, что при
//   простом просмотре/дампе/экспорте storage.local (в том числе автоматическим
//   агентом или LLM с доступом к инструменту чтения браузера) вместо ключа API будет
//   виден непрозрачный шифротекст — нужно ещё найти и использовать ключ шифрования,
//   который лежит отдельно и не экспортируется вместе с настройками (см. options.js:
//   экспорт настроек команды НИКОГДА не включает зашифрованные секреты).
// - ЧЕСТНО про предел этой защиты: ключ шифрования хранится в том же chrome.storage.local
//   (иначе расшифровка вообще невозможна без участия пользователя каждый раз) — поэтому
//   это защита от НЕЦЕЛЕНАПРАВЛЕННОГО чтения (казуальный дамп, чужое менее привилегированное
//   расширение, автоматический скрипт, который просто выгружает storage.local целиком и не
//   знает, что нужно ещё найти и применить ключ), а не криптографически стойкая защита от
//   злоумышленника с полным контролем над тем же браузерным профилем и временем на анализ
//   расширения. Это разумный, честно описанный уровень defense-in-depth, а не панацея.

const SOC_COPILOT_CRYPTO_KEY_STORAGE = "socCopilotStorageKeyRawB64";

function bufToBase64(buf) {
  const bytes = new Uint8Array(buf);
  let binary = "";
  for (let i = 0; i < bytes.length; i++) binary += String.fromCharCode(bytes[i]);
  return btoa(binary);
}

function base64ToBuf(b64) {
  const binary = atob(b64);
  const bytes = new Uint8Array(binary.length);
  for (let i = 0; i < binary.length; i++) bytes[i] = binary.charCodeAt(i);
  return bytes.buffer;
}

let cachedKeyPromise = null;

// Получает (или при первом вызове генерирует) AES-256 ключ шифрования, специфичный
// для этой установки расширения. Ключ кэшируется в памяти на время жизни контекста
// (service worker / content script), чтобы не читать storage на каждую операцию.
async function socCopilotGetStorageKey() {
  if (cachedKeyPromise) return cachedKeyPromise;
  cachedKeyPromise = (async () => {
    const data = await chrome.storage.local.get([SOC_COPILOT_CRYPTO_KEY_STORAGE]);
    let rawB64 = data[SOC_COPILOT_CRYPTO_KEY_STORAGE];
    if (!rawB64) {
      const rawBytes = crypto.getRandomValues(new Uint8Array(32)); // 256 бит
      rawB64 = bufToBase64(rawBytes.buffer);
      await chrome.storage.local.set({ [SOC_COPILOT_CRYPTO_KEY_STORAGE]: rawB64 });
    }
    return crypto.subtle.importKey("raw", base64ToBuf(rawB64), { name: "AES-GCM" }, false, ["encrypt", "decrypt"]);
  })();
  return cachedKeyPromise;
}

// Шифрует строку. Возвращает компактную строку "v1:<iv_base64>:<ciphertext_base64>"
// либо null, если на вход подали пусто (чтобы не шифровать "ничего" бессмысленно).
async function socCopilotEncryptString(plaintext) {
  if (plaintext === null || plaintext === undefined || plaintext === "") return null;
  const key = await socCopilotGetStorageKey();
  const iv = crypto.getRandomValues(new Uint8Array(12)); // 96 бит — рекомендация для AES-GCM
  const encoded = new TextEncoder().encode(String(plaintext));
  const ciphertext = await crypto.subtle.encrypt({ name: "AES-GCM", iv }, key, encoded);
  return `v1:${bufToBase64(iv.buffer)}:${bufToBase64(ciphertext)}`;
}

// Расшифровывает строку, созданную socCopilotEncryptString. Возвращает null при
// любой ошибке (повреждённые данные, смена ключа и т.п.) — НИКОГДА не бросает
// исключение наружу, чтобы вызывающий код мог просто трактовать null как "не задано".
async function socCopilotDecryptString(encoded) {
  if (!encoded || typeof encoded !== "string" || !encoded.startsWith("v1:")) return null;
  try {
    const [, ivB64, dataB64] = encoded.split(":");
    const key = await socCopilotGetStorageKey();
    const iv = new Uint8Array(base64ToBuf(ivB64));
    const plainBuf = await crypto.subtle.decrypt({ name: "AES-GCM", iv }, key, base64ToBuf(dataB64));
    return new TextDecoder().decode(plainBuf);
  } catch (e) {
    console.warn("[crypto] Не удалось расшифровать значение (повреждено или ключ утерян):", e.message);
    return null;
  }
}

if (typeof module !== "undefined") {
  module.exports = { socCopilotEncryptString, socCopilotDecryptString, socCopilotGetStorageKey };
}
