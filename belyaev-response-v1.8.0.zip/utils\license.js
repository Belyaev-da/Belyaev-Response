// utils/license.js
// Логика лицензирования: бесплатный период, статус подписки, разделение фич.
//
// Модель: по умолчанию — 30 дней полнофункционального триала с момента установки
// (локально, без обращения к серверу — упрощённо и без блокировки первого запуска).
// После истечения триала без активной лицензии — Free-тариф. Лицензия активируется
// через сервер лицензирования (см. /license-server) и периодически перепроверяется.
//
// Разделение Free/Pro: в Free остаются функции с наибольшим охватом и минимальной
// стоимостью для оператора (нет платных внешних API-вызовов) — это то, что должно
// "зацепить" массового пользователя. В Pro — функции, требующие оплачиваемых LLM-
// запросов (аналитик или организация платит за токены так или иначе) и функции,
// критичные для командной работы/менеджмента (рассылка в каналы, PDF для комплаенса,
// телеметрия для руководителя).

const SOC_COPILOT_TRIAL_DAYS = 30;

const SOC_COPILOT_PRO_FEATURES = {
  llmSummary: "Улучшение сводки инцидента через LLM",
  llmPredict: "LLM-уточнение прогноза следующего шага (MITRE)",
  llmMentorAsk: "Диалог с AI-наставником (Socratic Q&A)",
  askSelection: "«Спросить AI про выделенное» на любой странице",
  conclusionPdf: "Экспорт заключения в PDF",
  conclusionBroadcast: "Отправка заключения в Slack / Telegram / MAX",
  grafanaSync: "Синхронизация статистики с сервером/Grafana",
  glossary: "Живой глоссарий терминов SIEM (community)"
};

function socCopilotComputeLicenseState({ installDate, license, now = Date.now() }) {
  const installTime = new Date(installDate || now).getTime();
  const trialEndTime = installTime + SOC_COPILOT_TRIAL_DAYS * 24 * 60 * 60 * 1000;
  const trialActive = now < trialEndTime;
  const trialDaysLeft = Math.max(0, Math.ceil((trialEndTime - now) / (24 * 60 * 60 * 1000)));

  const licenseActive = !!(license && license.status === "active" && license.expiresAt && new Date(license.expiresAt).getTime() > now);

  if (licenseActive) {
    return {
      tier: "pro",
      source: "license",
      orgName: license.orgName || "",
      expiresAt: license.expiresAt,
      trialActive: false,
      trialDaysLeft: 0
    };
  }
  if (trialActive) {
    return {
      tier: "pro",
      source: "trial",
      orgName: "",
      expiresAt: new Date(trialEndTime).toISOString(),
      trialActive: true,
      trialDaysLeft
    };
  }
  return { tier: "free", source: "none", orgName: "", expiresAt: null, trialActive: false, trialDaysLeft: 0 };
}

function socCopilotIsPro(licenseState) {
  return !!licenseState && licenseState.tier === "pro";
}

if (typeof module !== "undefined") {
  module.exports = {
    SOC_COPILOT_TRIAL_DAYS,
    SOC_COPILOT_PRO_FEATURES,
    socCopilotComputeLicenseState,
    socCopilotIsPro
  };
}
