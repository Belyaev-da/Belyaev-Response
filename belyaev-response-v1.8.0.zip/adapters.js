// adapters.js
// Адаптер описывает, как расширение находит поля карточки инцидента/события
// на конкретной SIEM-платформе. Так как MP SIEM, RuSIEM и BI.ZONE обычно
// разворачиваются on-prem на кастомных доменах и разметка может меняться
// от версии к версии, точные CSS-селекторы НЕ хардкодятся — это плейсхолдеры.
// Аналитик заполняет их один раз через "Пикер элементов" в настройках
// (options -> вкладка адаптера -> "Выбрать на странице"), после чего
// конфиг сохраняется в chrome.storage.local и используется дальше.

const SOC_COPILOT_DEFAULT_ADAPTERS = [
  {
    id: "mpsiem",
    name: "MaxPatrol SIEM",
    vendor: "Positive Technologies",
    enabled: true,
    // Подстроки пути/URL, по которым расширение решает, что это карточка
    // инцидента этой платформы. Отредактируйте под свой домен/маршруты.
    urlPatterns: ["/incidents/", "/events/", "/mpsiem", "ptsecurity"],
    selectors: {
      title: "",        // напр. заголовок инцидента
      description: "",  // описание / резюме
      severity: "",     // критичность
      status: "",        // статус обработки
      assignee: "",      // ответственный
      assets: "",        // затронутые активы/хосты
      timeline: "",       // таймлайн событий
      rawContainer: ""    // fallback: контейнер, откуда парсим текст целиком
    }
  },
  {
    id: "rusiem",
    name: "RuSIEM",
    vendor: "RuSIEM",
    enabled: true,
    urlPatterns: ["/incident", "/alert", "rusiem"],
    selectors: {
      title: "",
      description: "",
      severity: "",
      status: "",
      assignee: "",
      assets: "",
      timeline: "",
      rawContainer: ""
    }
  },
  {
    id: "bizone",
    name: "BI.ZONE (EDR/TDR)",
    vendor: "BI.ZONE",
    enabled: true,
    urlPatterns: ["/incidents", "/cases", "bizone"],
    selectors: {
      title: "",
      description: "",
      severity: "",
      status: "",
      assignee: "",
      assets: "",
      timeline: "",
      rawContainer: ""
    }
  },
  {
    id: "test-siem",
    name: "Тестовый стенд Belyaev Response",
    vendor: "Belyaev Response (встроенный тест)",
    enabled: true,
    urlPatterns: ["test-siem.html"],
    selectors: {
      title: "#bt-title",
      description: "#bt-description",
      severity: "#bt-severity",
      status: "#bt-status",
      assignee: "#bt-assignee",
      riskScore: "",
      timeline: "#bt-timeline",
      rawContainer: "#bt-card"
    }
  },
  {
    id: "universal",
    // Единственный универсальный адаптер (объединяет прежние "universal" и "generic"
    // fallback — они дублировали друг друга: оба матчились на любой URL). Из
    // параметра поддержки MP SIEM/RuSIEM/BI.ZONE убраны — под них уже есть
    // отдельные специфичные адаптеры выше, дублировать их здесь незачем.
    name: "Универсальный (Security Vision SIEM / SIEM KUMA / SearchInform SIEM / R-Vision SIEM / Splunk / ArcSight / любая другая)",
    vendor: "Любая SIEM-система",
    // ВАЖНО (найдено при аудите безопасности/приватности): этот адаптер не имеет
    // urlPatterns и потому технически совпадает с ЛЮБЫМ сайтом. Если включить его
    // по умолчанию, расширение будет извлекать текст, писать событие в eventsLog
    // и регистрировать вкладку для кросс-корреляции на КАЖДОМ посещаемом сайте —
    // а не только на карточках инцидентов SIEM. По умолчанию — ВЫКЛЮЧЕН, включение —
    // осознанное действие аналитика в настройках (с явным предупреждением там же).
    enabled: false,
    urlPatterns: [], // подходит всегда, если ни один другой адаптер не сматчился
    selectors: {
      title: "h1, h2, .incident-title, .alert-title, [data-field='name']",
      description: "main, .incident-body, .alert-body, .description, [data-field='description']",
      severity: ".severity, .priority, [data-field='severity'], [data-field='priority']",
      status: ".status, [data-field='status']",
      assignee: ".assignee, .owner, [data-field='assignee']",
      riskScore: ".risk-score, [data-field='riskScore']",
      timeline: ".timeline, .events, [data-field='timeline']",
      rawContainer: "main, .container, body"
    }
  }
];

// Определяет, подходит ли адаптер под текущий URL
function socCopilotMatchAdapter(adapter, href) {
  if (!adapter.enabled) return false;
  if (!adapter.urlPatterns || adapter.urlPatterns.length === 0) return true; // generic fallback
  return adapter.urlPatterns.some((p) => p && href.toLowerCase().includes(p.toLowerCase()));
}

// Выбирает наиболее подходящий адаптер: сначала те, что привязаны к конкретным
// URL-паттернам (специфичные платформы), и только если ни один не подошёл —
// адаптер-fallback (пустой urlPatterns, сейчас это "universal").
function socCopilotResolveAdapter(adapters, href) {
  const enabled = adapters.filter((a) => a.enabled);
  const specific = enabled.filter((a) => a.urlPatterns && a.urlPatterns.length > 0);
  const match = specific.find((a) => socCopilotMatchAdapter(a, href));
  if (match) return match;
  return enabled.find((a) => !a.urlPatterns || a.urlPatterns.length === 0) || null;
}

if (typeof module !== "undefined") {
  module.exports = { SOC_COPILOT_DEFAULT_ADAPTERS, socCopilotMatchAdapter, socCopilotResolveAdapter };
}
