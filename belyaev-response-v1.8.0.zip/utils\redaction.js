// utils/redaction.js
// Обезличивание чувствительных данных ПЕРЕД любой отправкой текста во внешний LLM.
// Используется и в content.js (для сборки контекста запроса), и в background.js
// (через importScripts — см. ниже) для запроса "Спросить AI про выделенное",
// который приходит из контекстного меню в обход content.js.
//
// Принцип: находим чувствительные значения, заменяем их на плейсхолдеры вида
// [[TYPE_N]], запоминаем соответствие в локальной (никуда не отправляемой) карте.
// После получения ответа модели плейсхолдеры можно вернуть обратно в исходный
// текст функцией socCopilotRestoreSensitiveData — так аналитик видит настоящие
// значения, а модель их не видела вообще.

const SOC_COPILOT_REDACTION_PATTERNS = {
  sshPrivateKey: /-----BEGIN [A-Z0-9 ]*PRIVATE KEY-----[\s\S]*?-----END [A-Z0-9 ]*PRIVATE KEY-----/g,
  sshPublicKey: /\bssh-(?:rsa|ed25519|dss|ecdsa[-a-z0-9]*)\s+[A-Za-z0-9+/=]{20,}(?:\s+\S+)?/g,
  awsAccessKey: /\bAKIA[0-9A-Z]{16}\b/g,
  jwtToken: /\beyJ[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,}\b/g,
  mac: /\b[0-9A-Fa-f]{2}(?:[:-][0-9A-Fa-f]{2}){5}\b/g,
  ipv6: /\b(?:[a-fA-F0-9]{1,4}:){2,7}[a-fA-F0-9]{1,4}\b/g,
  ipv4: /\b(?:(?:25[0-5]|2[0-4]\d|1?\d?\d)\.){3}(?:25[0-5]|2[0-4]\d|1?\d?\d)\b/g,
  email: /\b[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}\b/g
};

// Учётные записи по контексту (после ключевого слова) — эвристика, не 100% точная,
// т.к. точный формат зависит от локали SIEM. Дополняется списком слов в options.
const SOC_COPILOT_ACCOUNT_KEYWORD_REGEX =
  /(логин|пользовател[ья]|учетна[яю] запис[ьи]|учётна[яю] запис[ьи]|username|user ?name|account|login)\s*[:=]\s*["']?([A-Za-zА-Яа-яЁё0-9_.\\@-]{2,64})["']?/gi;

// DOMAIN\username — типичный формат Windows-учёток в логах.
const SOC_COPILOT_DOMAIN_ACCOUNT_REGEX = /\b[A-Za-z0-9_.-]{2,20}\\[A-Za-z0-9_.-]{2,32}\b/g;

function socCopilotRedactSensitiveData(text, options = {}) {
  if (!text) return { text: "", mapping: {} };
  let result = text;
  const mapping = {}; // placeholder -> исходное значение
  const counters = {};

  function placeholderFor(value, label) {
    const existing = Object.keys(mapping).find((k) => mapping[k] === value);
    if (existing) return existing;
    counters[label] = (counters[label] || 0) + 1;
    const placeholder = `[[${label}_${counters[label]}]]`;
    mapping[placeholder] = value;
    return placeholder;
  }

  function replaceByRegex(regex, label) {
    result = result.replace(regex, (match) => placeholderFor(match, label));
  }

  // Порядок важен: сначала более специфичные/длинные паттерны (ключи, JWT),
  // иначе они могут быть частично съедены менее специфичными регулярками.
  replaceByRegex(SOC_COPILOT_REDACTION_PATTERNS.sshPrivateKey, "SSH_PRIVATE_KEY");
  replaceByRegex(SOC_COPILOT_REDACTION_PATTERNS.sshPublicKey, "SSH_PUBLIC_KEY");
  replaceByRegex(SOC_COPILOT_REDACTION_PATTERNS.awsAccessKey, "AWS_KEY");
  replaceByRegex(SOC_COPILOT_REDACTION_PATTERNS.jwtToken, "TOKEN");
  replaceByRegex(SOC_COPILOT_REDACTION_PATTERNS.mac, "MAC");
  replaceByRegex(SOC_COPILOT_REDACTION_PATTERNS.ipv6, "IPV6");
  replaceByRegex(SOC_COPILOT_REDACTION_PATTERNS.ipv4, "IP");
  replaceByRegex(SOC_COPILOT_REDACTION_PATTERNS.email, "EMAIL");

  result = result.replace(SOC_COPILOT_DOMAIN_ACCOUNT_REGEX, (match) => placeholderFor(match, "ACCOUNT"));
  result = result.replace(SOC_COPILOT_ACCOUNT_KEYWORD_REGEX, (full, kw, val) => `${kw}: ${placeholderFor(val, "ACCOUNT")}`);

  // Название(я) компании/внутренние домены — задаются аналитиком в настройках,
  // т.к. автоматически определить их невозможно.
  (options.companyNames || []).forEach((name) => {
    const trimmed = (name || "").trim();
    if (!trimmed) return;
    const escaped = trimmed.replace(/[.*+?^${}()|[\]\\]/g, "\\$&");
    const regex = new RegExp(escaped, "gi");
    result = result.replace(regex, (match) => placeholderFor(match, "ORG"));
  });

  return { text: result, mapping };
}

// Возвращает плейсхолдеры вида [[TYPE_N]] обратно в исходные значения —
// используется ТОЛЬКО локально, после получения ответа модели, чтобы аналитик
// видел настоящие данные. Модель этих значений никогда не видит.
function socCopilotRestoreSensitiveData(text, mapping) {
  if (!text || !mapping) return text;
  let result = text;
  for (const [placeholder, original] of Object.entries(mapping)) {
    result = result.split(placeholder).join(original);
  }
  return result;
}

function socCopilotRedactionSummary(mapping) {
  const counts = {};
  Object.keys(mapping || {}).forEach((placeholder) => {
    const label = placeholder.replace(/^\[\[|_\d+\]\]$/g, "");
    counts[label] = (counts[label] || 0) + 1;
  });
  return counts;
}

if (typeof module !== "undefined") {
  module.exports = {
    socCopilotRedactSensitiveData,
    socCopilotRestoreSensitiveData,
    socCopilotRedactionSummary
  };
}
