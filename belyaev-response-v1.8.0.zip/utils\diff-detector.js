// utils/diff-detector.js
// Отслеживает, что изменилось в полях карточки инцидента, пока вкладка была
// неактивна (свёрнута/на фоне) — актуально при параллельной работе с несколькими
// карточками: SIEM мог обновить статус/добавить комментарий, пока аналитик смотрел
// в другую вкладку.

function socCopilotSnapshotFields(fields) {
  return {
    title: fields?.title || "",
    description: fields?.description || "",
    status: fields?.status || "",
    severity: fields?.severity || "",
    assignee: fields?.assignee || "",
    timestamp: Date.now()
  };
}

// Возвращает массив изменений {field, from, to} либо пустой массив, если ничего
// не изменилось значимо (сравнение по обрезанным/нормализованным строкам, чтобы
// не шуметь на пробельных различиях).
function socCopilotDiffFields(oldSnapshot, newFields) {
  if (!oldSnapshot) return [];
  const labels = { title: "Заголовок", description: "Описание", status: "Статус", severity: "Критичность", assignee: "Ответственный" };
  const changes = [];
  for (const key of Object.keys(labels)) {
    const before = (oldSnapshot[key] || "").trim();
    const after = (newFields?.[key] || "").trim();
    if (before !== after) {
      changes.push({ field: key, label: labels[key], from: before, to: after });
    }
  }
  return changes;
}

if (typeof module !== "undefined") {
  module.exports = { socCopilotSnapshotFields, socCopilotDiffFields };
}
