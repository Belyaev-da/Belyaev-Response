const FIELD_LABELS = {
  title: "Заголовок",
  description: "Описание",
  severity: "Критичность",
  status: "Статус",
  assignee: "Ответственный",
  assets: "Активы",
  timeline: "Таймлайн",
  rawContainer: "Контейнер (fallback)"
};

let adapters = [];
let targetTabId = null;

function toast(msg) {
  const t = document.getElementById("toast");
  t.textContent = msg;
  t.classList.add("show");
  setTimeout(() => t.classList.remove("show"), 1800);
}

// Раньше обновление настроек (тема/язык/адаптеры) уходило только в ту вкладку,
// что выбрана в выпадающем списке пикера селекторов (см. loadTabsSelector) — а не
// в ту, где аналитик реально видит панель. Из-за этого смена темы/языка выглядела
// "не работающей": содержимое просто не долетало до нужной вкладки. Теперь рассылаем
// во ВСЕ открытые вкладки; content.js на каждой сам решает, актуально ли это для неё.
function broadcastSettingsUpdated() {
  chrome.tabs.query({}, (tabs) => {
    tabs.forEach((t) => {
      if (!t.id) return;
      chrome.tabs.sendMessage(t.id, { type: "socCopilotSettingsUpdated" }, () => chrome.runtime.lastError);
    });
  });
}

function loadTabsSelector() {
  const container = document.createElement("div");
  container.innerHTML = `
    <label style="margin-bottom:16px">Вкладка с открытой карточкой инцидента (для пикера):
      <select id="tabSelect"></select>
      <button id="refreshTabs" type="button">Обновить список</button>
    </label>`;
  document.querySelector("section").after(container);

  function populate() {
    chrome.tabs.query({}, (tabs) => {
      const select = document.getElementById("tabSelect");
      select.innerHTML = "";
      tabs
        .filter((t) => t.url && /^https?:\/\//.test(t.url))
        .forEach((t) => {
          const opt = document.createElement("option");
          opt.value = t.id;
          opt.textContent = `${t.title?.slice(0, 50) || t.url} — ${t.url.slice(0, 50)}`;
          select.appendChild(opt);
        });
      targetTabId = select.value ? Number(select.value) : null;
      select.addEventListener("change", () => (targetTabId = Number(select.value)));
    });
  }
  populate();
  document.getElementById("refreshTabs").addEventListener("click", populate);
}

function renderAdapters() {
  const root = document.getElementById("adapters");
  root.innerHTML = "";
  adapters.forEach((adapter, idx) => {
    const card = document.createElement("div");
    card.className = "adapter-card";
    card.innerHTML = `
      <h3>${escapeHtml(adapter.name)} <label style="display:inline;font-size:12px;font-weight:normal">
        <input type="checkbox" data-role="enabled" ${adapter.enabled ? "checked" : ""}/> включён</label></h3>
      <div class="vendor">${escapeHtml(adapter.vendor || "")} · id: ${escapeHtml(adapter.id)}</div>
      <div class="url-patterns">
        <label style="font-size:12px;color:#cbd5e1">URL-паттерны (по одному в строке, подстрока в адресе страницы):</label>
        <textarea rows="2" data-role="urlPatterns">${escapeHtml((adapter.urlPatterns || []).join("\n"))}</textarea>
      </div>
      <div class="selectors"></div>
    `;
    const selectorsEl = card.querySelector(".selectors");
    Object.keys(FIELD_LABELS).forEach((field) => {
      const row = document.createElement("div");
      row.className = "field-row";
      row.innerHTML = `
        <label>${FIELD_LABELS[field]}</label>
        <input type="text" data-field="${field}" value="${escapeHtml(adapter.selectors[field] || "")}" placeholder="CSS-селектор" />
        <button type="button" data-pick="${field}">Выбрать на странице</button>
      `;
      selectorsEl.appendChild(row);
    });

    // Обработчики
    card.querySelector('[data-role="enabled"]').addEventListener("change", (e) => {
      adapters[idx].enabled = e.target.checked;
      saveAdapters();
    });
    card.querySelector('[data-role="urlPatterns"]').addEventListener("change", (e) => {
      adapters[idx].urlPatterns = e.target.value.split("\n").map((s) => s.trim()).filter(Boolean);
      saveAdapters();
    });
    selectorsEl.querySelectorAll('input[data-field]').forEach((input) => {
      input.addEventListener("change", (e) => {
        adapters[idx].selectors[e.target.dataset.field] = e.target.value;
        saveAdapters();
      });
    });
    selectorsEl.querySelectorAll('button[data-pick]').forEach((btn) => {
      btn.addEventListener("click", () => startPicking(idx, btn.dataset.pick));
    });

    root.appendChild(card);
  });
}

function startPicking(adapterIdx, field) {
  if (!targetTabId) {
    toast("Выберите вкладку с карточкой инцидента вверху страницы");
    return;
  }
  chrome.tabs.sendMessage(targetTabId, { type: "socCopilotStartPicker", field }, (resp) => {
    if (chrome.runtime.lastError) {
      toast("Не удалось связаться со вкладкой. Обновите её и попробуйте снова.");
      return;
    }
    toast(`Кликните по элементу «${FIELD_LABELS[field]}» на вкладке карточки инцидента`);
  });
  pendingPick = { adapterIdx, field };
}

let pendingPick = null;
chrome.runtime.onMessage.addListener((msg) => {
  if (msg.type === "socCopilotPickerResult" && pendingPick) {
    adapters[pendingPick.adapterIdx].selectors[pendingPick.field] = msg.selector;
    renderAdapters();
    saveAdapters();
    toast(`Селектор для «${FIELD_LABELS[pendingPick.field]}» сохранён`);
    pendingPick = null;
  }
});

function saveAdapters() {
  chrome.storage.local.set({ socCopilotAdapters: adapters }, () => {
    broadcastSettingsUpdated();
  });
}

function loadAdapters() {
  chrome.storage.local.get(["socCopilotAdapters"], (data) => {
    adapters = data.socCopilotAdapters && data.socCopilotAdapters.length
      ? data.socCopilotAdapters
      : JSON.parse(JSON.stringify(SOC_COPILOT_DEFAULT_ADAPTERS));
    renderAdapters();
    if (typeof populateMarketplacePublishSelect === "function") populateMarketplacePublishSelect();
  });
}

// --- Секреты: write-only паттерн ---------------------------------------------
// Значения шифруются перед сохранением (см. utils/crypto.js) и НИКОГДА не
// расшифровываются здесь, на странице настроек, для повторного отображения —
// расшифровка происходит только в background.js в момент фактического сетевого
// запроса. После сохранения поле показывает плейсхолдер, а не сам секрет.

const SECRET_PLACEHOLDER = "•••••••• (сохранено — введите новое значение, чтобы изменить)";

function markSecretSaved(inputEl) {
  inputEl.value = "";
  inputEl.placeholder = SECRET_PLACEHOLDER;
}

async function loadKeys() {
  chrome.storage.local.get(["socCopilotSecretsMeta"], (data) => {
    const meta = data.socCopilotSecretsMeta || {};
    if (meta.virustotal) document.getElementById("key-vt").placeholder = SECRET_PLACEHOLDER;
    if (meta.abuseipdb) document.getElementById("key-abuseipdb").placeholder = SECRET_PLACEHOLDER;
    if (meta.anthropic) document.getElementById("key-anthropic").placeholder = SECRET_PLACEHOLDER;
  });
}

document.getElementById("saveKeys").addEventListener("click", async () => {
  const vtEl = document.getElementById("key-vt");
  const abuseEl = document.getElementById("key-abuseipdb");
  const anthropicEl = document.getElementById("key-anthropic");

  const { socCopilotApiKeysEnc, socCopilotSecretsMeta } = await chrome.storage.local.get([
    "socCopilotApiKeysEnc",
    "socCopilotSecretsMeta"
  ]);
  const existingJson = await socCopilotDecryptString(socCopilotApiKeysEnc);
  const existing = existingJson ? JSON.parse(existingJson) : {};
  const meta = socCopilotSecretsMeta || {};

  const merged = {
    virustotal: vtEl.value.trim() || existing.virustotal || "",
    abuseipdb: abuseEl.value.trim() || existing.abuseipdb || "",
    anthropic: anthropicEl.value.trim() || existing.anthropic || ""
  };
  const enc = await socCopilotEncryptString(JSON.stringify(merged));
  meta.virustotal = !!merged.virustotal;
  meta.abuseipdb = !!merged.abuseipdb;
  meta.anthropic = !!merged.anthropic;

  chrome.storage.local.set({ socCopilotApiKeysEnc: enc, socCopilotSecretsMeta: meta }, () => {
    [vtEl, abuseEl, anthropicEl].forEach(markSecretSaved);
    toast("Ключи сохранены (зашифрованы)");
  });
});

function loadPlaybooks() {
  chrome.storage.local.get(["socCopilotPlaybooks"], (data) => {
    const pb = data.socCopilotPlaybooks && data.socCopilotPlaybooks.length
      ? data.socCopilotPlaybooks
      : SOC_COPILOT_DEFAULT_PLAYBOOKS;
    document.getElementById("playbooksJson").value = JSON.stringify(pb, null, 2);
  });
}

document.getElementById("savePlaybooks").addEventListener("click", () => {
  try {
    const parsed = JSON.parse(document.getElementById("playbooksJson").value);
    chrome.storage.local.set({ socCopilotPlaybooks: parsed }, () => toast("Плейбуки сохранены"));
  } catch (e) {
    toast("Ошибка в JSON: " + e.message);
  }
});

document.getElementById("resetPlaybooks").addEventListener("click", () => {
  document.getElementById("playbooksJson").value = JSON.stringify(SOC_COPILOT_DEFAULT_PLAYBOOKS, null, 2);
});

function loadAttackSyncStatus() {
  chrome.storage.local.get(["socCopilotAttackSyncMeta"], (data) => {
    const meta = data.socCopilotAttackSyncMeta;
    const el = document.getElementById("attackSyncStatus");
    if (meta) {
      el.textContent = `Синхронизировано: ${meta.count} техник, последний раз — ${new Date(meta.syncedAt).toLocaleString("ru-RU")}`;
    } else {
      el.textContent = "База не синхронизирована — используется встроенный курируемый набор.";
    }
  });
}

document.getElementById("syncAttack").addEventListener("click", (e) => {
  e.target.disabled = true;
  e.target.textContent = "Синхронизация…";
  chrome.runtime.sendMessage({ type: "socCopilotSyncAttack" }, (resp) => {
    e.target.disabled = false;
    e.target.textContent = "Синхронизировать с MITRE CTI (GitHub)";
    if (!resp || resp.error) {
      toast("Ошибка синхронизации: " + (resp?.error || "неизвестная ошибка"));
      return;
    }
    toast(`Синхронизировано ${resp.count} техник`);
    loadAttackSyncStatus();
  });
});

function loadCompanyNames() {
  chrome.storage.local.get(["socCopilotCompanyNames"], (data) => {
    document.getElementById("companyNames").value = (data.socCopilotCompanyNames || []).join("\n");
  });
}

document.getElementById("saveCompanyNames").addEventListener("click", () => {
  const names = document
    .getElementById("companyNames")
    .value.split("\n")
    .map((s) => s.trim())
    .filter(Boolean);
  chrome.storage.local.set({ socCopilotCompanyNames: names }, () => toast("Список сохранён"));
});

async function loadTelegram() {
  chrome.storage.local.get(["socCopilotSecretsMeta", "socCopilotTelegramChatId"], (data) => {
    if ((data.socCopilotSecretsMeta || {}).telegram) {
      document.getElementById("telegramToken").placeholder = SECRET_PLACEHOLDER;
    }
    document.getElementById("telegramChatId").value = data.socCopilotTelegramChatId || "";
  });
}

document.getElementById("saveTelegram").addEventListener("click", async () => {
  const tokenEl = document.getElementById("telegramToken");
  const chatId = document.getElementById("telegramChatId").value.trim();
  const { socCopilotTelegramConfigEnc, socCopilotSecretsMeta } = await chrome.storage.local.get([
    "socCopilotTelegramConfigEnc",
    "socCopilotSecretsMeta"
  ]);
  const existingJson = await socCopilotDecryptString(socCopilotTelegramConfigEnc);
  const existing = existingJson ? JSON.parse(existingJson) : {};
  const token = tokenEl.value.trim() || existing.token || "";
  const enc = await socCopilotEncryptString(JSON.stringify({ token, chatId }));
  const meta = socCopilotSecretsMeta || {};
  meta.telegram = !!token;

  chrome.storage.local.set(
    { socCopilotTelegramConfigEnc: enc, socCopilotTelegramChatId: chatId, socCopilotSecretsMeta: meta },
    () => {
      markSecretSaved(tokenEl);
      toast("Telegram сохранён (токен зашифрован)");
    }
  );
});

async function loadMax() {
  chrome.storage.local.get(["socCopilotSecretsMeta", "socCopilotMaxChatId"], (data) => {
    if ((data.socCopilotSecretsMeta || {}).max) {
      document.getElementById("maxToken").placeholder = SECRET_PLACEHOLDER;
    }
    document.getElementById("maxChatId").value = data.socCopilotMaxChatId || "";
  });
}

document.getElementById("saveMax").addEventListener("click", async () => {
  const tokenEl = document.getElementById("maxToken");
  const chatId = document.getElementById("maxChatId").value.trim();
  const { socCopilotMaxConfigEnc, socCopilotSecretsMeta } = await chrome.storage.local.get([
    "socCopilotMaxConfigEnc",
    "socCopilotSecretsMeta"
  ]);
  const existingJson = await socCopilotDecryptString(socCopilotMaxConfigEnc);
  const existing = existingJson ? JSON.parse(existingJson) : {};
  const token = tokenEl.value.trim() || existing.token || "";
  const enc = await socCopilotEncryptString(JSON.stringify({ token, chatId }));
  const meta = socCopilotSecretsMeta || {};
  meta.max = !!token;

  chrome.storage.local.set(
    { socCopilotMaxConfigEnc: enc, socCopilotMaxChatId: chatId, socCopilotSecretsMeta: meta },
    () => {
      markSecretSaved(tokenEl);
      toast("MAX сохранён (токен зашифрован)");
    }
  );
});

async function loadWebhook() {
  chrome.storage.local.get(["socCopilotSecretsMeta"], (data) => {
    if ((data.socCopilotSecretsMeta || {}).webhook) {
      document.getElementById("webhookUrl").placeholder = SECRET_PLACEHOLDER;
    }
  });
}

document.getElementById("saveWebhook").addEventListener("click", async () => {
  const urlEl = document.getElementById("webhookUrl");
  const url = urlEl.value.trim();
  if (!url) return; // пустое поле — оставляем как есть, ничего не перезаписываем
  const enc = await socCopilotEncryptString(url);
  const { socCopilotSecretsMeta } = await chrome.storage.local.get(["socCopilotSecretsMeta"]);
  const meta = socCopilotSecretsMeta || {};
  meta.webhook = true;

  chrome.storage.local.set({ socCopilotWebhookUrlEnc: enc, socCopilotSecretsMeta: meta }, () => {
    markSecretSaved(urlEl);
    toast("Webhook сохранён (зашифрован)");
  });
});

document.getElementById("exportSettings").addEventListener("click", () => {
  chrome.storage.local.get(["socCopilotAdapters", "socCopilotPlaybooks"], (data) => {
    const payload = {
      exportedAt: new Date().toISOString(),
      version: chrome.runtime.getManifest().version,
      adapters: data.socCopilotAdapters || adapters,
      playbooks: data.socCopilotPlaybooks || SOC_COPILOT_DEFAULT_PLAYBOOKS
    };
    const blob = new Blob([JSON.stringify(payload, null, 2)], { type: "application/json" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = "soc-copilot-settings.json";
    a.click();
    URL.revokeObjectURL(url);
  });
});

document.getElementById("importSettingsBtn").addEventListener("click", () => {
  document.getElementById("importSettingsFile").click();
});

document.getElementById("importSettingsFile").addEventListener("change", (e) => {
  const file = e.target.files[0];
  if (!file) return;
  const reader = new FileReader();
  reader.onload = () => {
    try {
      const parsed = JSON.parse(reader.result);
      if (!parsed.adapters && !parsed.playbooks) throw new Error("файл не похож на экспорт настроек Belyaev Response");
      const toSave = {};
      if (Array.isArray(parsed.adapters)) toSave.socCopilotAdapters = parsed.adapters;
      if (Array.isArray(parsed.playbooks)) toSave.socCopilotPlaybooks = parsed.playbooks;
      chrome.storage.local.set(toSave, () => {
        toast("Настройки импортированы");
        loadAdapters();
        loadPlaybooks();
      });
    } catch (err) {
      toast("Ошибка импорта: " + err.message);
    }
  };
  reader.readAsText(file);
  e.target.value = "";
});

// --- Лицензия -----------------------------------------------------------------

function loadLicenseStatus() {
  chrome.storage.local.get(["socCopilotInstallDate", "socCopilotLicense", "socCopilotLicenseServerUrl"], (data) => {
    const state = socCopilotComputeLicenseState({
      installDate: data.socCopilotInstallDate || new Date().toISOString(),
      license: data.socCopilotLicense || null
    });
    const el = document.getElementById("licenseStatus");
    if (state.tier === "pro" && state.source === "license") {
      el.textContent = `✅ Pro (лицензия${state.orgName ? ", " + state.orgName : ""}), действует до ${new Date(state.expiresAt).toLocaleDateString("ru-RU")}`;
    } else if (state.tier === "pro" && state.source === "trial") {
      el.textContent = `🎁 Pro (бесплатный триал) — осталось ${state.trialDaysLeft} дн.`;
    } else {
      el.textContent = "⬜ Free-тариф. Активируйте лицензию для Pro-функций (см. вкладку «Тарифы» в README).";
    }
    // URL сервера лицензирования больше не вводится пользователем — единый сервер,
    // см. константу SOC_COPILOT_LICENSE_SERVER_URL ниже.
  });
}

// ЕДИНЫЙ сервер лицензирования — меняйте здесь при переезде на другой домен/IP.
// Раньше URL вводил каждый пользователь вручную; теперь лицензии выдаёт только
// владелец продукта, поэтому сервер один и жёстко задан в коде обеих сторон
// (см. также background.js: getLicenseAuth()).
const SOC_COPILOT_LICENSE_SERVER_URL = "https://belyaev.expert";

document.getElementById("activateLicense").addEventListener("click", () => {
  const btn = document.getElementById("activateLicense");
  const key = document.getElementById("licenseKey").value.trim();
  if (!key) {
    toast("Укажите лицензионный ключ");
    return;
  }
  btn.disabled = true;
  btn.textContent = "Активация…";
  chrome.runtime.sendMessage({ type: "socCopilotLicenseActivate", key, serverUrl: SOC_COPILOT_LICENSE_SERVER_URL }, (resp) => {
    btn.disabled = false;
    btn.textContent = "Активировать";
    if (!resp || !resp.valid) {
      toast("Не удалось активировать: " + (resp?.reason || "неизвестная ошибка"));
      return;
    }
    document.getElementById("licenseKey").value = ""; // write-only — ключ уже сохранён зашифрованным
    toast("Лицензия активирована ✓");
    loadLicenseStatus();
  });
});

// --- Grafana-синхронизация ------------------------------------------------------

function loadGrafanaSettings() {
  chrome.storage.local.get(["socCopilotGrafanaSyncEnabled", "socCopilotAnalystPseudonym"], (data) => {
    document.getElementById("grafanaSyncEnabled").checked = !!data.socCopilotGrafanaSyncEnabled;
    document.getElementById("analystPseudonym").value = data.socCopilotAnalystPseudonym || "";
  });
}

document.getElementById("saveGrafanaSettings").addEventListener("click", () => {
  const enabled = document.getElementById("grafanaSyncEnabled").checked;
  const pseudonym = document.getElementById("analystPseudonym").value.trim();
  chrome.storage.local.set(
    { socCopilotGrafanaSyncEnabled: enabled, socCopilotAnalystPseudonym: pseudonym },
    () => toast("Настройки Grafana сохранены")
  );
});

document.getElementById("syncNow").addEventListener("click", () => {
  const btn = document.getElementById("syncNow");
  chrome.storage.local.get(
    ["socCopilotBelZorBalance", "socCopilotEventsLog", "socCopilotConclusionsHistory"],
    (data) => {
      const history = data.socCopilotConclusionsHistory || [];
      const byVerdict = { tp: 0, fp: 0, benign: 0, escalate: 0 };
      history.forEach((h) => {
        if (byVerdict.hasOwnProperty(h.verdict)) byVerdict[h.verdict] += 1;
      });
      const payload = {
        belZorBalance: data.socCopilotBelZorBalance || 0,
        eventsCount: (data.socCopilotEventsLog || []).length,
        incidentsCount: history.length,
        byVerdict
      };
      btn.disabled = true;
      btn.textContent = "Отправка…";
      chrome.runtime.sendMessage({ type: "socCopilotIngestStats", payload }, (resp) => {
        btn.disabled = false;
        btn.textContent = "Синхронизировать сейчас";
        toast(resp && resp.ok ? "Синхронизировано ✓" : "Ошибка: " + (resp?.reason || "неизвестная"));
      });
    }
  );
});

// --- Teams ----------------------------------------------------------------------

async function loadTeams() {
  chrome.storage.local.get(["socCopilotSecretsMeta"], (data) => {
    if ((data.socCopilotSecretsMeta || {}).teams) {
      document.getElementById("teamsWebhookUrl").placeholder = SECRET_PLACEHOLDER;
    }
  });
}

document.getElementById("saveTeams").addEventListener("click", async () => {
  const urlEl = document.getElementById("teamsWebhookUrl");
  const url = urlEl.value.trim();
  if (!url) return;
  const enc = await socCopilotEncryptString(url);
  const { socCopilotSecretsMeta } = await chrome.storage.local.get(["socCopilotSecretsMeta"]);
  const meta = socCopilotSecretsMeta || {};
  meta.teams = true;
  chrome.storage.local.set({ socCopilotTeamsWebhookUrlEnc: enc, socCopilotSecretsMeta: meta }, () => {
    markSecretSaved(urlEl);
    toast("Teams сохранён (зашифрован)");
  });
});

// --- Jira -------------------------------------------------------------------------

async function loadJira() {
  chrome.storage.local.get(["socCopilotSecretsMeta", "socCopilotJiraMeta"], (data) => {
    if ((data.socCopilotSecretsMeta || {}).jira) {
      document.getElementById("jiraApiToken").placeholder = SECRET_PLACEHOLDER;
    }
    const meta = data.socCopilotJiraMeta || {};
    document.getElementById("jiraBaseUrl").value = meta.baseUrl || "";
    document.getElementById("jiraEmail").value = meta.email || "";
    document.getElementById("jiraProjectKey").value = meta.projectKey || "";
    document.getElementById("jiraIssueType").value = meta.issueType || "Task";
  });
}

document.getElementById("saveJira").addEventListener("click", async () => {
  const tokenEl = document.getElementById("jiraApiToken");
  const jiraMeta = {
    baseUrl: document.getElementById("jiraBaseUrl").value.trim(),
    email: document.getElementById("jiraEmail").value.trim(),
    projectKey: document.getElementById("jiraProjectKey").value.trim(),
    issueType: document.getElementById("jiraIssueType").value.trim() || "Task"
  };
  const { socCopilotJiraConfigEnc, socCopilotSecretsMeta } = await chrome.storage.local.get([
    "socCopilotJiraConfigEnc",
    "socCopilotSecretsMeta"
  ]);
  const existingJson = await socCopilotDecryptString(socCopilotJiraConfigEnc);
  const existing = existingJson ? JSON.parse(existingJson) : {};
  const apiToken = tokenEl.value.trim() || existing.apiToken || "";
  const enc = await socCopilotEncryptString(JSON.stringify({ apiToken }));
  const meta = socCopilotSecretsMeta || {};
  meta.jira = !!apiToken;

  chrome.storage.local.set(
    { socCopilotJiraConfigEnc: enc, socCopilotJiraMeta: jiraMeta, socCopilotSecretsMeta: meta },
    () => {
      markSecretSaved(tokenEl);
      toast("Jira сохранена (токен зашифрован)");
    }
  );
});

// --- Локальная LLM ----------------------------------------------------------------

function loadLocalLLM() {
  chrome.storage.local.get(
    ["socCopilotLocalLLMEnabled", "socCopilotLocalLLMUrl", "socCopilotLocalLLMModel", "socCopilotLocalLLMProvider"],
    (data) => {
      document.getElementById("localLLMEnabled").checked = !!data.socCopilotLocalLLMEnabled;
      document.getElementById("localLLMUrl").value = data.socCopilotLocalLLMUrl || "http://localhost:11434";
      document.getElementById("localLLMModel").value = data.socCopilotLocalLLMModel || "llama3";
      if (data.socCopilotLocalLLMProvider)
        document.getElementById("localLLMProvider").value = data.socCopilotLocalLLMProvider;
    }
  );
}

document.getElementById("saveLocalLLM").addEventListener("click", () => {
  const enabled = document.getElementById("localLLMEnabled").checked;
  const url = document.getElementById("localLLMUrl").value.trim();
  const model = document.getElementById("localLLMModel").value.trim();
  const provider = document.getElementById("localLLMProvider").value;
  chrome.storage.local.set(
    { socCopilotLocalLLMEnabled: enabled, socCopilotLocalLLMUrl: url, socCopilotLocalLLMModel: model, socCopilotLocalLLMProvider: provider },
    () => toast("LLM настройки сохранены")
  );
});

// --- ФИО и контакты аналитика --------------------------------------------------

function loadAnalystInfo() {
  chrome.storage.local.get(["socCopilotAnalystPseudonym", "socCopilotAnalystFullName", "socCopilotAnalystContacts"], (data) => {
    if (document.getElementById("analystPseudonym"))
      document.getElementById("analystPseudonym").value = data.socCopilotAnalystPseudonym || "";
    if (document.getElementById("analystFullName"))
      document.getElementById("analystFullName").value = data.socCopilotAnalystFullName || "";
    if (document.getElementById("analystContacts"))
      document.getElementById("analystContacts").value = data.socCopilotAnalystContacts || "";
  });
}

// Сохранение ФИО/контактов вместе с кнопкой Grafana (они в одном разделе)
const _origSaveGrafanaClick = document.getElementById("saveGrafanaSettings").onclick;
document.getElementById("saveGrafanaSettings").addEventListener("click", () => {
  const fullName = document.getElementById("analystFullName")?.value.trim() || "";
  const contacts = document.getElementById("analystContacts")?.value.trim() || "";
  chrome.storage.local.set({ socCopilotAnalystFullName: fullName, socCopilotAnalystContacts: contacts });
});

// --- Забота об аналитике (детектор выгорания) --------------------------------------

function loadBurnoutSettings() {
  chrome.storage.local.get(["socCopilotBurnoutCheckEnabled"], (data) => {
    document.getElementById("burnoutCheckEnabled").checked = data.socCopilotBurnoutCheckEnabled !== false; // по умолчанию включено
  });
}

document.getElementById("saveBurnoutSettings").addEventListener("click", () => {
  const enabled = document.getElementById("burnoutCheckEnabled").checked;
  chrome.storage.local.set({ socCopilotBurnoutCheckEnabled: enabled }, () => toast("Сохранено"));
});

// --- Маркетплейс адаптеров ---------------------------------------------------

function populateMarketplacePublishSelect() {
  const select = document.getElementById("marketplacePublishSelect");
  select.innerHTML = adapters
    .map((a, i) => `<option value="${i}">${escapeHtml(a.name)} (${escapeHtml(a.id)})</option>`)
    .join("");
}

let lastMarketplaceListing = []; // для предпросмотра селекторов перед установкой (см. security-фикс ниже)

document.getElementById("marketplaceRefresh").addEventListener("click", () => {
  const statusEl = document.getElementById("marketplaceStatus");
  const listEl = document.getElementById("marketplaceList");
  statusEl.textContent = "Загрузка…";
  chrome.runtime.sendMessage({ type: "socCopilotMarketplaceList" }, (resp) => {
    if (!resp || !resp.ok) {
      statusEl.textContent = "Ошибка: " + (resp?.error || "неизвестная");
      listEl.innerHTML = "";
      return;
    }
    lastMarketplaceListing = resp.adapters;
    statusEl.textContent = `Найдено адаптеров: ${resp.adapters.length}`;
    listEl.innerHTML = resp.adapters
      .map(
        (a) => `
        <div class="adapter-card">
          <h3>${escapeHtml(a.name)}</h3>
          <div class="vendor">${escapeHtml(a.vendor || "—")} · автор: ${escapeHtml(a.publishedBy)} · загрузок: ${a.downloads || 0}</div>
          <button type="button" data-preview="${escapeHtml(a.id)}">Показать селекторы</button>
          <button type="button" data-install="${escapeHtml(a.id)}">Установить</button>
          <pre class="marketplace-preview" data-preview-for="${escapeHtml(a.id)}" style="display:none"></pre>
        </div>`
      )
      .join("");
    listEl.querySelectorAll("[data-preview]").forEach((btn) =>
      btn.addEventListener("click", () => toggleMarketplacePreview(btn.dataset.preview))
    );
    listEl.querySelectorAll("[data-install]").forEach((btn) =>
      btn.addEventListener("click", () => installMarketplaceAdapter(btn.dataset.install, btn))
    );
  });
});

// Security-фикс (аудит): раньше адаптер устанавливался без возможности проверить,
// НА ЧТО именно указывают его селекторы, — а они определяют, какой текст со страницы
// SIEM попадёт в извлечённые поля карточки (и далее может уйти в LLM/отчёт после
// обезличивания). Установка чужого адаптера из маркетплейса — это по сути доверие
// незнакомой организации в вопросе "откуда на странице брать текст". Теперь селекторы
// можно посмотреть ДО установки, а сама установка требует явного подтверждения.
function toggleMarketplacePreview(id) {
  let pre = null;
  try {
    pre = document.querySelector(`.marketplace-preview[data-preview-for="${id}"]`);
  } catch {
    pre = null; // defense-in-depth: сервер уже валидирует id строго (ADAPTER_ID_RE),
    // но не полагаемся только на это здесь — некорректный селектор просто не найдёт узел.
  }
  if (!pre) return;
  if (pre.style.display !== "none") {
    pre.style.display = "none";
    return;
  }
  const adapter = lastMarketplaceListing.find((a) => a.id === id);
  pre.textContent = adapter ? JSON.stringify({ urlPatterns: adapter.urlPatterns, selectors: adapter.selectors }, null, 2) : "не найдено";
  pre.style.display = "block";
}

function escapeHtml(s) {
  return String(s || "").replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" }[c]));
}

function installMarketplaceAdapter(adapterId, btn) {
  btn.disabled = true;
  btn.textContent = "Установка…";
  chrome.runtime.sendMessage({ type: "socCopilotMarketplaceDownload", adapterId }, (resp) => {
    btn.disabled = false;
    if (!resp || !resp.ok) {
      btn.textContent = "Ошибка: " + (resp?.error || "неизвестная");
      return;
    }
    const downloaded = resp.adapter;
    const idx = adapters.findIndex((a) => a.id === downloaded.id);
    const newAdapter = {
      id: downloaded.id,
      name: downloaded.name,
      vendor: downloaded.vendor,
      enabled: true,
      urlPatterns: downloaded.urlPatterns,
      selectors: downloaded.selectors
    };
    if (idx >= 0) adapters[idx] = newAdapter;
    else adapters.push(newAdapter);
    saveAdapters();
    renderAdapters();
    populateMarketplacePublishSelect();
    btn.textContent = "Установлено ✓";
    toast(`Адаптер «${downloaded.name}» установлен`);
  });
}

document.getElementById("marketplacePublishBtn").addEventListener("click", () => {
  const btn = document.getElementById("marketplacePublishBtn");
  const idx = Number(document.getElementById("marketplacePublishSelect").value);
  const adapter = adapters[idx];
  if (!adapter) return;
  btn.disabled = true;
  btn.textContent = "Публикация…";
  chrome.runtime.sendMessage({ type: "socCopilotMarketplacePublish", adapter }, (resp) => {
    btn.disabled = false;
    btn.textContent = "Опубликовать";
    if (!resp || !resp.ok) {
      toast("Ошибка публикации: " + (resp?.error || "неизвестная"));
      return;
    }
    toast(`Адаптер «${adapter.name}» опубликован`);
  });
});

// --- Оформление и язык -------------------------------------------------------

function populateLanguageSelect() {
  const select = document.getElementById("uiLanguage");
  select.innerHTML = SOC_COPILOT_LANGUAGES
    .map((l) => `<option value="${l.code}">${l.native} (${l.ru})</option>`)
    .join("");
}

function applyOptionsPageTheme(theme) {
  document.body.classList.toggle("sc-theme-light", theme === "light");
}

function loadAppearance() {
  chrome.storage.local.get(["socCopilotUITheme", "socCopilotUILanguage"], (data) => {
    const theme = data.socCopilotUITheme || "dark";
    document.getElementById("uiTheme").value = theme;
    document.getElementById("uiLanguage").value = data.socCopilotUILanguage || "ru";
    applyOptionsPageTheme(theme);
  });
}

document.getElementById("saveAppearance").addEventListener("click", () => {
  const theme = document.getElementById("uiTheme").value;
  const language = document.getElementById("uiLanguage").value;
  chrome.storage.local.set({ socCopilotUITheme: theme, socCopilotUILanguage: language }, () => {
    toast("Оформление сохранено");
    applyOptionsPageTheme(theme); // сама страница настроек тоже должна следовать теме — раньше не следовала
    // Применится сразу на уже открытых вкладках с карточками инцидентов —
    // используем тот же канал, что и остальные настройки (см. saveAdapters).
    broadcastSettingsUpdated();
  });
});

populateLanguageSelect();
loadAppearance();

loadTabsSelector();
loadAdapters();
loadKeys();
loadPlaybooks();
loadAttackSyncStatus();
loadWebhook();
loadCompanyNames();
loadTelegram();
loadMax();
loadLicenseStatus();
loadGrafanaSettings();
loadTeams();
loadJira();
loadLocalLLM();
loadBurnoutSettings();
loadAnalystInfo();
